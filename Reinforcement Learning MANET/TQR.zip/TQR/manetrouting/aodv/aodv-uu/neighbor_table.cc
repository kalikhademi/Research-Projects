/*****************************************************************************
 *
 * Copyright (C) 2001 Uppsala University and Ericsson AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Erik Nordstr�m, <erik.nordstrom@it.uu.se>
 *
 *****************************************************************************/
#define NS_PORT
#define OMNETPP

#include <time.h>
#include <fstream>
#include <iostream>

#ifdef NS_PORT
#ifndef OMNETPP
#include "ns/aodv-uu.h"
#else
#include "../aodv_uu_omnet.h"
#endif
#else
#include "routing_table.h"
#include "neighbor_table.h"
#include "aodv_timeout.h"
#include "aodv_rerr.h"
#include "aodv_hello.h"
#include "aodv_socket.h"
#include "aodv_neighbor.h"
#include "timer_queue_aodv.h"
#include "defs_aodv.h"
#include "debug_aodv.h"
#include "params.h"
#include "seek_list.h"
#include "nl.h"
extern int llfeedback;
#endif              /* NS_PORT */

void NS_CLASS nei_table_init()
{
    while (!aodvNeiTableMap.empty())
    {
        nei_table_delete (aodvNeiTableMap.begin()->second);
        aodvNeiTableMap.erase(aodvNeiTableMap.begin());
    }
}

void NS_CLASS nei_table_delete(nei_table_t * nei)
{
    if (!nei)
    {
        DEBUG(LOG_ERR, 0, "No neighbor entry to delete");
        return;
    }

    ManetAddress dest = nei->nei_addr.s_addr;
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(dest);
    if (it != aodvNeiTableMap.end())
    {
        if (it->second != nei)
            opp_error("AODV neighbor table error");
    }
    aodvNeiTableMap.erase(it);
    free(nei);
    return;
}

nei_table_t *NS_CLASS nei_table_find(struct in_addr dest_addr)
{

    if (aodvNeiTableMap.empty())
        return NULL;

    // Check if we already have an entry for dest_addr
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(dest_addr.s_addr);

    if (it != aodvNeiTableMap.end())
        return it->second;
    return NULL;
}

nei_table_t *NS_CLASS nei_table_insert(struct in_addr neigh_addr,double Dt,double It , double Tt ,bool isTr, double q_val,
        int fwdto,int fwded, bool bl, bool now, double energy, double fVal, simtime_t delay)
{
    nei_table_t *nei;
    ManetAddress neighbor;
    neighbor=neigh_addr.S_addr;
    if ((nei = (nei_table_t *) malloc(sizeof(nei_table_t))) == NULL)
    {
        fprintf(stderr, "Malloc failed!\n");
        exit(-1);
    }
    memset(nei, 0, sizeof(nei_table_t));
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(neighbor);
    if (it != aodvNeiTableMap.end())
        return it->second;
    nei->Ttrust=Tt;
    nei->Itrust=It;
    nei->trusted=isTr;
    nei->Dtrust=Dt;
    nei->q_value=q_val;
    nei->forwardTo=fwdto;
    nei->forwarded=fwded;
    nei->blacklist=bl;
    nei->nei_now = now;
    nei->energy = energy;
    nei->lastUpdate = 0;
    nei->futureValue = fVal;
    nei->delay = delay;    //not used in the algorithm
    nei->forward = 0;
    nei->rcvd = 0;
    nei->hello_rcvd = 0;
    nei->hello_send = 0;
    nei->etx = 0;
    aodvNeiTableMap.insert(std::make_pair(neighbor,nei));

    AodvNeiTableMap::iterator it2 = aodvNeiTableMap.find(neighbor);
    EV<<"add new neighbor to neighbor_table: "<<"\t"<<it2->second->Ttrust<<"\t"<<it2->second->blacklist<<endl;

   /*  write neighbor table map in the txt file
    std::fstream neiFile;
    neiFile.open("neiTableMap.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    if(neiFile.is_open())
    {
        neiFile<<neighbor<<" : "<< nei->Ttrust<<"\t"<<endl;
        neiFile.close();
    }
    else
        EV<<"error opening neiTableMap file"<<endl;*/

    return nei;
}

void NS_CLASS show_neighbors()
{
    std::fstream showFile;
    showFile.open("neighbor tables.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    for (AodvNeiTableMap::iterator it3 = aodvNeiTableMap.begin(); it3 != aodvNeiTableMap.end(); it3++)
   {
       //EV<<"neighbors information: "<< it3->first <<" :"<<it3->second->Ttrust<<"\t"<<it3->second->blacklist<<endl;
       showFile<<it3->first<<":"<<it3->second->Ttrust<<"\t"<<it3->second->blacklist<<endl;
   }
    showFile<<endl;
    showFile.close();
    return;
}

void NS_CLASS inc_forwarded_packet(struct in_addr nei_addr)
{
   // Check if we already have an entry for nei_addr
   AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
   if (it != aodvNeiTableMap.end())
       it->second->forwarded++;
   return;
}

void NS_CLASS inc_forwardTo_packet(struct in_addr nei_addr)
{
   // Check if we already have an entry for nei_addr
   AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
   if (it != aodvNeiTableMap.end())
       it->second->forwardTo++;
   return;
}

/*void NS_CLASS inc_forward_packet(struct in_addr nei_addr)
{
   // Check if we already have an entry for nei_addr
   AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
   if (it != aodvNeiTableMap.end())
       it->second->forward++;
   return;
}

void NS_CLASS inc_rcvd_packet(struct in_addr nei_addr)
{
   // Check if we already have an entry for nei_addr
   AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
   if (it != aodvNeiTableMap.end())
       it->second->rcvd++;
   return;
}*/

void NS_CLASS trust_value_update()
{
    double current_trust = 0;
    struct in_addr nei_addr;
    bool foundFlag, noRelation, found2, found;
    std::fstream trustFile;
    trustFile.open("Trust.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    trustFile<<"in "<< DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<endl;
    trustFile<<"routing table:"<<endl;
    for(AodvRtTableMap::iterator it=aodvRtTableMap.begin(); it!=aodvRtTableMap.end(); it++)
    {

       struct in_addr newNei;
       newNei.S_addr = it->first;
       nei_table_t *nei = nei_table_find(newNei);
       if(!nei)
           nei_table_insert (newNei, 0, 0 , -1.0 ,true, 0, 0, 0 , false, true, -1, 0, 0);
       trustFile<<"   "<<it->first<<": "<<it->second->trusted<<endl;
    }
    trustFile<<"\n\n";
    trustFile<<"neighbor table:"<<endl;
    for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
    {
       trustFile<<"   "<<it->first<<": "<<it->second->trusted<<endl;
    }
    trustFile<<"\n\n";
    for(IPMap::iterator it=ipmap.begin(); it!=ipmap.end(); it++)
    {
        trustFile<<"\n"<<it->first<<" :\n";
        for(unsigned int i=0; i<it->second.size(); i++)
            trustFile<<it->second[i]->neiNode<<"  "<<it->second[i]->fwded<<"  "<<it->second[i]->fwdto<<endl;
        trustFile<<"\n\n";
    }
    IPMap::iterator myIp = ipmap.find(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr);

    for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
    {
        foundFlag = false;
        noRelation = false;
        found2 = false;
        found = false;
        //if(it->first == it->second->next_hop.S_addr)
        //{
           // AodvNeiTableMap::iterator Nei = aodvNeiTableMap.find(it->first);
           // if(Nei != aodvNeiTableMap.end())
           // {
                IPMap::iterator neiIp = ipmap.find(it->first);
                for(unsigned int i=0 ; i<myIp->second.size();i++)
                {
                    if(ManetAddress(myIp->second[i]->neiNode) == it->first)
                    {
                        foundFlag = true;
                        if(myIp->second[i]->fwdto == 0)
                        {
                            trustFile<<"the node had not relationship with "<<it->first<<" yet."<<endl;
                            noRelation = true;
                            break;
                        }
                        else if(myIp->second[i]->fwdto != 0 && it->second->Ttrust == -1)
                        {
                            trustFile<<"first relationship!"<<endl;
                            for(unsigned int j=0 ; j<neiIp->second.size();j++)
                                if(ManetAddress(neiIp->second[j]->neiNode) == myIp->first)
                                {
                                    trustFile<<"number of packets forwarded by neigh:"<<neiIp->second[j]->fwded<<endl;
                                    trustFile<<"number of packets forwarded to neigh:"<<myIp->second[i]->fwdto<<endl;
                                    it->second->Dtrust = (double)(neiIp->second[j]->fwded)/myIp->second[i]->fwdto;  //compute current direct trust
                                    trustFile<<"direct trust:"<< it->second->Dtrust<<endl;
                                    if(it->second->Dtrust > 1)
                                        it->second->Dtrust = 1;
                                    if( it->second->Dtrust < trustThrsh )
                                        it->second->Dtrust = trustThrsh;
                                   // found2 = true;
                                }
                            break;
                        }
                        else if(myIp->second[i]->fwdto != 0 && it->second->Ttrust != -1)
                        {
                            trustFile<<"more relationship!"<<endl;
                            for(unsigned int j=0 ; j<neiIp->second.size();j++)
                               if(ManetAddress(neiIp->second[j]->neiNode) == myIp->first)
                               {
                                   trustFile<<"number of packets forwarded to neigh:"<<myIp->second[i]->fwdto<<endl;
                                   trustFile<<"number of packets forwarded by neigh:"<<neiIp->second[j]->fwded<<endl;
                                   it->second->Dtrust = (double)(neiIp->second[j]->fwded)/myIp->second[i]->fwdto;  //compute current direct trust
                                   trustFile<<"direct trust:"<< it->second->Dtrust<<endl;
                                   if(it->second->Dtrust > 1)
                                   {
                                     ///////// it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(floor(it->second->Dtrust))/it->second->beforFwd );
                                      it->second->Dtrust = 1;
                                   }
                                   found = true;
                               }
                            if(found == false)
                            {
                                //direct trust ro kam konim
                                it->second->Dtrust = 0;
                                trustFile<<"the node did not forward the packet \n";
                                trustFile<<"direct trust"<<it->second->Dtrust<<endl;
                            }
                            break;
                        }

                    }
                }
                if(noRelation == true)
                    if (it->second->Ttrust == -1)
                    {
                        trustFile<<"the node had not relationship with "<<it->first<<" at "<<simTime()<<endl;
                        continue;
                    }
                if(foundFlag == false)
                {
                    trustFile<<"the node had not relationship with "<<it->first<<" in this period of time, at "<<simTime()<<endl;
                    continue;
                }
                nei_addr.S_addr = it->first;
                it->second->Itrust = Itrust_compute(nei_addr);
                trustFile<<"direct trust about "<<it->first<<" is "<<it->second->Dtrust<<" at "<<simTime()<<endl;
                trustFile<<"Indirect trust about "<<it->first<<" is "<<it->second->Itrust<<endl;
                current_trust = Ctrust_compute(it->second->Dtrust, it->second->Itrust);    //compute current trust based on direct and indirect trust
                trustFile<<"current trust: "<<current_trust<<endl;
                trustFile<<"total trust before:"<<it->second->Ttrust<<endl;
                if(it->second->Ttrust == -1)
                    it->second->Ttrust = current_trust;
                else
                    it->second->Ttrust = Ttrust_compute(current_trust, it->second->Ttrust);    //compute total trust based on current and history trust

                /* determine trustworthiness of the node*/
                trustFile<<"total trust after: "<<it->second->Ttrust<<endl;
                AodvRtTableMap::iterator it2 = aodvRtTableMap.find(it->first);
                if (it2!=aodvRtTableMap.end() && it->second->Ttrust >= trustThrsh)
                {
                    it->second->trusted = true;
                    if(it2!=aodvRtTableMap.end())
                        it2->second->trusted = true;
                }
                else
                {
                    it->second->trusted = false;
                     if(it2!=aodvRtTableMap.end())
                         it2->second->trusted = false;
                }
            //}
        //}
    }
    return;
}


/*                //set direct trust
                if(Nei->second->forwardTo == 0 && Nei->second->Ttrust == -1)    //if the node had not relationship yet, ignore the trust update
                {
                    trustFile<<"the node had not relationship with "<<it->first<<" yet."<<endl;
                    continue;
                }
                if(Nei->second->forwardTo !=0 && Nei->second->Ttrust == -1)  //if node had relationship with the neighbor
                {
                    Nei->second->Dtrust = (double)(Nei->second->forwarded)/Nei->second->forwardTo;  //compute current direct trust
                    if( Nei->second->Dtrust < trustThrsh )
                        Nei->second->Dtrust = trustThrsh;
                    if( Nei->second->Dtrust > 1 )
                        Nei->second->Dtrust = 1;
                }
                else if(Nei->second->forwardTo !=0 && Nei->second->Ttrust != -1)
                {
                    Nei->second->Dtrust = (double)(Nei->second->forwarded)/Nei->second->forwardTo;  //compute current direct trust
                    if( Nei->second->Dtrust > 1 )
                        Nei->second->Dtrust = 1;
                }
                trustFile<<"forwarded:"<<Nei->second->forwarded<<" forwardTo:"<<Nei->second->forwardTo<<endl;
                //trustFile<<"direct trust:"<<it->second->Dtrust<<endl;
                Nei->second->Itrust = Itrust_compute(nei_addr);
                trustFile<<"direct trust about "<<it->first<<" is "<<Nei->second->Dtrust<<" at "<<simTime()<<endl;
                trustFile<<"Indirect trust about "<<it->first<<" is "<<Nei->second->Itrust<<endl;
                current_trust = Ctrust_compute(Nei->second->Dtrust, Nei->second->Itrust);    //compute current trust based on direct and indirect trust
                trustFile<<"current trust: "<<current_trust<<endl;
                trustFile<<"total trust before:"<<Nei->second->Ttrust<<endl;
                if(Nei->second->Ttrust == -1)
                {
                    if( current_trust != -1)
                        Nei->second->Ttrust = current_trust;
                }
                else
                {
                    if(current_trust != -1)
                        Nei->second->Ttrust = Ttrust_compute(current_trust, Nei->second->Ttrust);    //compute total trust based on current and history trust
                }
                 determine trustworthiness of the node
                trustFile<<"total trust after: "<<Nei->second->Ttrust<<endl;
                if (Nei->second->Ttrust >= trustThrsh)
                {
                    Nei->second->trusted = true;
                    it->second->trusted = true;
                }
                else
                {
                    Nei->second->trusted = false;
                    it->second->trusted = false;
                }
                reset the field of receive and forward
                Nei->second->forwardTo = 0;
                Nei->second->forwarded = 0;
                Nei->second->lastUpdate = simTime();
            }
            else
                trustFile<<"error! neighbor is not in neighbor table"<<endl;
        }
        trustFile<<endl;
            AodvRecomTableMap::iterator it2 = aodvRecomTableMap.find(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr);
            for(unsigned i=0; i<it2->second.size();i++)
            {
                if(it2->second[i]->objNode == it->first)
                {
                    if(it2->second[i]->trust == -1)
                    {
                        trustFile<<"the node had not interaction with the neighbor"<<endl;
                        //it->second->Dtrust = -1;
                        continue;
                    }
                    else
                        it->second->Dtrust = it2->second[i]->trust;
                }
            }
            it->second->Itrust = Itrust_compute(nei_addr);
            trustFile<<"direct trust about "<<it->first<<" is "<<it->second->Dtrust<<" at "<<simTime()<<endl;
            trustFile<<"Indirect trust about "<<it->first<<" is "<<it->second->Itrust<<endl;
            current_trust = Ctrust_compute(it->second->Dtrust, it->second->Itrust);    //compute current trust based on direct and indirect trust
            trustFile<<"current trust: "<<current_trust<<endl;
            if(it->second->Ttrust == -1)
            {
                if( current_trust != -1)
                    it->second->Ttrust = current_trust;
            }
            else
            {
                if(current_trust != -1)
                    it->second->Ttrust = Ttrust_compute(current_trust, it->second->Ttrust);    //compute total trust based on current and history trust
            }
             determine trustworthiness of the node
            trustFile<<"total trust: "<<it->second->Ttrust<<endl;
            if (it->second->Ttrust >= trustThrsh)
                it->second->trusted = true;
            else
                it->second->trusted = false;
            reset the field of receive and forward
            it->second->forwardTo = 0;
            it->second->forwarded = 0;
            it->second->lastUpdate = simTime();
        }
    }
    trustFile<<endl;
    trustFile.close();
    return;
}*/

double NS_CLASS Ctrust_compute(double Dt, double Int)  //if the difference of Dt and Rt is high, be nazare recommender shak konim
{
    double trust = 0;
    if(Dt==-1 && Int==-1)
        return -1;
    if(Dt==-1)
    {
        if(Int < trustThrsh)
            return trustThrsh;
        else
            return Int;
    }
    if(Int==-1)
        return Dt;
    else
    {
        trust = (double)(dTrustFactor* Dt + ((1 - dTrustFactor)* Int));
        return trust;
    }
}

double NS_CLASS Ttrust_compute(double Ctt, double Htt)   // idea:trust kamkam be dast miad va be sor'at az bein mire
{
    double trust = 0;
    trust = (double)((curTrustFactor * Htt) + ((1 - curTrustFactor)* Ctt));
    return trust;
}

double NS_CLASS Itrust_compute(struct in_addr nei_addr)
{
    ManetAddress nei = nei_addr.S_addr;
    double Itrust=0, counter=0;
    std::fstream trustFile;
    trustFile.open("Trust.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    for(AodvRecomTableMap::iterator it2=aodvRecomTableMap.begin(); it2!=aodvRecomTableMap.end(); it2++)
        {
            trustFile<<"vector of:"<<it2->first<<endl;
            for(unsigned i=0; i<it2->second.size(); i++)
            {
                trustFile<<it2->second[i]->objNode<<" trust: "<<it2->second[i]->trust<<endl;
            }
            trustFile<<"\n\n";

        }
    for(AodvRtTableMap::iterator it=aodvRtTableMap.begin(); it!=aodvRtTableMap.end(); it++)  //search for recommenders
    {
        if(it->first == it->second->next_hop.S_addr)
        {
            AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it->first);
            if(checkNei != aodvNeiTableMap.end() && it->first != nei)
            {
                AodvRecomTableMap::iterator it2 = aodvRecomTableMap.find(it->first);
                for(unsigned i=0; i<it2->second.size(); i++)
                {
                    if( it2->second[i]->objNode == nei && it2->second[i]->is_nei == true && it2->second[i]->trust != -1)
                    {
                        Itrust = Itrust + it2->second[i]->trust;
                        counter++;
                    }
                }
            }
        }
    }
    if(counter == 0)
        return -1;  //first it was 0.5, changed to -1. neighbors do not have any idea
    Itrust = (double)(Itrust)/counter;
    return Itrust;
}

void NS_CLASS nei_table_update(struct in_addr nei_addr, simtime_t delay, double fVal, bool is_nei)
{
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
    it->second->nei_now = is_nei;
    it->second->delay = delay;
    it->second->futureValue = fVal;
    return;
}
