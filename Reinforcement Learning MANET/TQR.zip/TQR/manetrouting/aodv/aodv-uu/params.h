/*****************************************************************************
 *
 * Copyright (C) 2001 Uppsala University & Ericsson AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Erik Nordstr�m, <erik.nordstrom@it.uu.se>
 *
 *
 *****************************************************************************/
#ifndef _PARAMS_H
#define _PARAMS_H

#include "defs_aodv.h"

#define K_PARAM   5

#define tUpdateTime 5.0001 //trust update time interval
#define rUpdateTime 5.00001  //position map update time interval
#define dUpdateTime 5.00001  //information exchange time interval
#define etUpdateTime 0.51   //etx calculation time interval
#define updateResult 25
#define etIUpdateTime 0.5
#define iUpdateTime 1
#define max_critic  5  //maximum criticality of the mission
#define min_critic  1
//#define epsilon    //used to compute exploration rate in rreq_forward (selecting next hop)
//#define epsilon2  //used in computation of expected future reward in rrep_create
#define trustThrsh 0.5  //threshold for trustworthiness and untrustworthiness
#define recomThrsh 0.5  //threshold for trustworthiness of the recommender
//#define e 2.72          //nepper number for decay function
#define dTrustFactor 0.6 //importance factor of direct trust in current trust computation
#define curTrustFactor 0.6  //importance factor of current trust
#define eta 0.00008          //transmission delay used in calculating sigma

/* Dynamic configuration values. Default numbers are for HELLO messages. */
#define ACTIVE_ROUTE_TIMEOUT active_route_timeout
#define TTL_START ttl_start
#define DELETE_PERIOD delete_period
#define CRITIC_THRSH (max_critic + min_critic)/2


/* Settings for Link Layer Feedback */
#define ACTIVE_ROUTE_TIMEOUT_LLF    1000
#define TTL_START_LLF               1
#define DELETE_PERIOD_LLF           ACTIVE_ROUTE_TIMEOUT_LLF

/* Settings for HELLO messages */
#define ACTIVE_ROUTE_TIMEOUT_HELLO  3000
#define TTL_START_HELLO             35 //2
#define DELETE_PERIOD_HELLO         K_PARAM * max(ACTIVE_ROUTE_TIMEOUT, ALLOWED_HELLO_LOSS * HELLO_INTERVAL)

/* Non runtime modifiable settings */
#define ALLOWED_HELLO_LOSS      2
/* If expanding ring search is used, BLACKLIST_TIMEOUT should be?: */
#define BLACKLIST_TIMEOUT       RREQ_RETRIES * NET_TRAVERSAL_TIME + (TTL_THRESHOLD - TTL_START)/TTL_INCREMENT + 1 + RREQ_RETRIES
#define HELLO_INTERVAL          1
#define LOCAL_ADD_TTL           2
#define MAX_REPAIR_TTL          3 * NET_DIAMETER / 10
#define MY_ROUTE_TIMEOUT        2 * ACTIVE_ROUTE_TIMEOUT
#define NET_DIAMETER            35
#define NET_TRAVERSAL_TIME      2 * NODE_TRAVERSAL_TIME * NET_DIAMETER
#define NEXT_HOP_WAIT           NODE_TRAVERSAL_TIME + 10
#define NODE_TRAVERSAL_TIME     100
#define PATH_DISCOVERY_TIME     2 * NET_TRAVERSAL_TIME
#define RERR_RATELIMIT          10
#define RING_TRAVERSAL_TIME     2 * NODE_TRAVERSAL_TIME * (TTL_VALUE + TIMEOUT_BUFFER)
#define RREQ_RETRIES            2
#define RREQ_RATELIMIT          10
#define TIMEOUT_BUFFER          2
#define TTL_INCREMENT           2
#define TTL_THRESHOLD           7

#ifndef NS_PORT
/* Dynamic configuration values */
extern int active_route_timeout;
extern int ttl_start;
extern int delete_period;
#endif

#endif              /* _PARAMS_H */
