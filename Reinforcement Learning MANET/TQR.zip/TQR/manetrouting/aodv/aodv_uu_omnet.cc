/*****************************************************************************
 *
 * Copyright (C) 2002 Uppsala University.
 * Copyright (C) 2006 Malaga University.
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Bj�n Wiberg <bjorn.wiberg@home.se>
 *          Erik Nordstr� <erik.nordstrom@it.uu.se>
 * Authors: Alfonso Ariza Quintana.<aarizaq@uma.ea>
 *
 *****************************************************************************/

#include <string.h>
#include <assert.h>


#include "UDPPacket.h"
#include "IPv4ControlInfo.h"
#include "IPv6ControlInfo.h"
#include "ICMPMessage_m.h"
#include "ICMPAccess.h"
#include "NotifierConsts.h"
#include "IPv4Datagram.h"
#include "IPv4InterfaceData.h"

#include "ProtocolMap.h"
#include "IPv4Address.h"
#include "IPvXAddress.h"
#include "ControlManetRouting_m.h"
#include "Ieee802Ctrl_m.h"
#include "aodv_uu_omnet.h"

const int UDP_HEADER_BYTES = 8;
typedef std::vector<IPv4Address> IPAddressVector;

Define_Module(AODVUU);

/* Constructor for the AODVUU routing agent */

bool AODVUU::log_file_fd_init=false;
int AODVUU::log_file_fd = -1;

#ifdef AODV_GLOBAL_STATISTISTIC
bool AODVUU::iswrite = false;
int AODVUU::totalSend=0;
int AODVUU::totalRreqSend=0;
int AODVUU::totalRreqRec=0;
int AODVUU::totalRrepSend=0;
int AODVUU::totalRrepRec=0;
int AODVUU::totalRrepAckSend=0;
int AODVUU::totalRrepAckRec=0;
int AODVUU::totalRerrSend=0;
int AODVUU::totalRerrRec=0;
int AODVUU::totalLocalRep =0;
double AODVUU:: energyConsumed = 0;
#endif
std::map<ManetAddress,u_int32_t *> AODVUU::mapSeqNum;

typedef std::vector<struct RecomList *> RecomVectorG;
RecomVectorG recomvectorG;

typedef std::map<ManetAddress, RecomVectorG> RecomMap;
RecomMap recommap;

typedef std::vector<struct etxList *> EtxVector;
EtxVector etxvector;

typedef std::map<ManetAddress, EtxVector> EtxMap;
EtxMap etxmap;

//used for mapping datas from ip layer to network layer
//typedef std::vector<struct neighbors *> TempVec;
typedef std::map< ManetAddress , std::vector<struct neighbors *> > TempMap;
TempMap tempmap;

simtime_t times;
simtime_t etimes;
simtime_t temptimes;


void NS_CLASS initialize(int stage)
{
     /*
       Enable usage of some of the configuration variables from Tcl.

       Note: Do NOT change the values of these variables in the constructor
       after binding them! The desired default values should be set in
       ~ns/tcl/lib/ns-default.tcl instead.
     */
    if (stage==4)
    {

        RERR_UDEST_SIZE = 4+getAddressSize();
        RERR_SIZE = 8+getAddressSize();
        RREP_SIZE = (getAddressSize()*2)+12;
        RREQ_SIZE = 16+(getAddressSize()*2);


#ifndef AODV_GLOBAL_STATISTISTIC
        iswrite = false;
        totalSend=0;
        totalRreqSend=0;
        totalRreqRec=0;
        totalRrepSend=0;
        totalRrepRec=0;
        totalRrepAckSend=0;
        totalRrepAckRec=0;
        totalRerrSend=0;
        totalRerrRec=0;
        totalLocalRep=0;
#endif
        log_to_file = 0;
        hello_jittering = 0;
        optimized_hellos = 0;
        expanding_ring_search = 0;
        local_repair = 0;
        debug=0;
        rreq_gratuitous =0;

        //sendMessageEvent = new cMessage();

        if ((bool)par("log_to_file"))
            log_to_file = 1;

        if ((bool) par("hello_jittering"))
            hello_jittering = 1;

        if ((bool)par("optimized_hellos"))
            optimized_hellos  = 1;

        if ((bool)par("expanding_ring_search"))
            expanding_ring_search = 1;

        if ((bool) par("local_repair"))
            local_repair = 1;

        if ((bool)par("rreq_gratuitous"))
            rreq_gratuitous = 1;

        if ((bool)par("debug"))
            debug = 1;

        if (hasPar("RreqDelayInReception"))
            storeRreq = par(("RreqDelayInReception")).boolValue();
        checkRrep = false;

        useIndex = par("UseIndex");
        unidir_hack = (int) par("unidir_hack");

        receive_n_hellos    = (int) par("receive_n_hellos");
        wait_on_reboot = (int) par ("wait_on_reboot");
        rt_log_interval = (int) par("rt_log_interval"); // Note: in milliseconds!
        ratelimit = (int) par("ratelimit");
        llfeedback = 0;
        if (par("llfeedback"))
            llfeedback = 1;
        internet_gw_mode = (int) par("internet_gw_mode");
        gateWayAddress = new IPv4Address(par("internet_gw_address").stringValue());

        if (llfeedback)
        {
            active_route_timeout = ACTIVE_ROUTE_TIMEOUT_LLF;
            ttl_start = TTL_START_LLF;
            delete_period =  DELETE_PERIOD_LLF;
        }
        else
        {
            active_route_timeout = (int) par("active_timeout");// ACTIVE_ROUTE_TIMEOUT_HELLO;
            ttl_start = TTL_START_HELLO;
            delete_period = DELETE_PERIOD_HELLO;
        }

        if (hasPar("avoidDupRREP") && llfeedback)
            checkRrep = par("avoidDupRREP").boolValue();

        /* Initialize common manet routing protocol structures */
        registerRoutingModule();
        if (llfeedback)
            linkLayerFeeback();

        if (hasPar("fullPromis"))
        {
            if (par("fullPromis").boolValue())
            {
                linkFullPromiscuous();
            }
        }

        /* From main.c */
        progname = strdup("AODV-UU");
        /* From debug.c */
        /* Note: log_nmsgs was never used anywhere */
        log_nmsgs = 0;
        log_rt_fd = -1;
#ifndef  _WIN32

        if (debug && !log_file_fd_init)
        {
            log_file_fd = -1;
            openlog("aodv-uu ",0,LOG_USER);
            log_init();
            log_file_fd_init=true;
        }
#else
        debug = 0;
#endif
        /* Set host parameters */
        memset(&this_host, 0, sizeof(struct host_info));
        memset(dev_indices, 0, sizeof(unsigned int) * MAX_NR_INTERFACES);
        this_host.seqno = 1;
        this_host.rreq_id = 0;
        this_host.nif = 1;


        for (int i = 0; i < MAX_NR_INTERFACES; i++)
            DEV_NR(i).enabled=0;

        for (int i = 0; i <getNumInterfaces(); i++)
        {
            DEV_NR(i).ifindex = i;
            dev_indices[i] = i;
            strcpy(DEV_NR(i).ifname, getInterfaceEntry(i)->getName());
            if (!isInMacLayer())
            {
                DEV_NR(i).netmask.s_addr =
                    ManetAddress(getInterfaceEntry(i)->ipv4Data()->getIPAddress().getNetworkMask());
                DEV_NR(i).ipaddr.s_addr =
                        ManetAddress(getInterfaceEntry(i)->ipv4Data()->getIPAddress());
            }
            else
            {
                DEV_NR(i).netmask.s_addr = ManetAddress(MACAddress::BROADCAST_ADDRESS);
                DEV_NR(i).ipaddr.s_addr = ManetAddress(getInterfaceEntry(i)->getMacAddress());

            }
            if (getInterfaceEntry(i)->isLoopback())
                continue;
            if (isInMacLayer())
            {
                mapSeqNum[DEV_NR(i).ipaddr.s_addr] = &this_host.seqno;
            }
        }
        /* Set network interface parameters */
        for (int i=0; i < getNumWlanInterfaces(); i++)
        {
            DEV_NR(getWlanInterfaceIndex(i)).enabled = 1;
            DEV_NR(getWlanInterfaceIndex(i)).sock = -1;
            DEV_NR(getWlanInterfaceIndex(i)).broadcast.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));
        }

        NS_DEV_NR = getWlanInterfaceIndexByAddress();
        NS_IFINDEX = getWlanInterfaceIndexByAddress();
#ifndef AODV_USE_STL
        list_t *lista_ptr;
        lista_ptr=&rreq_records;
        INIT_LIST_HEAD(&rreq_records);
        lista_ptr=&rreq_blacklist;
        INIT_LIST_HEAD(&rreq_blacklist);
        lista_ptr=&seekhead;
        INIT_LIST_HEAD(&seekhead);

        lista_ptr=&TQ;
        INIT_LIST_HEAD(&TQ);
#endif
        /* Initialize data structures */
        worb_timer.data = NULL;
        worb_timer.used = 0;
        hello_timer.data = NULL;
        hello_timer.used = 0;
        rt_log_timer.data = NULL;
        rt_log_timer.used = 0;
        isRoot = par("isRoot");
        costStatic = par("costStatic");
        costMobile = par("costMobile");
        useHover = par("useHover");
        proactive_rreq_timeout= par("proactiveRreqTimeout").longValue();

        if (isRoot)
        {
            timer_init(&proactive_rreq_timer,&NS_CLASS rreq_proactive, NULL);
            timer_set_timeout(&proactive_rreq_timer, par("startRreqProactive").longValue());
        }

        propagateProactive = par("propagateProactive");
        strcpy(nodeName,getParentModule()->getParentModule()->getFullName());
        aodv_socket_init();
        rt_table_init();
        packet_queue_init();
        startAODVUUAgent();
        nei_table_init();

        recomUpdate = new cMessage("recomUpdate");
        scheduleAt(simTime()+ rUpdateTime, recomUpdate);

        trustUpdate = new cMessage("trustUpdate");
        //scheduleAt(simTime()+ tUpdateTime, trustUpdate);

        infoUpdate = new cMessage("infoUpdate");
        scheduleAt(simTime()+ iUpdateTime, infoUpdate);

        etxUpdate = new cMessage("etxUpdate");
        scheduleAt(simTime()+ etUpdateTime, etxUpdate);

        etxInfoUpdate = new cMessage("etxInfoUpdate");
        scheduleAt(simTime() + etIUpdateTime, etxInfoUpdate);

        update = new cMessage("update");
       scheduleAt(simTime() + updateResult, update);


        //directTrustUpdate = new cMessage("directTrustUpdate");
        //scheduleAt(simTime()+ dUpdateTime, directTrustUpdate);

        BasicBattery  *bt = BatteryAccess().get();
        maxCapacity = bt->GetEnergy();
        energyThrsh = (double)(maxCapacity) / 5.0;

        count_overhead = 0;
        destination = ManetAddress::ZERO;


        is_init=true;

        times=rUpdateTime;
        etimes=etIUpdateTime;
        temptimes=rUpdateTime;
        // Initialize the timer
        scheduleNextEvent();

        EV << "Aodv active"<< "\n";
    }
}

/* Destructor for the AODV-UU routing agent */
NS_CLASS ~AODVUU()
{
#ifdef AODV_USE_STL_RT
    while (!aodvRtTableMap.empty())
    {
        free (aodvRtTableMap.begin()->second);
        aodvRtTableMap.erase(aodvRtTableMap.begin());
    }
#else
    list_t *tmp = NULL, *pos = NULL;
    for (int i = 0; i < RT_TABLESIZE; i++)
    {
        list_foreach_safe(pos, tmp, &rt_tbl.tbl[i])
        {
            rt_table_t *rt = (rt_table_t *) pos;
            list_detach(&rt->l);
            precursor_list_destroy(rt);
            free(rt);
        }
    }
#endif
#ifndef AODV_USE_STL
    while (!list_empty(&rreq_records))
    {
        pos = list_first(&rreq_records);
        list_detach(pos);
        if (pos) free(pos);
    }

    while (!list_empty(&rreq_blacklist))
    {
        pos = list_first(&rreq_blacklist);
        list_detach(pos);
        if (pos) free(pos);
    }

    while (!list_empty(&seekhead))
    {
        pos = list_first(&seekhead);
        list_detach(pos);
        if (pos) free(pos);
    }
#else
    while (!rreq_records.empty())
    {
        free (rreq_records.back());
        rreq_records.pop_back();
    }

    while (!rreq_blacklist.empty())
    {
        free (rreq_blacklist.begin()->second);
        rreq_blacklist.erase(rreq_blacklist.begin());
    }

    while (!seekhead.empty())
    {
        delete (seekhead.begin()->second);
        seekhead.erase(seekhead.begin());
    }
#endif
    packet_queue_destroy();
    cancelAndDelete(sendMessageEvent);
    log_cleanup();
    delete gateWayAddress;
}

/*
  Moves pending packets with a certain next hop from the interface
  queue to the packet buffer or simply drops it.
*/

/* Called for packets whose delivery fails at the link layer */
void NS_CLASS packetFailed(IPv4Datagram *dgram)
{
    rt_table_t *rt_next_hop, *rt;
    struct in_addr dest_addr, src_addr, next_hop;

    src_addr.s_addr = ManetAddress(dgram->getSrcAddress());
    dest_addr.s_addr = ManetAddress(dgram->getDestAddress());


    DEBUG(LOG_DEBUG, 0, "Got failure callback");
    /* We don't care about link failures for broadcast or non-data packets */
    if (dgram->getDestAddress().getInt() == IP_BROADCAST ||
            dgram->getDestAddress().getInt() == AODV_BROADCAST)
    {
        DEBUG(LOG_DEBUG, 0, "Ignoring callback");
        scheduleNextEvent();
        return;
    }


    DEBUG(LOG_DEBUG, 0, "LINK FAILURE for next_hop=%s dest=%s ",ip_to_str(next_hop), ip_to_str(dest_addr));

    if (seek_list_find(dest_addr))
    {
        DEBUG(LOG_DEBUG, 0, "Ongoing route discovery, buffering packet...");
        packet_queue_add((IPv4Datagram *)dgram->dup(), dest_addr);
        scheduleNextEvent();
        return;
    }


    rt = rt_table_find(dest_addr);

    if (!rt || rt->state == INVALID)
    {
        scheduleNextEvent();
        return;
    }
    next_hop.s_addr = rt->next_hop.s_addr;
    rt_next_hop = rt_table_find(next_hop);

    if (!rt_next_hop || rt_next_hop->state == INVALID)
    {
        scheduleNextEvent();
        return;
    }

    /* Do local repair? */
    if (local_repair && rt->hcnt <= MAX_REPAIR_TTL)
        /* && ch->num_forwards() > rt->hcnt */
    {
        /* Buffer the current packet */
        packet_queue_add((IPv4Datagram *) dgram->dup(), dest_addr);

        // In omnet++ it's not possible to access to the mac queue
        //  /* Buffer pending packets from interface queue */
        //  interfaceQueue((nsaddr_t) next_hop.s_addr, IFQ_BUFFER);
        //  /* Mark the route to be repaired */
        rt_next_hop->flags |= RT_REPAIR;
        neighbor_link_break(rt_next_hop);
        rreq_local_repair(rt, src_addr, NULL);
    }
    else
    {
        /* No local repair - just force timeout of link and drop packets */
        neighbor_link_break(rt_next_hop);
// In omnet++ it's not possible to access to the mac queue
//  interfaceQueue((nsaddr_t) next_hop.s_addr, IFQ_DROP);
    }
    scheduleNextEvent();
}


/* Called for packets whose delivery fails at the link layer */
void NS_CLASS packetFailedMac(Ieee80211DataFrame *dgram)
{
    rt_table_t *rt_next_hop, *rt;
    struct in_addr dest_addr, src_addr, next_hop;
    if (dgram->getReceiverAddress().isBroadcast())
    {
        scheduleNextEvent();
        return;
    }

    src_addr.s_addr = ManetAddress(dgram->getAddress3());
    dest_addr.s_addr = ManetAddress(dgram->getAddress4());
    if (seek_list_find(dest_addr))
    {
        DEBUG(LOG_DEBUG, 0, "Ongoing route discovery, buffering packet...");
        packet_queue_add(dgram->dup(), dest_addr);
        scheduleNextEvent();
        return;
    }

    next_hop.s_addr = ManetAddress(dgram->getReceiverAddress());
    if (isStaticNode() && getCollaborativeProtocol())
    {
        ManetAddress next;
        int iface;
        double cost;
        if (getCollaborativeProtocol()->getNextHop(next_hop.s_addr, next, iface, cost))
            if(next == next_hop.s_addr)
            {
                scheduleNextEvent();
                return; // both nodes are static, do nothing
            }
    }

    rt = rt_table_find(dest_addr);

    if (!rt || rt->state == INVALID)
    {
        scheduleNextEvent();
        return;
    }
    next_hop.s_addr = rt->next_hop.s_addr;
    rt_next_hop = rt_table_find(next_hop);

    if (!rt_next_hop || rt_next_hop->state == INVALID)
    {
        scheduleNextEvent();
        return;
    }

    /* Do local repair? */
    if (local_repair && rt->hcnt <= MAX_REPAIR_TTL)
        /* && ch->num_forwards() > rt->hcnt */
    {
        /* Buffer the current packet */
        packet_queue_add(dgram->dup(), dest_addr);

        // In omnet++ it's not possible to access to the mac queue
        //  /* Buffer pending packets from interface queue */
        //  interfaceQueue((nsaddr_t) next_hop.s_addr, IFQ_BUFFER);
        //  /* Mark the route to be repaired */
        rt_next_hop->flags |= RT_REPAIR;
        neighbor_link_break(rt_next_hop);
        rreq_local_repair(rt, src_addr, NULL);
    }
    else
    {
        /* No local repair - just force timeout of link and drop packets */
        neighbor_link_break(rt_next_hop);
// In omnet++ it's not possible to access to the mac queue
//  interfaceQueue((nsaddr_t) next_hop.s_addr, IFQ_DROP);
    }
    scheduleNextEvent();
}



/* Entry-level packet reception */
void NS_CLASS handleMessage (cMessage *msg)
{
    AODV_msg *aodvMsg=NULL;
    IPv4Datagram * ipDgram=NULL;
    UDPPacket * udpPacket=NULL;
    struct in_addr cur_src;
   // std::fstream mesFile;
    double random=0;
    //mesFile.open("handleMessage.txt", std::fstream::in | std::fstream::out | std::fstream::app);

   /* std::fstream recFile;
    recFile.open("Recommenders.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    std::fstream rFile;
    rFile.open("received_hellos.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    std::fstream testFile;
    testFile.open("testFile.txt", std::fstream::in | std::fstream::out | std::fstream::app);*/

    std::fstream infoFile, overFile, ecFile, malFile, neiFile, nei2File, testFile;
    //infoFile.open("Information.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    std::string address;
    std::string address2;
    std::fstream attFile,hFile, att2File, trustFile2;
    //hFile.open("handleMessage.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    //testFile.open("test.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    trustFile2.open("trustUpdate.txt", std::fstream::in | std::fstream::out | std::fstream::app);

  //  testFile<<"Entering handleMessage"<<endl;

    cMessage *msg_aux;
    struct in_addr src_addr;
    struct in_addr dest_addr;

    if (!isNodeOperational())
    {
        delete msg;
        return;
    }

    if (is_init==false)
        opp_error ("Aodv has not been initialized ");

    if(msg==update)
    {
        ecFile.open("EnergyConsumed.txt", std::fstream::in | std::fstream::out | std::fstream::app);
        //malFile.open("MaliciousNodes.txt", std::fstream::in | std::fstream::out | std::fstream::app);
        overFile.open("ControlPackets.txt", std::fstream::in | std::fstream::out | std::fstream::app);
        neiFile.open("DetectionRatio.txt", std::fstream::in | std::fstream::out | std::fstream::app);
        overFile<<"time "<<simTime()<<"\t"<<count_overhead<<endl;
        int malCount=0, normCount=0, malCount2=0, detectedM=0, detectedN=0;
        bool malFlag = false;

        simtime_t t = simTime();
        BasicBattery *bt = BatteryAccess().get();
        energyConsumed = maxCapacity - bt->GetEnergy();
        ecFile<<"time "<<simTime()<<"\t"<<energyConsumed<<endl;

        //detection ratio
        for (AodvNeiTableMap::iterator it2 = aodvNeiTableMap.begin(); it2 != aodvNeiTableMap.end(); it2++)
        {
            attFile.open("blackAttack.txt", std::fstream::in | std::fstream::out | std::fstream::app);
            while(!attFile.eof())
            {
                std::getline(attFile,address);
                //neiFile<<address<<"  "<<it2->first.str()<<endl;
                if(address == it2->first.str())
                {
                    //neiFile<<"same"<<endl;
                    if(it2->second->trusted == false)
                    {
                        //neiFile<<"blackattack"<<it2->second->trusted<<endl;
                        detectedM++;
                        //neiFile<<detectedM<<endl;
                    }
                    malCount++;
                    //neiFile<<malCount<<endl;
                    malFlag=true;
                }
            }

            att2File.open("grayAttack.txt", std::fstream::in);
            while(!att2File.eof())
            {
                std::getline(att2File,address2);
               // neiFile<<address2<<"  "<<it2->first.str()<<endl;
                if(address2 == it2->first.str())
                {
                    //neiFile<<"same"<<endl;
                    if(it2->second->trusted == false)
                    {
                        //neiFile<<"grayattack"<<it2->second->trusted<<endl;
                        detectedM++;
                        //neiFile<<detectedM<<endl;
                    }
                    malCount++;
                    //neiFile<<malCount<<endl;
                    malFlag=true;
                }

            }
            if(malFlag == false)
            {
                normCount++;
                if(it2->second->trusted == true)
                {
                    //neiFile<<"normal"<<it2->second->trusted<<endl;
                    detectedN++;
                    //neiFile<<detectedN<<endl;
                }
            }
            malFlag = false;
            attFile.close();
            att2File.close();
        }
        neiFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<":"<<endl;
        neiFile<<"malicious:\t"<<(double)(detectedM)/malCount<<endl;
        neiFile<<"normal:\t"<<(double)(detectedN)/(normCount)<<endl;


        /*malFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<":"<<endl;
        for (AodvNeiTableMap::iterator it2 = aodvNeiTableMap.begin(); it2 != aodvNeiTableMap.end(); it2++)
        {
            if(it2->second->trusted == false)
            {
                attFile.open("blackAttack.txt", std::fstream::in | std::fstream::out | std::fstream::app);
                while(!attFile.eof())
                {
                    std::getline(attFile,address);
                    if(address == it2->first.str())
                    {
                        malCount++;
                        malFlag = true;
                    }
                }
                //apply gray attack
                att2File.open("grayAttack.txt", std::fstream::in);
                while(!att2File.eof())
                {
                    std::getline(att2File,address2);
                    if(address2 == it2->first.str())
                    {
                        malCount++;
                        malFlag = true;
                    }

                }
                if(malFlag == false)
                    normCount++;
                else
                    malFlag = false;
            }
        }
        malFile<<"normal:"<<normCount<<endl;
        malFile<<"malicious:"<<malCount<<endl;
        malFile<<endl;


        neiFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<":"<<endl;
        attFile.open("blackAttack.txt", std::fstream::in | std::fstream::out | std::fstream::app);
        while(!attFile.eof())
        {
            std::getline(attFile,address);
            for (AodvNeiTableMap::iterator it2 = aodvNeiTableMap.begin(); it2 != aodvNeiTableMap.end(); it2++)
                if(address == it2->first.str())
                    malCount2++;
        }
        //apply gray attack
        att2File.open("grayAttack.txt", std::fstream::in);
        while(!att2File.eof())
        {
            std::getline(att2File,address2);
            for (AodvNeiTableMap::iterator it2 = aodvNeiTableMap.begin(); it2 != aodvNeiTableMap.end(); it2++)
                if(address2 == it2->first.str())
                    malCount2++;

        }
        neiFile<<"malicious:"<<(double)(malCount)/malCount2<<endl;
        neiFile<<"normal:"<<(double)(aodvNeiTableMap.size() - (malCount2+normCount))/(aodvNeiTableMap.size() - malCount2)<<endl;
*/

        scheduleAt(simTime()+updateResult, update);
        return;
    }

    if( msg == etxInfoUpdate)
    {
        struct etxList * e;
       if(simTime() != etimes)
       {
           etimes=simTime();
           etxmap.clear();
       }
       for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
       {
           e=new etxList;
           e->neiNode = it->first;
           e->sent = it->second->hello_send;
           e->received = it->second->hello_rcvd;
           etxvector.push_back(e);
       }
       etxmap.insert(std::make_pair(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr,etxvector));
       etxvector.clear();
       scheduleAt(simTime()+etIUpdateTime, etxInfoUpdate);
       return;
    }
    if( msg == etxUpdate)
    {
        for (AodvRtTableMap::iterator it = aodvRtTableMap.begin(); it != aodvRtTableMap.end(); it++)    //for current neighbors
        {
            AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it->first);
            if(checkNei!=aodvNeiTableMap.end())
            {
                for(EtxMap::iterator it2 = etxmap.begin(); it2 != etxmap.end(); it2++)
                {
                    if(it2->first == it->first)
                    {
                        for(unsigned i=0; i<it2->second.size(); i++)
                        {
                            if( it2->second[i]->neiNode == DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr)
                            {
            //                    hFile<<it2->second[i]->received<<endl;
              //                  hFile<<it->second->hello_send<<endl;
                                if(checkNei->second->hello_send == 0 || it2->second[i]->received== 0)
                                    checkNei->second->etx = 5;
                                else
                                    checkNei->second->etx = 1.0 / ((double)(it2->second[i]->received) /checkNei->second->hello_send);
                                break;
                //                hFile<<it->second->etx<<endl;
                            }
                           // checkNei->second->etx = 5;
                        }
                    }
                }
                checkNei->second->hello_send = 0;
                checkNei->second->hello_rcvd = 0;
            }
        }
        scheduleAt(simTime()+etUpdateTime, etxUpdate);
        return;
    }
    if( msg == infoUpdate )
    {

       /* infoFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" at:"<<simTime()<<endl;
        for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
        {
            infoFile<<"forward to: "<<it->first<<"forwardTo:"<<it->second->forwardTo<<" forwarded: "<<it->second->forwarded<<endl;
        }
        infoFile<<"\n\n";*/
        scheduleAt(simTime()+iUpdateTime, infoUpdate);
        return;
    }
    if( msg == recomUpdate )
    {
        struct RecomList * r;
        //recFile<<"times: "<<times<<" simulation time: "<<simTime()<<endl;
        if(simTime() != times)
        {
            times=simTime();
            recommap.clear();
        }
        for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
        {
            r=new RecomList;
            AodvRtTableMap::iterator checkNei = aodvRtTableMap.find(it->first);
            if( checkNei!=aodvRtTableMap.end() && checkNei->first == checkNei->second->next_hop.S_addr )
                r->is_nei = true;
            else
                r->is_nei = false;
            //r->is_nei = it->second->nei_now;
            r->objNode = it->first;
            r->trust = it->second->Dtrust;
            r->lastTime = it->second->lastUpdate;
            recomvectorG.push_back(r);
        }
        recommap.insert(std::make_pair(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr,recomvectorG));
        recomvectorG.clear();

        //testFile<<"\n***********\n********** "<<simTime()<<"  "<<temptimes<<endl;
        if(simTime() != temptimes)
        {
            temptimes=simTime();
            //testFile<<"\n***********\n********** "<<simTime()<<"  "<<temptimes<<endl;
            tempmap.clear();
        }
        IPv4 obj;
        std::vector<struct neighbors *> tempvec;
        //tempvec = obj.getOwnVector(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr, tempvec);
        obj.getOwnVector(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr, tempvec);


        //obj.getOwnVector(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr);
/*        testFile<<simTime();*/
        //testFile<<"\ntempvec of: "<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" :\n";
        /*for(unsigned int i=0;i<tempvec.size();i++)
            testFile<<tempvec[i]->neiNode<<" : "<<tempvec[i]->fwded<<"  "<<tempvec[i]->fwdto<<endl;*/

        tempmap.insert(std::make_pair(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr,tempvec));

        //testFile<<"\nprinting tempmap:\n";
        /*for (TempMap::iterator it = tempmap.begin(); it != tempmap.end(); it++)
        {
            testFile<<it->first<<" : "<<endl;
            for(unsigned int i=0 ; i<it->second.size(); i++)
                testFile<<it->second[i]->neiNode<<"  "<<it->second[i]->fwded<<"   "<<it->second[i]->fwdto<<endl;
        }
*/

        scheduleAt(simTime()+rUpdateTime, recomUpdate);
        scheduleAt(simTime(), trustUpdate);
        return;

    }
    if( msg == directTrustUpdate)
    {
        double direct_trust;
        for (AodvRtTableMap::iterator it = aodvRtTableMap.begin(); it != aodvRtTableMap.end(); it++)
        {
            if(it->first == it->second->next_hop.S_addr)
            {
                direct_trust = 0;
                AodvNeiTableMap::iterator Nei = aodvNeiTableMap.find(it->first);
                if(Nei != aodvNeiTableMap.end())
                {
                    if(Nei->second->rcvd != 0)
                    {
                        direct_trust = (double)(Nei->second->forward) / Nei->second->rcvd;
                        if(direct_trust > 1)
                            direct_trust = 1;
                    }
                    else
                        //direct_trust = 0.5;  //uncertain node
                        direct_trust = -1;  //we can use this, instead, mohafeze karane!
                }
                else
                    direct_trust = -1;

                RecomMap::iterator it2 = recommap.find(it->first);
                for(unsigned i=0; i<it2->second.size();i++)
                    if(it2->second[i]->objNode == DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr)
                        it2->second[i]->trust=direct_trust;
                //}
                Nei->second->forward = 0;
                Nei->second->rcvd = 0;
               // it->second->hello_rcvd = 0;
               // it->second->hello_send = 0;
            }
        }
        scheduleAt(simTime()+dUpdateTime, directTrustUpdate);
        return;
    }
    if( msg == trustUpdate )
    {
        struct RecomList *r;
        aodvRecomTableMap.clear();
        /*for (RecomMap::iterator it = recommap.begin(); it != recommap.end(); it++)
        {
           recFile<<"node: "<<it->first<<endl;
            for(unsigned i3=0 ; i3<it->second.size(); i3++)
                recFile<<it->second[i3]->trust<<"   "<<it->second[i3]->objNode<<endl;
            recFile<<endl;
        }*/
        for (RecomMap::iterator it = recommap.begin(); it != recommap.end(); it++)
        {
            for(unsigned i=0 ; i<it->second.size(); i++)
            {
                r = new RecomList;
                r->is_nei = it->second[i]->is_nei;
                r->objNode = it->second[i]->objNode;
                r->trust = it->second[i]->trust;
                r->lastTime = it->second[i]->lastTime;
                recomvector.push_back(r);
            }
            aodvRecomTableMap.insert(std::make_pair(it->first,recomvector));
           /* for(unsigned i2=0 ; i2<recomvector.size(); i2++)
               recFile<<recomvector[i2]->objNode<<"\t"<<recomvector[i2]->trust<<endl;
            recFile<<endl;*/
            recomvector.clear();
        }
        ipmap.clear();
       // testFile<<" time: "<<simTime()<<endl;
        for (TempMap::iterator it = tempmap.begin(); it != tempmap.end(); it++)
        {
            ipvec.clear();
            ipvec = it->second;
            //testFile<<it->first<<" at "<<simTime()<<":\n";
            /*for(unsigned int i=0 ; i<it->second.size(); i++)
                testFile<<it->second[i]->neiNode<<"  "<<it->second[i]->fwded<<"   "<<it->second[i]->fwdto<<endl;
*/
            ipmap.insert(std::make_pair(it->first,ipvec));
            //ipmap.insert(std::make_pair(it->first,it->second));
        }
      //  recFile<<"enetring trust update"<<endl;
        trust_value_update();
        trustFile2<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" , time: "<<simTime()<<endl;
       for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
       {
           trustFile2<<it->first<<" : "<<it->second->Ttrust<<endl;
       }
       //scheduleAt(simTime()+tUpdateTime, trustUpdate);
       return;
/*        for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
        {
            it->second->hello_send = 0;
            it->second->hello_rcvd = 0;
        }*/
        //scheduleAt(simTime()+tUpdateTime, trustUpdate);
        return;
    }
    if (msg->isSelfMessage() && dynamic_cast<AODV_msg*> (msg))
    {
        DelayInfo * delayInfo = check_and_cast<DelayInfo *> (msg->removeControlInfo());
        RREP * rrep = dynamic_cast<RREP *> (msg);
        if (rrep)
        {
            if (isThisRrepPrevSent(msg))
            {
                delete msg;
                msg = NULL;
            }
        }
        if (msg)
            aodv_socket_send((AODV_msg *) msg, delayInfo->dst , delayInfo->len, delayInfo->ttl, delayInfo->dev,0);
        delete delayInfo;
        return;
    }
    else if (msg->isSelfMessage() && dynamic_cast<RREQProcessed*> (msg))
    {
        RREQProcessed* rreqList = dynamic_cast<RREQProcessed*> (msg);
        if (rreqList)
        {
            while (!rreqList->infoList.empty())
            {
                cPacket *pkt = rreqList->infoList.front().pkt;
                rreqList->infoList.pop_front();
                recvAODVUUPacket(pkt);
            }
        }
        // delete rreqList from the list
        for (std::map<PacketDestOrigin,RREQProcessed*>::iterator it = rreqProc.begin(); it != rreqProc.end(); ++it)
        {
            if (it->second == rreqList)
            {
                rreqProc.erase(it);
                break;
            }
        }

        delete msg;
        scheduleNextEvent();
        return;
    }

    if (msg==sendMessageEvent)
    {
        // timer event
        //testFile<<"send msg event"<<endl;
        scheduleNextEvent();
        return;
    }
    /* Handle packet depending on type */
    if (dynamic_cast<ControlManetRouting *>(msg))
    {
        //testFile<<"message 3"<<"\n";
        ControlManetRouting * control =  check_and_cast <ControlManetRouting *> (msg);
        if (control->getOptionCode()== MANET_ROUTE_NOROUTE)
        {
            if (isInMacLayer())
            {
                if (control->getDestAddress().isBroadcast())
                {
                    delete control;
                    return;
                }
                cMessage* msgAux = control->decapsulate();

                if (msgAux)
                    processMacPacket(PK(msgAux), control->getDestAddress(), control->getSrcAddress(), NS_IFINDEX);
                else
                {
                    if (!addressIsForUs(control->getSrcAddress()))
                    {
                        struct in_addr dest_addr;
                        dest_addr.s_addr = control->getDestAddress();
                        rt_table_t * fwd_rt = rt_table_find(dest_addr);

                        RERR *rerr;
                        DEBUG(LOG_DEBUG, 0,
                                "No route, src=%s dest=%s prev_hop=%s - DROPPING!",
                                ip_to_str(src_addr), ip_to_str(dest_addr));
                        if (fwd_rt)
                        {
                            rerr = rerr_create(0, fwd_rt->dest_addr,fwd_rt->dest_seqno);
                            rt_table_update_timeout(fwd_rt, DELETE_PERIOD);
                        }
                        else
                            rerr = rerr_create(0, dest_addr, 0);
                        struct in_addr src_addr;
                        src_addr.s_addr = control->getSrcAddress();
                        rt_table_t * rev_rt = rt_table_find(src_addr);

                        struct in_addr rerr_dest;

                        if (rev_rt && rev_rt->state == VALID)
                            rerr_dest = rev_rt->next_hop;
                        else
                            rerr_dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));

                        aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr), 1, &DEV_IFINDEX(NS_IFINDEX));
                    }
                }
            }
            else
            {
                ipDgram = (IPv4Datagram*) control->decapsulate();
                cPolymorphic * ctrl = ipDgram->removeControlInfo();
                unsigned int ifindex = NS_IFINDEX;  /* Always use ns interface */
                if (ctrl)
                {
                    if (dynamic_cast<Ieee802Ctrl*> (ctrl))
                    {
                        Ieee802Ctrl *ieeectrl = dynamic_cast<Ieee802Ctrl*> (ctrl);
                        ManetAddress address(ieeectrl->getDest());
                        int index = getWlanInterfaceIndexByAddress(address);
                        if (index!=-1)
                            ifindex = index;
                    }
                    delete ctrl;
                }
                EV << "Aodv rec datagram  " << ipDgram->getName() << " with dest=" << ipDgram->getDestAddress().str() << "\n";
                processPacket(ipDgram,ifindex);   // Data path
            }
        }
        else if (control->getOptionCode()== MANET_ROUTE_UPDATE)
        {
            DEBUG(LOG_DEBUG, 0, "forwarding packers, actualize time outs");
            src_addr.s_addr = control->getSrcAddress();
            dest_addr.s_addr = control->getDestAddress();
            rt_table_t * fwd_rt = rt_table_find(dest_addr);
            rt_table_t * rev_rt = rt_table_find(src_addr);
            rt_table_update_route_timeouts(fwd_rt, rev_rt);
            /* When forwarding data, make sure we are sending HELLO messages */
            gettimeofday(&this_host.fwd_time, NULL);
        }
        delete msg;
        scheduleNextEvent();
        return;
    }
    else if (dynamic_cast<UDPPacket *>(msg) || dynamic_cast<AODV_msg  *>(msg))
    {

        udpPacket = NULL;
        if (!isInMacLayer())
        {
            udpPacket = check_and_cast<UDPPacket*>(msg);
            if (udpPacket->getDestinationPort()!= 654)
            {
                delete  msg;
                scheduleNextEvent();
                return;
            }
            msg_aux  = udpPacket->decapsulate();
        }
        else
            msg_aux = msg;

        if (dynamic_cast<AODV_msg  *>(msg_aux))
        {
            aodvMsg = check_and_cast  <AODV_msg *>(msg_aux);
            //testFile<<"message 4"<<endl;
            if(aodvMsg->type == AODV_RREQ)
            {
                /*//apply black attack
                attFile.open("blackAttack.txt", std::fstream::in | std::fstream::out | std::fstream::app);
                while(!attFile.eof())
                {
                    std::getline(attFile,address);
                    if( address == DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr.str())
                    {
                        hFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" is black attacker"<<endl;
                        return;
                    }
                }
                //apply gray attack
                att2File.open("grayAttack.txt", std::fstream::in);
                while(!att2File.eof())
                {
                    std::getline(att2File,address2);
                    if( address2 == DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr.str())
                    {

                        random =  ((double) rand() / (RAND_MAX+1));
                        hFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" is gray attacker"<<endl;
                        hFile<<"random:"<<random<<endl;
                        if(random >= 0.5)
                        {
                            hFile<<"dropped"<<endl;
                            return;
                        }
                    }
                }*/

            }
            /*if( aodvMsg->type == AODV_RREP)   //if the message is hello message, increment the number of hello packets received from the neighbor
            {
                struct in_addr dst,src;
                RREP * rrep=(RREP*)aodvMsg;
                testFile<<"ttl: "<<rrep->ttl<<endl;

                if(rrep->ttl == 1)
                {
                    testFile<<"hello message ttl: "<<rrep->ttl<<endl;
                    IPv4ControlInfo *ctrl = check_and_cast<IPv4ControlInfo *>(msg_aux->getControlInfo());
                    IPvXAddress destAddr = ctrl->getDestAddr();
                    dst.S_addr = ManetAddress(destAddr);
                    //rFile<<"destination: "<<dst.S_addr<<endl;
                    if(rrep->dest_addr == ManetAddress(IPv4Address(AODV_BROADCAST)))
                    {
                        testFile<<"destination: "<<rrep->dest_addr<<endl;
                        testFile<<"increase hello recvd number"<<endl;
                        //IPvXAddress srcAddr = ctrl->getSrcAddr();
                        //src.S_addr = ManetAddress(srcAddr);
                        //rFile<<"src: "<<src.S_addr<<endl;
                        AodvNeiTableMap::iterator it = aodvNeiTableMap.find(src.S_addr);
                        {
                            rFile<<DEV_NR(NS_IFINDEX).ipaddr.S_addr<<"received hello from "<<it->first<<endl;
                            it->second->hello_rcvd++;
                        }
                    }
                }

            }*/
           /* if( aodvMsg->type == AODV_RREQ )
            {
                RREQ * rreq =(RREQ *) aodvMsg;
                cur_src.S_addr = rreq->cur_src;*/
/*                if(rreq->flag == 1)
                {
                    mesFile<<"rreq flag is 1: "<<endl;
                    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(rreq->orig_addr);
                    if( it != aodvNeiTableMap.end())
                        it->second->Dtrust = rreq->direct_trust;
                    mesFile<<"direct trust of "<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" about "<<rreq->orig_addr<<" is "<<it->second->Dtrust<<" at "<<simTime()<<endl;
                    mesFile<<endl;
                    mesFile.close();
                    return;
                }*/

               // mesFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" received rreq from "<<rreq->cur_src<<" at "<<simTime()<<endl;
               // mesFile<<"increment rcvd:"<<endl;
                /*AodvNeiTableMap::iterator it = aodvNeiTableMap.find(cur_src.s_addr);
                if (it != aodvNeiTableMap.end())
                   mesFile<<it->second->rcvd<<endl;*/
               /* if(rreq->ttl != 0)
                    inc_rcvd_packet(cur_src);*/
               /* mesFile<<it->second->rcvd<<endl;
                mesFile<<"forward:\n";
                mesFile<<it->second->forward<<endl;*/
           // }
            if (!isInMacLayer())
            {
                //testFile<<"message 5"<<endl;
                IPv4ControlInfo *controlInfo = check_and_cast<IPv4ControlInfo*>(udpPacket->removeControlInfo());
                src_addr.s_addr = ManetAddress(controlInfo->getSrcAddr());
                aodvMsg->setControlInfo(controlInfo);
                //testFile<<"end of message 5"<<endl;
            }
            else
            {
                //testFile<<"message 6"<<endl;
                Ieee802Ctrl *controlInfo = check_and_cast<Ieee802Ctrl*>(aodvMsg->getControlInfo());
                src_addr.s_addr = ManetAddress(controlInfo->getSrc());
            }
        }
        else
        {
            if (udpPacket)
                delete udpPacket;
            delete msg_aux;
            scheduleNextEvent();
            return;

        }

        if (udpPacket)
            delete udpPacket;
    }
    else
    {
        delete msg;
        scheduleNextEvent();
        return;
    }
    /* Detect routing loops */
    if (isLocalAddress(src_addr.s_addr))
    {
        delete aodvMsg;
        aodvMsg=NULL;
        scheduleNextEvent();
        //testFile<<"message 6"<<endl;
        return;
    }
    if (storeRreq)
    {
        //EV<<"message 5"<<"\n";
        RREQInfo rreqInfo;
        PacketDestOrigin orgDest;

        if (getDestAddressRreq(aodvMsg,orgDest,rreqInfo))
        {
            rreqInfo.pkt = aodvMsg;
            std::map<PacketDestOrigin,RREQProcessed*>::iterator it = rreqProc.find(orgDest);
            if (it == rreqProc.end())
            {
                RREQProcessed* proc = new RREQProcessed;
                proc->destOrigin = orgDest;
                proc->infoList.push_back(rreqInfo);
                rreqProc.insert(std::make_pair(orgDest,proc));
                scheduleAt(simTime()+par("rreqWait").doubleValue(),proc);
            }
            else
            {
                // store the packet in function if the cost and seq num
                RREQProcessed* proc = it->second;
                std::deque<RREQInfo>::iterator it2;
                for (it2 = proc->infoList.begin(); it2 != proc->infoList.end(); ++it2)
                {
                    if (((*it2).origin_seqno < rreqInfo.origin_seqno) || ((*it2).origin_seqno == rreqInfo.origin_seqno && (*it2).cost > rreqInfo.cost))
                    {
                        it2 = proc->infoList.insert(it2,rreqInfo);
                        break;
                    }
                }
                if (it2 == proc->infoList.end())
                {
                    proc->infoList.push_back(rreqInfo);
                }
            }
            return;
        }
    }
    recvAODVUUPacket(aodvMsg);
    scheduleNextEvent();
  //  recFile.close();
  //  rFile.close();
   // testFile<<"Exiting handleMessage"<<endl;
    //testFile.close();
    //infoFile.close();
}
/*
      case PT_ENCAPSULATED:
    // Decapsulate...
    if (internet_gw_mode) {
        rt_table_t *rev_rt, *next_hop_rt;
         rev_rt = rt_table_find(saddr);

         if (rev_rt && rev_rt->state == VALID) {
         rt_table_update_timeout(rev_rt, ACTIVE_ROUTE_TIMEOUT);

         next_hop_rt = rt_table_find(rev_rt->next_hop);

         if (next_hop_rt && next_hop_rt->state == VALID &&
             rev_rt && next_hop_rt->dest_addr.s_addr != rev_rt->dest_addr.s_addr)
             rt_table_update_timeout(next_hop_rt, ACTIVE_ROUTE_TIMEOUT);
         }
         p = pkt_decapsulate(p);

         target_->recv(p, (Handler *)0);
         break;
    }

    processPacket(p);   // Data path
    }
*/

/*void NS_CLASS energy_status_check (cMessage * msg)
{
    BasicBattery *bt = BatteryAccess().get();
    struct in_addr dest;
   // EV<<"###################################################";
   // EV<<bt->GetEnergy()<<"   "<<energyThrsh<<endl;
    if ( bt->GetEnergy() < energyThrsh )
        rreq_send(dest,-1, 1, flags, 1, bt->GetEnergy());
    return;
}*/



/* Starts the AODV-UU routing agent */
int NS_CLASS startAODVUUAgent()
{

    /* Set up the wait-on-reboot timer */
    if (wait_on_reboot)
    {
        timer_init(&worb_timer, &NS_CLASS wait_on_reboot_timeout, &wait_on_reboot);
        timer_set_timeout(&worb_timer, DELETE_PERIOD);
        DEBUG(LOG_NOTICE, 0, "In wait on reboot for %d milliseconds.",DELETE_PERIOD);
    }
    /* Schedule the first HELLO */
    if (!llfeedback && !optimized_hellos)
    {
        EV<<"hello start"<<endl;
        hello_start();
    }

    /* Initialize routing table logging */
    if (rt_log_interval)
        log_rt_table_init();

    /* Initialization complete */
    initialized = 1;

    DEBUG(LOG_DEBUG, 0, "Routing agent with IP = %s  started.",
          ip_to_str(DEV_NR(NS_DEV_NR).ipaddr));

    DEBUG(LOG_DEBUG, 0, "Settings:");
    DEBUG(LOG_DEBUG, 0, "unidir_hack %s", unidir_hack ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "rreq_gratuitous %s", rreq_gratuitous ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "expanding_ring_search %s", expanding_ring_search ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "local_repair %s", local_repair ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "receive_n_hellos %s", receive_n_hellos ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "hello_jittering %s", hello_jittering ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "wait_on_reboot %s", wait_on_reboot ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "optimized_hellos %s", optimized_hellos ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "ratelimit %s", ratelimit ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "llfeedback %s", llfeedback ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "internet_gw_mode %s", internet_gw_mode ? "ON" : "OFF");
    DEBUG(LOG_DEBUG, 0, "ACTIVE_ROUTE_TIMEOUT=%d", ACTIVE_ROUTE_TIMEOUT);
    DEBUG(LOG_DEBUG, 0, "TTL_START=%d", TTL_START);
    DEBUG(LOG_DEBUG, 0, "MAX_CAPACITY=%d", MAX_CAPACITY);
    DEBUG(LOG_DEBUG, 0, "DELETE_PERIOD=%d", DELETE_PERIOD);

    /* Schedule the first timeout */
    scheduleNextEvent();
    return 0;

}



// for use with gateway in the future
IPv4Datagram * NS_CLASS pkt_encapsulate(IPv4Datagram *p, IPv4Address gateway)
{
    IPv4Datagram *datagram = new IPv4Datagram(p->getName());
    datagram->setByteLength(IP_HEADER_BYTES);
    datagram->encapsulate(p);

    // set source and destination address
    datagram->setDestAddress(gateway);

    IPv4Address src = p->getSrcAddress();

    // when source address was given, use it; otherwise it'll get the address
    // of the outgoing interface after routing
    // set other fields
    datagram->setTypeOfService(p->getTypeOfService());
    datagram->setIdentification(p->getIdentification());
    datagram->setMoreFragments(false);
    datagram->setDontFragment (p->getDontFragment());
    datagram->setFragmentOffset(0);
    datagram->setTimeToLive(
        p->getTimeToLive() > 0 ?
        p->getTimeToLive() :
        0);

    datagram->setTransportProtocol(IP_PROT_IP);
    return datagram;
}



IPv4Datagram *NS_CLASS pkt_decapsulate(IPv4Datagram *p)
{

    if (p->getTransportProtocol() == IP_PROT_IP)
    {
        IPv4Datagram *datagram = check_and_cast  <IPv4Datagram *>(p->decapsulate());
        datagram->setTimeToLive(p->getTimeToLive());
        delete p;
        return datagram;
    }
    return NULL;
}



/*
  Reschedules the timer queue timer to go off at the time of the
  earliest event (so that the timer queue will be investigated then).
  Should be called whenever something might have changed the timer queue.
*/
#ifdef AODV_USE_STL
void NS_CLASS scheduleNextEvent()
{
    simtime_t timer;
    simtime_t timeout = timer_age_queue();

    if (!aodvTimerMap.empty())
    {
        timer = aodvTimerMap.begin()->first;
        if (sendMessageEvent->isScheduled())
        {
            if (timer < sendMessageEvent->getArrivalTime())
            {
                cancelEvent(sendMessageEvent);
                scheduleAt(timer, sendMessageEvent);
            }
        }
        else
        {
            scheduleAt(timer, sendMessageEvent);
        }
    }
}
#else
void NS_CLASS scheduleNextEvent()
{
    struct timeval *timeout;
    double delay;
    simtime_t timer;
    timeout = timer_age_queue();
    if (timeout)
    {
        delay  = (double)(((double)timeout->tv_usec/(double)1000000.0) +(double)timeout->tv_sec);
        timer = simTime()+delay;
        if (sendMessageEvent->isScheduled())
        {
            if (timer < sendMessageEvent->getArrivalTime())
            {
                cancelEvent(sendMessageEvent);
                scheduleAt(timer, sendMessageEvent);
            }
        }
        else
        {
            scheduleAt(timer, sendMessageEvent);
        }
    }
}
#endif



/*
  Replacement for if_indextoname(), used in routing table logging.
*/
const char *NS_CLASS if_indextoname(int ifindex, char *ifname)
{
    InterfaceEntry *   ie;
    assert(ifindex >= 0);
    ie = getInterfaceEntry(ifindex);
    return ie->getName();
}



void NS_CLASS recvAODVUUPacket(cMessage * msg)
{
    std::fstream testFile;
    //testFile.open("testFile.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    //testFile<<"Entering receive aodvuu packet"<<"\n";
    struct in_addr src, dst;
    int ttl;
    int interfaceId;

    AODV_msg *aodv_msg = check_and_cast<AODV_msg *> (msg);
    int len = aodv_msg->getByteLength();
    int ifIndex = NS_IFINDEX;

    ttl =  aodv_msg->ttl-1;
    if (!isInMacLayer())
    {
        IPv4ControlInfo *ctrl = check_and_cast<IPv4ControlInfo *>(msg->getControlInfo());
        IPvXAddress srcAddr = ctrl->getSrcAddr();
        IPvXAddress destAddr = ctrl->getDestAddr();
        EV<<"IPvXAddress: "<<srcAddr<<endl;

        src.s_addr = ManetAddress(srcAddr);
        dst.s_addr =  ManetAddress(destAddr);
        interfaceId = ctrl->getInterfaceId();

    }
    else
    {
        Ieee802Ctrl *ctrl = check_and_cast<Ieee802Ctrl *>(msg->getControlInfo());
        src.s_addr = ManetAddress(ctrl->getSrc());
        dst.s_addr =  ManetAddress(ctrl->getDest());
    }

    InterfaceEntry *   ie;
    if (!isInMacLayer())
    {
        for (int i = 0; i < getNumWlanInterfaces(); i++)
        {
            ie = getWlanInterfaceEntry(i);

            {
                // IPv4InterfaceData *ipv4data = ie->ipv4Data();
                if (interfaceId == ie->getInterfaceId())
                    ifIndex = getWlanInterfaceIndex(i);
            }
        }
    }
    aodv_socket_process_packet(aodv_msg, len, src, dst, ttl, ifIndex);
    delete   aodv_msg;
}


void NS_CLASS processMacPacket(cPacket * p, const ManetAddress &dest, const ManetAddress &src, int ifindex)
{
    struct in_addr dest_addr, src_addr;
    bool isLocal = false;
    struct ip_data *ipd = NULL;
    u_int8_t rreq_flags = 0;

    dest_addr.s_addr = dest;
    src_addr.s_addr = src;
    rt_table_t *fwd_rt, *rev_rt;

    //InterfaceEntry *   ie = getInterfaceEntry(ifindex);
    isLocal = isLocalAddress(src);

    rev_rt = rt_table_find(src_addr);
    fwd_rt = rt_table_find(dest_addr);


    rt_table_update_route_timeouts(fwd_rt, rev_rt);

    /* OK, the timeouts have been updated. Now see if either: 1. The
       packet is for this node -> ACCEPT. 2. The packet is not for this
       node -> Send RERR (someone want's this node to forward packets
       although there is no route) or Send RREQ. */

    if (!fwd_rt || fwd_rt->state == INVALID ||
            (fwd_rt->hcnt == 1 && (fwd_rt->flags & RT_UNIDIR)))
    {
        // If I am the originating node, then a route discovery
        // must be performed
        if (isLocal || (fwd_rt && (fwd_rt->flags & RT_REPAIR)))
        {
            if (p->getControlInfo())
                delete p->removeControlInfo();
            packet_queue_add(p, dest_addr);
            if (fwd_rt && (fwd_rt->flags & RT_REPAIR))
                rreq_local_repair(fwd_rt, src_addr, ipd);
            else
            {
                if (par("targetOnlyRreq").boolValue())
                    rreq_flags |= RREQ_DEST_ONLY;
                rreq_route_discovery(dest_addr, rreq_flags, ipd);
            }
        }
        // Else we must send a RERR message to the source if
        // the route has been previously used
        else
        {

            RERR *rerr;
            DEBUG(LOG_DEBUG, 0,
                    "No route, src=%s dest=%s prev_hop=%s - DROPPING!",
                    ip_to_str(src_addr), ip_to_str(dest_addr));
            if (fwd_rt)
            {
                rerr = rerr_create(0, fwd_rt->dest_addr,fwd_rt->dest_seqno);
                rt_table_update_timeout(fwd_rt, DELETE_PERIOD);
            }
            else
                rerr = rerr_create(0, dest_addr, 0);
            DEBUG(LOG_DEBUG, 0, "Sending RERR to prev hop %s for unknown dest %s",
                    ip_to_str(src_addr), ip_to_str(dest_addr));

                /* Unicast the RERR to the source of the data transmission
                 * if possible, otherwise we broadcast it. */
            struct in_addr rerr_dest;
            if (rev_rt && rev_rt->state == VALID)
                rerr_dest = rev_rt->next_hop;
            else
                rerr_dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));
            aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr),
                    1, &DEV_IFINDEX(ifindex));
            if (wait_on_reboot)
            {
                DEBUG(LOG_DEBUG, 0, "Wait on reboot timer reset.");
                timer_set_timeout(&worb_timer, DELETE_PERIOD);
            }
            //drop (p);
            sendICMP(p);
            /* DEBUG(LOG_DEBUG, 0, "Dropping pkt uid=%d", ch->uid()); */
            //  icmpAccess.get()->sendErrorMessage(p, ICMP_DESTINATION_UNREACHABLE, 0);
            return;
        }
        scheduleNextEvent();
        return;
    }
    else
    {
        /* DEBUG(LOG_DEBUG, 0, "Sending pkt uid=%d", ch->uid()); */
        if (p->getControlInfo())
            delete p->removeControlInfo();
        if (isInMacLayer())
        {
            Ieee802Ctrl *ctrl = new Ieee802Ctrl();
            ctrl->setDest(fwd_rt->next_hop.s_addr.getMAC());
            //TODO ctrl->setEtherType(...);
            p->setControlInfo(ctrl);
        }

        send(p, "to_ip");
        /* When forwarding data, make sure we are sending HELLO messages */
        //gettimeofday(&this_host.fwd_time, NULL);
        if (!llfeedback && optimized_hellos)
            hello_start();
    }
}



void NS_CLASS processPacket(IPv4Datagram * p,unsigned int ifindex)
{
    rt_table_t *fwd_rt, *rev_rt;
    struct in_addr dest_addr, src_addr;
    u_int8_t rreq_flags = 0;
    struct ip_data *ipd = NULL;


    fwd_rt = NULL;      /* For broadcast we provide no next hop */
    ipd = NULL;         /* No ICMP messaging */

    bool isLocal=true;

    src_addr.s_addr = ManetAddress(p->getSrcAddress());
    dest_addr.s_addr = ManetAddress(p->getDestAddress());

    InterfaceEntry *   ie;

    if (!p->getSrcAddress().isUnspecified())
    {
        isLocal = isLocalAddress(ManetAddress(p->getSrcAddress()));
    }

    ie = getInterfaceEntry (ifindex);
    if (p->getTransportProtocol()==IP_PROT_TCP)
        rreq_flags |= RREQ_GRATUITOUS;

    /* If this is a TCP packet and we don't have a route, we should
       set the gratuituos flag in the RREQ. */
    bool isMcast = ie->ipv4Data()->isMemberOfMulticastGroup(dest_addr.s_addr.getIPv4());

    /* If the packet is not interesting we just let it go through... */
    if (isMcast || dest_addr.s_addr == ManetAddress(IPv4Address(AODV_BROADCAST)))
    {
        send(p,"to_ip");
        return;
    }
    /* Find the entry of the neighboring node and the destination  (if any). */
    rev_rt = rt_table_find(src_addr);
    fwd_rt = rt_table_find(dest_addr);

#ifdef CONFIG_GATEWAY
    /* Check if we have a route and it is an Internet destination (Should be
     * encapsulated and routed through the gateway). */
    if (fwd_rt && (fwd_rt->state == VALID) &&
            (fwd_rt->flags & RT_INET_DEST))
    {
        /* The destination should be relayed through the IG */

        rt_table_update_timeout(fwd_rt, ACTIVE_ROUTE_TIMEOUT);

        p = pkt_encapsulate(p, *gateWayAddress);

        if (p == NULL)
        {
            DEBUG(LOG_ERR, 0, "IP Encapsulation failed!");
            return;
        }
        /* Update pointers to headers */
        dest_addr.s_addr = gateWayAddress->getInt();
        fwd_rt = rt_table_find(dest_addr);
    }
#endif /* CONFIG_GATEWAY */

    /* UPDATE TIMERS on active forward and reverse routes...  */
    rt_table_update_route_timeouts(fwd_rt, rev_rt);

    /* OK, the timeouts have been updated. Now see if either: 1. The
       packet is for this node -> ACCEPT. 2. The packet is not for this
       node -> Send RERR (someone want's this node to forward packets
       although there is no route) or Send RREQ. */

    if (!fwd_rt || fwd_rt->state == INVALID ||
            (fwd_rt->hcnt == 1 && (fwd_rt->flags & RT_UNIDIR)))
    {

        /* Check if the route is marked for repair or is INVALID. In
         * that case, do a route discovery. */
        struct in_addr rerr_dest;

        if (isLocal)
            goto route_discovery;

        if (fwd_rt && (fwd_rt->flags & RT_REPAIR))
            goto route_discovery;



        RERR *rerr;
        DEBUG(LOG_DEBUG, 0,
              "No route, src=%s dest=%s prev_hop=%s - DROPPING!",
              ip_to_str(src_addr), ip_to_str(dest_addr));
        if (fwd_rt)
        {
            rerr = rerr_create(0, fwd_rt->dest_addr,fwd_rt->dest_seqno);
            rt_table_update_timeout(fwd_rt, DELETE_PERIOD);
        }
        else
            rerr = rerr_create(0, dest_addr, 0);
        DEBUG(LOG_DEBUG, 0, "Sending RERR to prev hop %s for unknown dest %s",
              ip_to_str(src_addr), ip_to_str(dest_addr));

        /* Unicast the RERR to the source of the data transmission
         * if possible, otherwise we broadcast it. */

        if (rev_rt && rev_rt->state == VALID)
            rerr_dest = rev_rt->next_hop;
        else
            rerr_dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));

        aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr),
                         1, &DEV_IFINDEX(ifindex));
        if (wait_on_reboot)
        {
            DEBUG(LOG_DEBUG, 0, "Wait on reboot timer reset.");
            timer_set_timeout(&worb_timer, DELETE_PERIOD);
        }

        //drop (p);
        sendICMP(p);
        /* DEBUG(LOG_DEBUG, 0, "Dropping pkt uid=%d", ch->uid()); */
        //  icmpAccess.get()->sendErrorMessage(p, ICMP_DESTINATION_UNREACHABLE, 0);
        return;

route_discovery:
        /* Buffer packets... Packets are queued by the ip_queue.o
           module already. We only need to save the handle id, and
           return the proper verdict when we know what to do... */

        packet_queue_add(p, dest_addr);

        if (fwd_rt && (fwd_rt->flags & RT_REPAIR))
            rreq_local_repair(fwd_rt, src_addr, ipd);
        else
        {
            if (par("targetOnlyRreq").boolValue())
                rreq_flags |= RREQ_DEST_ONLY;
            rreq_route_discovery(dest_addr, rreq_flags, ipd);
        }

        return;

    }
    else
    {
        /* DEBUG(LOG_DEBUG, 0, "Sending pkt uid=%d", ch->uid()); */
        send(p,"to_ip");
        /* When forwarding data, make sure we are sending HELLO messages */
        gettimeofday(&this_host.fwd_time, NULL);

        if (!llfeedback && optimized_hellos)
            hello_start();
    }
}


struct dev_info NS_CLASS dev_ifindex (int ifindex)
{
    int index = ifindex2devindex(ifindex);
    return  (this_host.devs[index]);
}

struct dev_info NS_CLASS dev_nr(int n)
{
    return (this_host.devs[n]);
}

int NS_CLASS ifindex2devindex(unsigned int ifindex)
{
    int i;
    for (i = 0; i < this_host.nif; i++)
        if (dev_indices[i] == ifindex)
            return i;
    return -1;
}


void NS_CLASS processLinkBreak(const cPolymorphic *details)
{
    IPv4Datagram  *dgram=NULL;
    if (llfeedback)
    {
        if (dynamic_cast<IPv4Datagram *>(const_cast<cPolymorphic*> (details)))
        {
            dgram = const_cast<IPv4Datagram *>(check_and_cast<const IPv4Datagram *>(details));
            packetFailed(dgram);
            return;
        }
        else if (dynamic_cast<Ieee80211DataFrame *>(const_cast<cPolymorphic*> (details)))
        {
            Ieee80211DataFrame *frame = dynamic_cast<Ieee80211DataFrame *>(const_cast<cPolymorphic*>(details));
            packetFailedMac(frame);
        }
    }
}


void NS_CLASS processFullPromiscuous(const cObject *details)
{
    if (dynamic_cast<Ieee80211TwoAddressFrame *>(const_cast<cPolymorphic*> (details)))
    {
        Ieee80211TwoAddressFrame *frame = dynamic_cast<Ieee80211TwoAddressFrame *>(const_cast<cObject*>(details));
        ManetAddress sender(frame->getTransmitterAddress());
        struct in_addr destination;
        int iface;
        double cost;
        destination.s_addr = sender;
        rt_table_t * fwd_rt = rt_table_find(destination);
        if (fwd_rt)
            fwd_rt->pending = false;
    }
}

void NS_CLASS processPromiscuous(const cObject *details)
{

    if (dynamic_cast<Ieee80211DataFrame *>(const_cast<cPolymorphic*> (details)))
    {
        Ieee80211DataFrame *frame = dynamic_cast<Ieee80211DataFrame *>(const_cast<cObject*>(details));
        cPacket * pktAux = frame->getEncapsulatedPacket();
        if (!isInMacLayer() && pktAux != NULL)
        {
            /*
            if (dynamic_cast<IPv4Datagram *>(pktAux))
            {
                cPacket * pktAux1 = pktAux->getEncapsulatedPacket(); // Transport
                if (pktAux1)
                {
                    cPacket * pktAux2 = pktAux->getEncapsulatedPacket(); // protocol
                    if (pktAux2 && dynamic_cast<RREP *> (pktAux2))
                    {

                    }
                }
            }
            */
        }
        else if (isInMacLayer() && dynamic_cast<Ieee80211MeshFrame *>(frame))
        {
            Ieee80211MeshFrame *meshFrame = dynamic_cast<Ieee80211MeshFrame *>(frame);
            if (meshFrame->getSubType() == ROUTING)
            {
                cPacket * pktAux2 = meshFrame->getEncapsulatedPacket(); // protocol
                if (pktAux2 && dynamic_cast<RREP *> (pktAux2) && checkRrep)
                {
                    RREP* rrep = dynamic_cast<RREP *> (pktAux2);
                    PacketDestOrigin destOrigin(rrep->dest_addr,rrep->orig_addr);
                    std::map<PacketDestOrigin,RREPProcessed>::iterator it = rrepProc.find(destOrigin);
                    if (it == rrepProc.end())
                    {
                        // new
                        RREPProcessed rproc;
                        rproc.cost = rrep->cost;
                        rproc.dest_seqno = rrep->dest_seqno;
                        rproc.hcnt = rrep->hcnt;
                        rproc.hopfix = rrep->hopfix;
                        rproc.totalHops = rrep->totalHops;
                        rproc.next = ManetAddress(meshFrame->getReceiverAddress());
                    }
                    else if (it->second.dest_seqno < rrep->dest_seqno)
                    {
                        // actualize
                        it->second.cost = rrep->cost;
                        it->second.dest_seqno = rrep->dest_seqno;
                        it->second.hcnt = rrep->hcnt;
                        it->second.hopfix = rrep->hopfix;
                        it->second.next = ManetAddress(meshFrame->getReceiverAddress());
                    }
                    else if (it->second.dest_seqno == rrep->dest_seqno)
                    {
                        // equal seq num check
                        if (it->second.hcnt > rrep->hcnt)
                        {
                            it->second.cost = rrep->cost;
                            it->second.dest_seqno = rrep->dest_seqno;
                            it->second.hcnt = rrep->hcnt;
                            it->second.hopfix = rrep->hopfix;
                            it->second.next = ManetAddress(meshFrame->getReceiverAddress());
                        }
                    }
                }
            }
        }
    }
}

void NS_CLASS finish()
{

    if (iswrite)
        return;
    //iswrite=true;

    std::fstream ecFile,erFile, malFile,overFile;
    ecFile.open("EnergyConsumed.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    erFile.open("EnergyResidual.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    malFile.open("MaliciousNodes.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    overFile.open("ControlPackets.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    overFile<<"time "<<simTime()<<"\t"<<count_overhead<<endl;

    simtime_t t = simTime();
    BasicBattery *bt = BatteryAccess().get();
    energyConsumed = maxCapacity - bt->GetEnergy();
    ecFile<<"time "<<simTime()<<"\t"<<energyConsumed<<endl;
    erFile<<bt->GetEnergy()<<endl;


    malFile<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<":"<<endl;
    for (AodvNeiTableMap::iterator it2 = aodvNeiTableMap.begin(); it2 != aodvNeiTableMap.end(); it2++)
        if(it2->second->trusted == false)
            malFile<<it2->first<<endl;
    malFile<<endl;

    recordScalar("simulated time", t);
    recordScalar("Aodv totalSend ", totalSend);
    recordScalar("rreq send", totalRreqSend);
    recordScalar("rreq rec", totalRreqRec);
    recordScalar("rrep send", totalRrepSend);
    recordScalar("rrep rec", totalRrepRec);
    recordScalar("rrep ack send", totalRrepAckSend);
    recordScalar("rrep ack rec", totalRrepAckRec);
    recordScalar("rerr send", totalRerrSend);
    recordScalar("rerr rec", totalRerrRec);
    recordScalar("total repair",totalLocalRep);
    recordScalar("total energy consumed",energyConsumed);

    erFile.close();
    ecFile.close();
    malFile.close();
    overFile.close();
}


uint32_t NS_CLASS getRoute(const ManetAddress &dest,std::vector<ManetAddress> &add)
{
    return 0;
}


bool  NS_CLASS getNextHop(const ManetAddress &dest,ManetAddress &add, int &iface,double &cost)
{
    struct in_addr destAddr;
    destAddr.s_addr = dest;
    ManetAddress apAddr;
    rt_table_t * fwd_rt = this->rt_table_find(destAddr);
    if (fwd_rt)
    {
        if (fwd_rt->state != VALID)
            return false;
        add = fwd_rt->next_hop.s_addr;
        InterfaceEntry * ie = getInterfaceEntry (fwd_rt->ifindex);
        iface = ie->getInterfaceId();
        cost = fwd_rt->hcnt;
        return true;
    }
    else if (getAp(dest,apAddr))
    {
        destAddr.s_addr = apAddr;
        fwd_rt = this->rt_table_find(destAddr);
        if (!fwd_rt)
            return false;
        if (fwd_rt->state != VALID)
            return false;
        add = fwd_rt->next_hop.s_addr;
        InterfaceEntry * ie = getInterfaceEntry (fwd_rt->ifindex);
        iface = ie->getInterfaceId();
        cost = fwd_rt->hcnt;
        return true;
    }
    return false;
}

bool NS_CLASS isProactive()
{
    return false;
}

void NS_CLASS setRefreshRoute(const ManetAddress &destination, const ManetAddress & nextHop,bool isReverse)
{
    struct in_addr dest_addr, next_hop;
    dest_addr.s_addr = destination;
    next_hop.s_addr = nextHop;
    rt_table_t * route  = rt_table_find(dest_addr);

    ManetAddress apAddr;
    bool gratuitus = false;


    if (getAp(destination,apAddr))
    {
        dest_addr.s_addr = apAddr;
    }
    if (getAp(nextHop,apAddr))
    {
        next_hop.s_addr = apAddr;
    }

    if(par ("checkNextHop").boolValue())
    {
        if (nextHop.isUnspecified())
           return;
        if (!isReverse)
        {
            if (route &&(route->next_hop.s_addr==nextHop))
                 rt_table_update_route_timeouts(route, NULL);
        }


        if (isReverse && !route && gratuitus)
        {
            // Gratuitous Return Path
            struct in_addr node_addr;
            struct in_addr  ip_src;
            node_addr.s_addr = destination;
            ip_src.s_addr = nextHop;
            rt_table_insert(node_addr, ip_src,0,0, ACTIVE_ROUTE_TIMEOUT, VALID, 0,NS_DEV_NR,0xFFFFFFF,100, true, true,0, 0);
        }
        else if (route && (route->next_hop.s_addr == nextHop))
            rt_table_update_route_timeouts(NULL, route);

    }
    else
    {
        if (!isReverse)
        {
            if (route)
                 rt_table_update_route_timeouts(route, NULL);
        }


        if (isReverse && !route && !nextHop.isUnspecified())
        {
            // Gratuitous Return Path
            struct in_addr node_addr;
            struct in_addr  ip_src;
            node_addr.s_addr = destination;
            ip_src.s_addr = nextHop;
            rt_table_insert(node_addr, ip_src,0,0, ACTIVE_ROUTE_TIMEOUT, VALID, 0,NS_DEV_NR,0xFFFFFFF,100,true, true, 0, 0);
        }
        else if (route)
            rt_table_update_route_timeouts(NULL, route);

    }

    Enter_Method_Silent();
    scheduleNextEvent();
}


bool NS_CLASS isOurType(cPacket * msg)
{
    AODV_msg *re = dynamic_cast <AODV_msg *>(msg);
    if (re)
        return true;
    return false;
}

bool NS_CLASS getDestAddress(cPacket *msg,ManetAddress &dest)
{
    RREQ *rreq = dynamic_cast <RREQ *>(msg);
    if (!rreq)
        return false;
    dest = rreq->dest_addr;
    return true;

}

bool AODVUU::getDestAddressRreq(cPacket *msg,PacketDestOrigin &orgDest,RREQInfo &rreqInfo)
{
    RREQ *rreq = dynamic_cast <RREQ *>(msg);
    if (!rreq)
        return false;
    orgDest.setDests(rreq->dest_addr);
    orgDest.setOrigin(rreq->orig_addr);
    rreqInfo.origin_seqno = rreq->orig_seqno;
    rreqInfo.dest_seqno = rreq->dest_seqno;
    rreqInfo.hcnt = rreq->hcnt;
    rreqInfo.cost = rreq->cost;
    rreqInfo.hopfix = rreq->hopfix;
    return true;
}



#ifdef AODV_USE_STL_RT
bool  NS_CLASS setRoute(const ManetAddress &dest,const ManetAddress &add, const int &ifaceIndex,const int &hops,const ManetAddress &mask)
{
    Enter_Method_Silent();
    struct in_addr destAddr;
    struct in_addr nextAddr;
    struct in_addr rerr_dest;
    destAddr.s_addr = dest;
    nextAddr.s_addr = add;
    bool status=true;
    bool delEntry = add.isUnspecified();

    DEBUG(LOG_DEBUG, 0, "setRoute %s next hop %s",ip_to_str(destAddr),ip_to_str(nextAddr));

    rt_table_t * fwd_rt = rt_table_find(destAddr);

    if (fwd_rt)
    {
        if (delEntry)
        {
            RERR* rerr = rerr_create(0, destAddr, 0);
            DEBUG(LOG_DEBUG, 0, "setRoute Sending for unknown dest %s", ip_to_str(destAddr));

            /* Unicast the RERR to the source of the data transmission
             * if possible, otherwise we broadcast it. */
            rerr_dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));

            aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr),
                             1, &DEV_IFINDEX(NS_IFINDEX));
        }
        ManetAddress dest = fwd_rt->dest_addr.s_addr;
        AodvRtTableMap::iterator it = aodvRtTableMap.find(dest);
        if (it != aodvRtTableMap.end())
        {
            if (it->second != fwd_rt)
                opp_error("AODV routing table error");
        }
        aodvRtTableMap.erase(it);
        if (fwd_rt->state == VALID || fwd_rt->state == IMMORTAL)
            rt_tbl.num_active--;
        timer_remove(&fwd_rt->rt_timer);
        timer_remove(&fwd_rt->hello_timer);
        timer_remove(&fwd_rt->ack_timer);
        rt_tbl.num_entries = aodvRtTableMap.size();
        free (fwd_rt);
    }
    else
        DEBUG(LOG_DEBUG, 0, "No route entry to delete");

    if (ifaceIndex>=getNumInterfaces())
        status = false;
    ManetRoutingBase::setRoute(dest,add,ifaceIndex,hops,mask);

    if (!delEntry && ifaceIndex<getNumInterfaces())
    {
        fwd_rt = modifyAODVTables(destAddr,nextAddr,hops,(uint32_t) SIMTIME_DBL(simTime()), 0xFFFF,IMMORTAL,0, ifaceIndex);
        status = (fwd_rt!=NULL);

    }

    return status;
}


bool  NS_CLASS setRoute(const ManetAddress &dest,const ManetAddress &add, const char  *ifaceName,const int &hops,const ManetAddress &mask)
{
    Enter_Method_Silent();
    struct in_addr destAddr;
    struct in_addr nextAddr;
    struct in_addr rerr_dest;
    destAddr.s_addr = dest;
    nextAddr.s_addr = add;
    bool status=true;
    int index;
    bool delEntry = add.isUnspecified();

    DEBUG(LOG_DEBUG, 0, "setRoute %s next hop %s",ip_to_str(destAddr),ip_to_str(nextAddr));
    rt_table_t * fwd_rt = rt_table_find(destAddr);

    if (fwd_rt)
    {
        if (delEntry)
        {
            RERR* rerr = rerr_create(0, destAddr, 0);
            DEBUG(LOG_DEBUG, 0, "setRoute Sending for unknown dest %s", ip_to_str(destAddr));

            /* Unicast the RERR to the source of the data transmission
             * if possible, otherwise we broadcast it. */
            rerr_dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));

            aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr),
                             1, &DEV_IFINDEX(NS_IFINDEX));
        }
        ManetAddress dest = fwd_rt->dest_addr.s_addr;
        AodvRtTableMap::iterator it = aodvRtTableMap.find(dest);
        if (it != aodvRtTableMap.end())
        {
            if (it->second != fwd_rt)
                opp_error("AODV routing table error");
        }
        aodvRtTableMap.erase(it);
        if (fwd_rt->state == VALID || fwd_rt->state == IMMORTAL)
            rt_tbl.num_active--;
        timer_remove(&fwd_rt->rt_timer);
        timer_remove(&fwd_rt->hello_timer);
        timer_remove(&fwd_rt->ack_timer);
        rt_tbl.num_entries = aodvRtTableMap.size();
        free (fwd_rt);
    }
    else
        DEBUG(LOG_DEBUG, 0, "No route entry to delete");

    for (index = 0; index <getNumInterfaces(); index++)
    {
        if (strcmp(ifaceName, getInterfaceEntry(index)->getName())==0) break;
    }
    if (index>=getNumInterfaces())
        status = false;

    ManetRoutingBase::setRoute(dest,add,index,hops,mask);

    if (!delEntry && index<getNumInterfaces())
    {
        fwd_rt = modifyAODVTables(destAddr,nextAddr,hops,(uint32_t) SIMTIME_DBL(simTime()), 0xFFFF,IMMORTAL,0, index);
        status = (fwd_rt!=NULL);
    }


    return status;
}
#else

bool  NS_CLASS setRoute(const ManetAddress &dest,const ManetAddress &add, const int &ifaceIndex,const int &hops,const ManetAddress &mask)
{
    Enter_Method_Silent();
    struct in_addr destAddr;
    struct in_addr nextAddr;
    struct in_addr rerr_dest;
    destAddr.s_addr = dest;
    nextAddr.s_addr = add;
    bool status=true;
    bool delEntry = (add == (ManetAddress)0);

    DEBUG(LOG_DEBUG, 0, "setRoute %s next hop %s",ip_to_str(destAddr),ip_to_str(nextAddr));

    rt_table_t * fwd_rt = rt_table_find(destAddr);

    if (fwd_rt)
    {
        if (delEntry)
        {
            RERR* rerr = rerr_create(0, destAddr, 0);
            DEBUG(LOG_DEBUG, 0, "setRoute Sending for unknown dest %s", ip_to_str(destAddr));

            /* Unicast the RERR to the source of the data transmission
             * if possible, otherwise we broadcast it. */
            rerr_dest.s_addr = AODV_BROADCAST;

            aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr),
                             1, &DEV_IFINDEX(NS_IFINDEX));
        }
        list_detach(&fwd_rt->l);
        precursor_list_destroy(fwd_rt);
        if (fwd_rt->state == VALID || fwd_rt->state == IMMORTAL)
            rt_tbl.num_active--;
        timer_remove(&fwd_rt->rt_timer);
        timer_remove(&fwd_rt->hello_timer);
        timer_remove(&fwd_rt->ack_timer);
        rt_tbl.num_entries--;
        free (fwd_rt);
    }
    else
        DEBUG(LOG_DEBUG, 0, "No route entry to delete");

    if (ifaceIndex>=getNumInterfaces())
        status = false;
    ManetRoutingBase::setRoute(dest,add,ifaceIndex,hops,mask);

    if (!delEntry && ifaceIndex<getNumInterfaces())
    {
        fwd_rt = modifyAODVTables(destAddr,nextAddr,hops,(uint32_t) SIMTIME_DBL(simTime()), 0xFFFF,IMMORTAL,0, ifaceIndex);
        status = (fwd_rt!=NULL);

    }

    return status;
}

bool  NS_CLASS setRoute(const ManetAddress &dest,const ManetAddress &add, const char  *ifaceName,const int &hops,const ManetAddress &mask)
{
    Enter_Method_Silent();
    struct in_addr destAddr;
    struct in_addr nextAddr;
    struct in_addr rerr_dest;
    destAddr.s_addr = dest;
    nextAddr.s_addr = add;
    bool status=true;
    int index;
    bool delEntry = (add == (ManetAddress)0);

    DEBUG(LOG_DEBUG, 0, "setRoute %s next hop %s",ip_to_str(destAddr),ip_to_str(nextAddr));
    rt_table_t * fwd_rt = rt_table_find(destAddr);

    if (fwd_rt)
    {
        if (delEntry)
        {
            RERR* rerr = rerr_create(0, destAddr, 0);
            DEBUG(LOG_DEBUG, 0, "setRoute Sending for unknown dest %s", ip_to_str(destAddr));

            /* Unicast the RERR to the source of the data transmission
             * if possible, otherwise we broadcast it. */
            rerr_dest.s_addr = AODV_BROADCAST;

            aodv_socket_send((AODV_msg *) rerr, rerr_dest,RERR_CALC_SIZE(rerr),
                             1, &DEV_IFINDEX(NS_IFINDEX));
        }
        list_detach(&fwd_rt->l);
        precursor_list_destroy(fwd_rt);
        if (fwd_rt->state == VALID || fwd_rt->state == IMMORTAL)
            rt_tbl.num_active--;
        timer_remove(&fwd_rt->rt_timer);
        timer_remove(&fwd_rt->hello_timer);
        timer_remove(&fwd_rt->ack_timer);
        rt_tbl.num_entries--;
        free (fwd_rt);
    }
    else
        DEBUG(LOG_DEBUG, 0, "No route entry to delete");

    for (index = 0; index <getNumInterfaces(); index++)
    {
        if (strcmp(ifaceName, getInterfaceEntry(index)->getName())==0) break;
    }
    if (index>=getNumInterfaces())
        status = false;

    ManetRoutingBase::setRoute(dest,add,index,hops,mask);

    if (!delEntry && index<getNumInterfaces())
    {
        fwd_rt = modifyAODVTables(destAddr,nextAddr,hops,(uint32_t) SIMTIME_DBL(simTime()), 0xFFFF,IMMORTAL,0, index);
        status = (fwd_rt!=NULL);
    }


    return status;
}
#endif

bool NS_CLASS isThisRrepPrevSent(cMessage *msg)
{
    if (!checkRrep)
        return false;
    RREP *rrep = dynamic_cast<RREP *>(msg);
    if (rrep->hcnt == 0)
            return false; // this packet had this node like destination, in this case the node must send the packet

    if (rrep == NULL)
         return false; // no information, send

    PacketDestOrigin destOrigin(rrep->dest_addr,rrep->orig_addr);
    std::map<PacketDestOrigin,RREPProcessed>::iterator it = rrepProc.find(destOrigin);
    if (it != rrepProc.end()) // only send if the seq num is bigger
    {
        if (it->second.dest_seqno > rrep->dest_seqno)
        {
            return true;
        }
        else if (it->second.dest_seqno == rrep->dest_seqno && it->second.totalHops < rrep->totalHops)
        {
            return true;
        }
    }
    return false;
}

void NS_CLASS actualizeTablesWithCollaborative(const ManetAddress &dest)
{
    if (!getCollaborativeProtocol())
        return;

    struct in_addr next_hop,destination;
    int iface;
    double cost;

    if (getCollaborativeProtocol()->getNextHop(dest,next_hop.s_addr,iface,cost))
    {
        u_int8_t hops = cost;
        destination.s_addr = dest;
        std::map<ManetAddress,u_int32_t *>::iterator it =  mapSeqNum.find(dest);
        if (it == mapSeqNum.end())
            opp_error("node not found in mapSeqNum");
        uint32_t sqnum = *(it->second);
        uint32_t life = PATH_DISCOVERY_TIME - 2 * hops * NODE_TRAVERSAL_TIME;
        int ifindex = -1;

        rt_table_t * fwd_rt = rt_table_find(destination);

        for (int i = 0; i < getNumInterfaces(); i++)
        {
            if (getInterfaceEntry(i)->getInterfaceId() == iface)
            {
                ifindex = i;
                break;
            }
        }

        if (ifindex == -1)
            opp_error("interface not found");

        if (fwd_rt)
            fwd_rt = rt_table_update(fwd_rt, next_hop, hops, sqnum, life, VALID, fwd_rt->flags,ifindex, cost, cost+1, fwd_rt->trusted, fwd_rt->blacklist, fwd_rt->delay, 0);
        else
            fwd_rt = rt_table_insert(destination, next_hop, hops, sqnum, life, VALID, 0, ifindex, cost, cost+1, true, true, 0, 0);

        hops = 1;
        rt_table_t * fwd_rtAux = rt_table_find(next_hop);
        it =  mapSeqNum.find(next_hop.s_addr);
        if (it == mapSeqNum.end())
            opp_error("node not found in mapSeqNum");
        sqnum = *(it->second);
        life = PATH_DISCOVERY_TIME - 2 * (int)hops * NODE_TRAVERSAL_TIME;
        if (fwd_rtAux)
            fwd_rtAux = rt_table_update(fwd_rtAux, next_hop, hops, sqnum, life, VALID, fwd_rtAux->flags,ifindex, hops, hops+1, fwd_rtAux->trusted, fwd_rtAux->blacklist, fwd_rtAux->delay, 0);
        else
            fwd_rtAux = rt_table_insert(next_hop, next_hop, hops, sqnum, life, VALID, 0, ifindex, hops, hops+1, true, true, 0, 0);
    }
}


bool NS_CLASS handleNodeStart(IDoneCallback *doneCallback)
{
    if (isRoot)
    {
        timer_init(&proactive_rreq_timer,&NS_CLASS rreq_proactive, NULL);
        timer_set_timeout(&proactive_rreq_timer, par("startRreqProactive").longValue());
    }

    propagateProactive = par("propagateProactive");
    strcpy(nodeName,getParentModule()->getParentModule()->getFullName());
    aodv_socket_init();
    rt_table_init();
    packet_queue_init();
    startAODVUUAgent();
    return true;
}

bool NS_CLASS handleNodeShutdown(IDoneCallback *doneCallback)
{

    while (!aodvRtTableMap.empty())
    {
        free (aodvRtTableMap.begin()->second);
        aodvRtTableMap.erase(aodvRtTableMap.begin());
    }
    while (!rreq_records.empty())
    {
        free (rreq_records.back());
        rreq_records.pop_back();
    }
    while (!rreq_blacklist.empty())
    {
        free (rreq_blacklist.begin()->second);
        rreq_blacklist.erase(rreq_blacklist.begin());
    }

    while (!seekhead.empty())
    {
        delete (seekhead.begin()->second);
        seekhead.erase(seekhead.begin());
    }
    packet_queue_destroy();
    cancelEvent(sendMessageEvent);
    log_cleanup();
    return true;
}

void NS_CLASS handleNodeCrash()
{
    while (!aodvRtTableMap.empty())
    {
        free (aodvRtTableMap.begin()->second);
        aodvRtTableMap.erase(aodvRtTableMap.begin());
    }
    while (!rreq_records.empty())
    {
        free (rreq_records.back());
        rreq_records.pop_back();
    }
    while (!rreq_blacklist.empty())
    {
        free (rreq_blacklist.begin()->second);
        rreq_blacklist.erase(rreq_blacklist.begin());
    }

    while (!seekhead.empty())
    {
        delete (seekhead.begin()->second);
        seekhead.erase(seekhead.begin());
    }
    packet_queue_destroy();
    cancelEvent(sendMessageEvent);
    log_cleanup();
}

