/*****************************************************************************
 *
 * Copyright (C) 2001 Uppsala University and Ericsson AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Erik Nordstr�, <erik.nordstrom@it.uu.se>
 *
 *
 *****************************************************************************/
#define NS_PORT
#define OMNETPP

#ifdef NS_PORT
#ifndef OMNETPP
#include "ns/aodv-uu.h"
#else
#include "../aodv_uu_omnet.h"
#endif
#else
#include <netinet/in.h>

#include "aodv_rreq.h"
#include "aodv_rrep.h"
#include "routing_table.h"
#include "aodv_timeout.h"
#include "timer_queue_aodv.h"
#include "aodv_socket.h"
#include "params.h"
#include "seek_list.h"
#include "defs_aodv.h"
#include "debug_aodv.h"

#include "locality.h"
#endif

#include "algorithm"
/* Comment this to remove packet field output: */
//#define DEBUG_OUTPUT

#define HCNT_LIMIT 0

typedef std::vector<ManetAddress> NonCoopNode;
NonCoopNode nonCoopNode;

#ifndef NS_PORT
static LIST(rreq_records);
static LIST(rreq_blacklist);

static struct rreq_record *rreq_record_insert(struct in_addr orig_addr,
        u_int32_t rreq_id);
static struct rreq_record *rreq_record_find(struct in_addr orig_addr,
        u_int32_t rreq_id);

struct blacklist *rreq_blacklist_find(struct in_addr dest_addr);

extern int rreq_gratuitous, expanding_ring_search;
extern int internet_gw_mode;
#endif

RREQ *NS_CLASS rreq_create(u_int8_t flags,struct in_addr dest_addr,
                           u_int32_t dest_seqno, struct in_addr orig_addr, int flag)
{
    EV<<"rreq_create"<<endl;

    //std::fstream rreqFile;
    //rreqFile.open("RREQCreate.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    RREQ *rreq;
#ifndef OMNETPP
    rreq = (RREQ *) aodv_socket_new_msg();
#else
    rreq = new RREQ();
    rreq->cost=0;
#endif
    rreq->type = AODV_RREQ;
    rreq->res1 = 0;
    rreq->res2 = 0;
    rreq->hcnt = 0;
    rreq->rreq_id = htonl(this_host.rreq_id++);
    rreq->dest_addr = dest_addr.s_addr;
    rreq->dest_seqno = htonl(dest_seqno);
    rreq->orig_addr = orig_addr.s_addr;
    rreq->criticality = criticality;  //set from the node initialization
    //rreq->flag = flag;
    //rreq->q_list = new qlist();
    rreq->cur_src = orig_addr.s_addr;
    rreq->prev_src =  orig_addr.s_addr;
    //rreq->energy = -1;
    rreq->totalDelay = 0;
    rreq->delay = 0;
    rreq->delayReward = 0;
    rreq->helloRcvd_no = 0;
    rreq->src_time = simTime();
    rreq->pathTrust = -1;
    rreq->futurQValue = 0;
    rreq->sender_x = 0;
    rreq->sender_y = 0;
    rreq->setByteLength(RREQ_SIZE);

    /* Immediately before a node originates a RREQ flood it must
       increment its sequence number... */
    seqno_incr(this_host.seqno);
    rreq->orig_seqno = htonl(this_host.seqno);

    if (flags & RREQ_JOIN)
        rreq->j = 1;
    if (flags & RREQ_REPAIR)
        rreq->r = 1;
    if (flags & RREQ_GRATUITOUS)
        rreq->g = 1;
    if (flags & RREQ_DEST_ONLY)
        rreq->d = 1;

    DEBUG(LOG_DEBUG, 0, "Assembled RREQ %s", ip_to_str(dest_addr));
#ifdef DEBUG_OUTPUT
    log_pkt_fields((AODV_msg *) rreq);
#endif
   // rreqFile<<"source is: "<<rreq->orig_addr<<" at "<<simTime()<<endl;
   // rreqFile<<"rreq created with length: "<<rreq->getByteLength()<<endl;
   // rreqFile.close();
    return rreq;
}

AODV_ext *rreq_add_ext(RREQ * rreq, int type, unsigned int offset,
                       int len, char *data)
{
    AODV_ext *ext = NULL;
#ifndef OMNETPP
    if (offset < RREQ_SIZE)
        return NULL;

    ext = (AODV_ext *) ((char *) rreq + offset);

    ext->type = type;
    ext->length = len;

    memcpy(AODV_EXT_DATA(ext), data, len);
#else
    ext = rreq->addExtension(type,len,data);
#endif
    return ext;
}

void NS_CLASS rreq_send(struct in_addr dest_addr, u_int32_t dest_seqno,
                        int ttl, u_int8_t flags, int flag , double energy)
{
    EV<<"rreq_send"<<endl;
    //std::fstream sendFile;
    //sendFile.open("sendRREQ.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    //std::fstream idFile;
    //idFile.open("RREQid.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    RREQ *rreq = new RREQ();
    struct in_addr dest;
    struct address * addr= new address;
    int i,sendFlag=0, num=0, count_observ=0, count_size=0;
    double energyThrshold=0, random=0, maxQ=0, randNum=0;
    ManetAddress id;
    in_addr nei;
    dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));
    Coord myPos = MobilityAccess().get()->getCurrentPosition();
    /* Check if we should force the gratuitous flag... (-g option). */
    if (rreq_gratuitous)
        flags |= RREQ_GRATUITOUS;


    /* Broadcast on all interfaces */
#ifdef OMNETPP
    double delay = -1;
    if (par("EqualDelay"))
        delay = par("broadcastDelay");
#endif

    for (i = 0; i < MAX_NR_INTERFACES; i++)
    {
        if (!DEV_NR(i).enabled)
            continue;

        rreq = rreq_create(flags, dest_addr, dest_seqno, DEV_NR(i).ipaddr, flag);

        //define the threshold for energy in selecting neighbors
        energyThrshold = (double)(maxCapacity)/(rreq->criticality+1);

        /*Determine the exploration rate*/
        for (AodvRtTableMap::iterator it = aodvRtTableMap.begin(); it != aodvRtTableMap.end(); it++)
        {
            if(it->second->next_hop.S_addr == it->first &&  rreq->prev_src != it->first)
            {
                AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it->first);
                if(checkNei!=aodvNeiTableMap.end() && checkNei->second->q_value != 0 && checkNei->second->trusted == true /*&& checkNei->second->energy >= energyThrshold*/)
                    count_observ++;
                count_size++;
            }
        }
        //sendFile<<"observe:"<<count_observ<<"   size: "<<count_size<<endl;
        if( count_observ <= (0.3*count_size) )
            epsilon = (1 - ((double)(count_observ)/count_size));
        else
            epsilon = 0.3;
        //epsilon = (1 - ((double)(count_observ)/count_size));
       // sendFile<<"epsilon:"<<epsilon<<endl;

#ifdef OMNETPP
           rreq->ttl = ttl;    //rreq message
          // sendFile<<"criticality: "<<rreq->criticality<<endl;

       /* select the next hop based on Q-value using exploration rate*/
          random =  ((double) rand() / (RAND_MAX+1));
          //sendFile<<"random: "<<random<<endl;
          for (AodvRtTableMap::iterator it2 = aodvRtTableMap.begin(); it2 != aodvRtTableMap.end(); it2++) //using exploitation
          {
              if(it2->second->next_hop.S_addr == it2->first)
              {
                  AodvNeiTableMap::iterator Nei = aodvNeiTableMap.find(it2->first);
                  if( Nei!=aodvNeiTableMap.end() && Nei->second->trusted == true && /*Nei->second->energy >= energyThrshold &&*/ rreq->prev_src != it2->first /*&& rreq->orig_addr != it2->first*/)
                  {
                      //sendFile<<"nexthop:"<<it2->first<<" qval:"<<Nei->second->q_value<<endl;
                      if(Nei->second->q_value >= maxQ)
                      {
                          maxQ = Nei->second->q_value;
                          //sendFile<<"checking  neighbor: "<<it2->first<<endl;
                          id = it2->first;
                      }
                  }
              }
          }
          //sendFile<<" id: "<<id<<"maxQ: "<<maxQ<<endl;
          if( random < epsilon)   //using exploration
          {
              //sendFile<<"random < epsilon"<<endl;
              for (AodvRtTableMap::iterator it2 = aodvRtTableMap.begin(); it2 != aodvRtTableMap.end(); it2++)
              {
                  if( it2->second->next_hop.S_addr == it2->first )
                  {
                      AodvNeiTableMap::iterator Nei = aodvNeiTableMap.find(it2->first);
                      if( Nei!=aodvNeiTableMap.end() && Nei->second->trusted == true && /*Nei->second->energy >= energyThrshold &&*/ rreq->prev_src != it2->first)
                          if(it2->first != id)
                              num++;
                  }
              }
              if(num != 0)
              {
                  randNum = ((double) ( rand() % num ) + 1);
                  num=0;
                  for (AodvRtTableMap::iterator it2 = aodvRtTableMap.begin(); it2 != aodvRtTableMap.end(); it2++)
                  {
                      if( it2->second->next_hop.S_addr == it2->first )
                      {
                          AodvNeiTableMap::iterator Nei = aodvNeiTableMap.find(it2->first);
                          if( Nei!=aodvNeiTableMap.end() && Nei->second->trusted == true && /*Nei->second->energy >= energyThrshold &&*/ rreq->prev_src != it2->first)
                              if(it2->first != id)
                              {
                                  num++;
                                  if( num == randNum )
                                  {
                                      id = it2->first;
                                      break;
                                  }
                              }
                      }
                  }
              }
          }

           rreq->inter_dest_addr = id;
           rreq->src_time = simTime();
           rreq->sender_x = myPos.x;
           rreq->sender_y = myPos.y;
           //put path trust
           AodvNeiTableMap::iterator it3 = aodvNeiTableMap.find(id);
           if(it3->second->Ttrust != -1)
               rreq->pathTrust = it3->second->Ttrust;
           //sendFile<<"path trust:"<<rreq->pathTrust<<endl;
           RREQ * rreq_new = new RREQ();
           rreq_new = check_and_cast <RREQ*>(rreq->dup());
           //EV<<"after duplicate: "<<rreq_new->prev_src<<"\t"<<rreq_new->cur_src<<"\t"<<rreq_new->criticality<<endl;
           rreq_new->ttl=ttl;
           //sendFile<<"rreq size:"<<RREQ_SIZE<<"   "<<sizeof(rreq_new)<<"  "<<rreq->getByteLength()<<endl;
           aodv_socket_send((AODV_msg *) rreq_new, dest, RREQ_SIZE, 1, &DEV_NR(i),delay);
           count_overhead++;
           //totalRreqSend++;
           nei.S_addr = rreq_new->inter_dest_addr;
           inc_forwardTo_packet(nei);
           addr->ad = id;
           addr->time = simTime();
           aodvQValueMap.insert(std::make_pair(rreq->rreq_id,addr));
           AodvQValueMap::iterator it4 = aodvQValueMap.find(rreq->rreq_id);
           //sendFile<<"neighbor inserted in q table map:"<<it4->second->ad<<" at: "<<it4->second->time<<endl;
           //sendFile<<"packet rreq "<<rreq_new->rreq_id<<" send from: "<<DEV_NR(i).ipaddr.S_addr<<" to "<<rreq_new->inter_dest_addr<<"in "<<simTime()<<endl;
          // ttlFile<<"packet rreq send to "<<dest.S_addr<<endl;

           sendFlag=1;
#else
        if(flag == 0)  //broadcast rreq msg to the selected neighbors (trusted and not low enerrgy ... )
        {
           rreq->ttl = ttl;    //rreq message
           /*for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
           {
               if(it->second->nei_now == true && it->second->trusted == true)
                   if((it->second->blacklist == true && rreq->criticality >= CRITIC_THRSH) || it->second->blacklist == false )
                   {
                       dest.S_addr = it->second->nei_addr.S_addr;
                       RREQ * rreq_new = check_and_cast <RREQ*>(rreq->dup());
                      aodv_socket_send((AODV_msg *) rreq_new, dest, RREQ_SIZE, 1, &DEV_NR(i),delay);
                       inc_forwardTo_packet(dest);
                       EV<<"packet sent to "<<dest.S_addr;
                   }
           }*/


        }
        else if(flag == 1)    //broadcast low energy msg
        {
            rreq->ttl = 1;      //low energy message

            aodv_socket_send((AODV_msg *) rreq, dest, size, ttl, &DEV_NR(i),delay);
        }
#endif
    }
    if(sendFlag==0 && flag==0)  // all the neighbors are in blacklist, so increment the criticality and try to send the packet again
    {
        criticality++;
       // rreq->criticality = criticality;
        //ttl = tempttl;
        //rreq_send(dest_addr, dest_seqno, ttl, flags, 0, -1);
    }
    //idFile<<rreq->cur_src<<" created packet with id "<<rreq->rreq_id<<" for dest:"<<rreq->dest_addr<<" at: "<<simTime()<<endl;
    totalRreqSend++;
    //sendFile<<endl;
    //sendFile.close();
    //idFile.close();

    /*BasicBattery *bt = BatteryAccess().get();
    energyConsumed = energyConsumed + maxCapacity - bt->GetEnergy();*/
}

void NS_CLASS rreq_forward(RREQ * rreq, int size, int ttl)
{
    struct in_addr dest, orig;
    int i, counter=0, count_observ=0, count_size=0;
    double maxQval=0, futurQ=0, sumQ=0, meanQ=0, energyThrshold=0;
    address * addr= new address;
    ManetAddress index;
    BasicBattery *bt = BatteryAccess().get();
    Coord myPos = MobilityAccess().get()->getCurrentPosition();
    //std::fstream forFile, neiFile;
    //forFile.open("forwardRREQ.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    //neiFile.open("neighborTable.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));
    orig.s_addr = rreq->orig_addr;

    //define the threshold for energy in selecting neighbors
    energyThrshold = (double)(maxCapacity)/(rreq->criticality+1);

    //printing neighbor table
    //neiFile<<"\n--- "<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<": \n";
    //for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
        //neiFile<<it->first<<" : "<<it->second->trusted<<"   "<<it->second->q_value<<endl;
    //neiFile<<"***********************************************"<<endl;


    /*Determine the exploration rate*/
    for (AodvRtTableMap::iterator it = aodvRtTableMap.begin(); it != aodvRtTableMap.end(); it++)
    {
        if(it->second->next_hop.S_addr == it->first &&  rreq->prev_src != it->first)
        {
            AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it->first);
            if(checkNei!=aodvNeiTableMap.end() && checkNei->second->q_value != 0 && checkNei->second->trusted == true /*&& checkNei->second->energy >= energyThrshold*/)
                count_observ++;
            count_size++;
        }
    }
    //forFile<<"observe:"<<count_observ<<"   size: "<<count_size<<endl;
    if( count_observ <= (0.3*count_size) )
        epsilon = (1 - ((double)(count_observ)/count_size));
    else
        epsilon = 0.3;
    //epsilon = (1 - ((double)(count_observ)/count_size));
    //forFile<<"epsilon:"<<epsilon<<endl;

    /* FORWARD the RREQ if the TTL allows it. */
    DEBUG(LOG_INFO, 0, "forwarding RREQ src=%s, rreq_id=%lu",
          ip_to_str(orig), ntohl(rreq->rreq_id));

    /* Queue the received message in the send buffer */
#ifndef OMNETPP
    rreq = (RREQ *) aodv_socket_queue_msg((AODV_msg *) rreq, size);
    rreq->hcnt++;       /* Increase hopcount to account for
                 * intermediate route */

    /* Send out on all interfaces */
    for (i = 0; i < MAX_NR_INTERFACES; i++)
    {
        if (!DEV_NR(i).enabled)
            continue;
        aodv_socket_send((AODV_msg *) rreq, dest, size, ttl, &DEV_NR(i));
#else
    rreq->hcnt++;       /* Increase hopcount to account for
                 * intermediate route */
    if (this->isStaticNode())
        rreq->hopfix++;
    /* Send out on all interfaces */
    double delay = -1;
    if (par("EqualDelay"))
        delay = par("broadcastDelay");

    //select next hop based on q value (RL action)
    ManetAddress id;
    double maxQ=0, randNum=0, random=0;
    int num=0;

    /* select the next hop based on Q-value using exploration rate*/
    random =  ((double) rand() / (RAND_MAX+1));

   // forFile<<"criticality < thrsh"<<endl;
    //forFile<<"random: "<<random<<endl;
    //forFile<<"max capacity"<<maxCapacity<<endl;
    for (AodvRtTableMap::iterator it2 = aodvRtTableMap.begin(); it2 != aodvRtTableMap.end(); it2++) //using exploitation
    {
        if( it2->first == it2->second->next_hop.S_addr )
        {
            AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it2->first);
            if( checkNei!=aodvNeiTableMap.end() && checkNei->second->trusted == true && /*checkNei->second->energy >= energyThrshold &&*/ rreq->prev_src != it2->first /*&& rreq->orig_addr != it2->first*/)
            {
                //forFile<<"nexthop:"<<it2->first<<" qval:"<<checkNei->second->q_value<<endl;
                if(checkNei->second->q_value >= maxQ)
                {
                    maxQ = checkNei->second->q_value;
                    id = it2->first;
                }
            }
        }
    }
    //forFile<<"maxQ: "<<maxQ<<" id: "<<id<<endl;
    if( random < epsilon)   //using exploration
    {
        //forFile<<"random < epsilon"<<endl;
        for (AodvRtTableMap::iterator it2 = aodvRtTableMap.begin(); it2 != aodvRtTableMap.end(); it2++)
        {
            if( it2->first == it2->second->next_hop.S_addr )
            {
                AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it2->first);
                if( checkNei!=aodvNeiTableMap.end() && checkNei->second->trusted == true && /*checkNei->second->energy >= energyThrshold &&*/ rreq->prev_src != it2->first /*&& rreq->orig_addr != it2->first*/)
                    if(it2->first != id)
                        num++;
            }
        }
        if(num != 0)
        {
            randNum = ((double) ( rand() % num ) + 1);
            num=0;
            for (AodvRtTableMap::iterator it2 = aodvRtTableMap.begin(); it2 != aodvRtTableMap.end(); it2++)
            {
                if( it2->first == it2->second->next_hop.S_addr )
                {
                    AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it2->first);
                    if( checkNei!=aodvNeiTableMap.end() && checkNei->second->trusted == true && /*checkNei->second->energy >= energyThrshold &&*/ rreq->prev_src != it2->first /*&& rreq->orig_addr != it2->first*/)
                        if(it2->first != id)
                        {
                            num++;
                            if( num == randNum )
                            {
                                id = it2->first;
                                maxQ= checkNei->second->q_value;
                                break;
                            }
                        }
                    }
            }
            //forFile<<"num: "<<num<<"  id:"<<id<<endl;
        }
    }
    //testFile<<"maxQ: "<<maxQ<<" id: "<<id<<endl;
    //forFile<<"id:"<<id<<"maxQ:"<<maxQ<<endl;
    /* forward rreq to the selected neighbor*/
    for (i = 0; i < MAX_NR_INTERFACES; i++)
    {
        if (!DEV_NR(i).enabled)
            continue;
        //totalRreqSend++;
        //dest.S_addr = id;
        RREQ * rreq_new = new RREQ();
        struct in_addr nei;
        rreq->inter_dest_addr = id;
        rreq->delay = simTime() - rreq->src_time;
        rreq->sender_x = myPos.x;
        rreq->sender_y = myPos.y;
        //forFile<<"delay:"<<rreq->delay<<endl;
        rreq->totalDelay = rreq->totalDelay + rreq->delay;
        //forFile<<"preveiuos source:"<<rreq->prev_src<<" with delay of: "<<rreq->delay<<endl;
        rreq->src_time = simTime();
      //  rreq->futurQValue = futurQ;
      //  testFile<<"rreq->futurq:"<<rreq->futurQValue<<endl;
        //put path trust
        AodvNeiTableMap::iterator it3 = aodvNeiTableMap.find(id);
        if(it3->second->Ttrust != -1)
        {
            if(rreq->pathTrust != -1)
                rreq->pathTrust = rreq->pathTrust * it3->second->Ttrust;
            else
                rreq->pathTrust = it3->second->Ttrust;
        }
       // forFile<<"path trust:"<<rreq->pathTrust<<endl;
        rreq_new = check_and_cast <RREQ*>(rreq->dup());
        EV<<"after duplicate: "<<rreq_new->prev_src<<"\t"<<rreq_new->cur_src<<"\t"<<rreq_new->criticality<<endl;
        rreq_new->ttl=ttl;
        aodv_socket_send((AODV_msg *) rreq_new, dest, size, ttl, &DEV_NR(i),delay);
        nei.S_addr = rreq_new->inter_dest_addr;
        inc_forwardTo_packet(nei);
        addr->time = simTime();
        addr->ad = id;
        //forFile<<addr->ad<<"  "<<addr->time<<"   "<<rreq_new->rreq_id<<endl;
        aodvQValueMap.insert(std::make_pair(rreq_new->rreq_id,addr));
        AodvQValueMap::iterator it4 = aodvQValueMap.find(rreq_new->rreq_id);
        //forFile<<"neighbor inserted in q table map:"<<it4->second->ad<<" at: "<<it4->second->time<<endl;
        //testFile<<"packet rreq forwarded from "<<rreq_new->cur_src<<" to "<<dest.S_addr<<endl;
        //testFile<<"intermediate destination node "<<rreq_new->inter_dest_addr<<endl;
        //forFile<<"packet rreq forwarded from "<<rreq_new->cur_src<<" to "<<dest.S_addr<<endl;
       // forFile<<"intermediate destination node "<<rreq_new->inter_dest_addr<<endl;
        //forFile<<endl;
        //testFile<<"\n\n";
    }

/*    for (AodvNeiTableMap::iterator it3 = aodvNeiTableMap.begin(); it3 != aodvNeiTableMap.end(); it3++)
    {
        if( it3->first == it3->second->next_hop.S_addr )
        {
            AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it3->first);
            if( checkNei!=aodvNeiTableMap.end() && checkNei->second->trusted == true && checkNei->second->energy >= energyThrshold && rreq->prev_src != it3->first)
                forFile<<it3->first<<": qValue:"<<it3->second->q_value<<" futureReward: "<<it3->second->futureValue<<endl;
        }
    }*/

    //forFile<<"\n\n\n"<<endl;
    //forFile.close();
    //testFile.close();
  #endif
}

void NS_CLASS rreq_process(RREQ * rreq, int rreqlen, struct in_addr ip_src,
                           struct in_addr ip_dst, int ip_ttl,
                           unsigned int ifindex)
{
    AODV_ext *ext=NULL;
    RREP *rrep = NULL;
    int rrep_size = RREP_SIZE;
    rt_table_t *rev_rt=NULL, *fwd_rt = NULL;
    nei_table_t *rev_nei=NULL;
    u_int32_t rreq_orig_seqno, rreq_dest_seqno;
    u_int32_t rreq_id, rreq_new_hcnt, life;
    unsigned int extlen = 0;
    struct in_addr rreq_dest, rreq_orig;
    uint32_t cost;
    uint8_t  hopfix;
    simtime_t rreq_new_delay;
    double new_pathTrust;
    std::fstream qFile;
    qFile.open("QValue.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    //std::fstream pFile;
    //pFile.open("ProcessRREQ.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    //std::fstream idFile;
    //idFile.open("RREQid.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    std::fstream delFile;
    delFile.open("Delay.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    //std::fstream testFile;
    //testFile.open("test.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    //pFile<<"rreq processing in"<< DEV_IFINDEX(ifindex).ipaddr.s_addr<<" at "<<simTime()<<endl;
   // delFile<<rreq->totalDelay<<endl;


   /*update q-value of the rreq's sender, if the neighbor forwarded the packet, that we sent to it before (listening to neighbors)*/
   /* and increment number of forwarded packets by neighbor*/
    if (isLocalAddress (rreq->prev_src))
    {
       //pFile<<"entering update q-value at"<<simTime()<<endl;
       //qFile<<endl;
       //qFile<<"orig:"<<rreq->orig_addr<<endl;
       //qFile<<rreq->prev_src<<": update "<<rreq->cur_src<<" Q value at "<<simTime()<<endl;
       //pFile<<rreq->prev_src<<": update "<<rreq->cur_src<<" Q value"<<endl;
      // qFile<<"futurQ: "<<rreq->futurQValue<<endl;
      // qFile<<"Entering q_value update"<<endl;
       struct in_addr nei_addr;
       nei_addr.S_addr = rreq->cur_src;
       inc_forwarded_packet(nei_addr);
       /*AodvQValueMap::iterator it4 = aodvQValueMap.find(rreq->rreq_id);
       if( it4 != aodvQValueMap.end())
       {
           pFile<<" deleting "<<it4->second->ad<<" from q table map"<<endl;
           aodvQValueMap.erase(rreq->rreq_id);
       }*/
       //Q_value_check();
       //q_value_update(nei_addr, rreq);
    }

    if(!isLocalAddress (rreq->inter_dest_addr))   //if this node is not selected as the next hop, drop it
    {
        //pFile<<"this is not the intermediate destination node at"<<simTime()<<endl;
       // delete rreq;
        return;
    }


    /* if the criticality is high and the energy of the receiver is low , with high probability process rreq, with low probability discard rreq
    pFile<<"rreq_process"<<" in "<<rreq->cur_src<<endl;
    pFile<<"ttl of rreq: "<<rreq->ttl<<endl;
    pFile<<"ttl of ip_ttl: "<<ip_ttl<<endl;

    srand((unsigned)time(NULL));
    BasicBattery *bt = BatteryAccess().get();

    double random = ((double) rand() / (RAND_MAX+1));
    double dropThrsh = (double) (bt->GetEnergy()) /maxCapacity;
    if((rreq->criticality > CRITIC_THRSH) && (bt->GetEnergy() < energyThrsh))
        if (random > dropThrsh)
        {
           //notify the sender that we do not forward the packet
            return;
        }
*/

    ManetAddress aux;
    if (getAp(rreq->dest_addr, aux) && !isBroadcast(rreq->dest_addr))
    {
        rreq_dest.s_addr = aux;
    }
    else
        rreq_dest.s_addr = rreq->dest_addr;

    if (getAp(rreq->orig_addr, aux))
    {
        rreq_orig.s_addr = aux;
    }
    else
        rreq_orig.s_addr = rreq->orig_addr;
    rreq_id = ntohl(rreq->rreq_id);
    rreq_dest_seqno = ntohl(rreq->dest_seqno);
    rreq_orig_seqno = ntohl(rreq->orig_seqno);
    rreq_new_hcnt = rreq->hcnt + 1;
    rreq_new_delay = rreq->totalDelay + simTime() - rreq->src_time;  //total delay of the rreq untill now
    new_pathTrust = rreq->pathTrust;

    cost = rreq->cost;
    hopfix = rreq->hopfix;
    if (this->isStaticNode())
        hopfix++;


    /* Ignore RREQ's that originated from this node. Either we do this
           or we buffer our own sent RREQ's as we do with others we
           receive. */

/*#ifndef OMNETPP
    if (rreq_orig.s_addr == DEV_IFINDEX(ifindex).ipaddr.s_addr)
        return;
#else
    if (isLocalAddress (rreq_orig.s_addr))
        return;
#endif*/

    DEBUG(LOG_DEBUG, 0, "ip_src=%s rreq_orig=%s rreq_dest=%s",
          ip_to_str(ip_src), ip_to_str(rreq_orig), ip_to_str(rreq_dest));
#ifdef OMNETPP
   // totalRreqRec++;
    /*pFile << "RREQ received, Src Address :" << convertAddressToString(ip_src.s_addr) << "  RREQ origin :" <<
            convertAddressToString(rreq_orig.s_addr) << "  RREQ dest :" << convertAddressToString(rreq_dest.s_addr) << "\n";*/
#endif

    if ((int)(sizeof(rreq)*8) < (int) RREQ_SIZE)
    {
        alog(LOG_WARNING, 0,
             __FUNCTION__, "IP data field too short (%u bytes)"
             "from %s to %s", rreqlen, ip_to_str(ip_src), ip_to_str(ip_dst));
       // pFile<<"rrelen:"<<rreqlen<<"rreq size"<<(int)RREQ_SIZE<<endl;
        return;
    }

    /* check if the previous hop is untrusted. if it is, then ignore the RREQ     */
    nei_table_t *entry;
    entry=nei_table_find(ip_src);
    /*if(entry)
       if(entry->trusted == false)
       {
           //pFile<<"sender is not trusted"<<endl;
           return;
       }*/


    /* Check if the previous hop of the RREQ is in the blacklist set. If
       it is, then ignore the RREQ. */
    if (rreq_blacklist_find(ip_src))
    {
        DEBUG(LOG_DEBUG, 0, "prev hop of RREQ blacklisted, ignoring!");
#ifdef OMNETPP

#endif
        //pFile<<"blacklist"<<endl;
        return;
    }
    /* Ignore already processed RREQs. prevents from loop*/
    if (rreq_record_find(rreq_orig, rreq_id))
    {
#ifdef OMNETPP
        if (isBroadcast(rreq_dest.s_addr))
        {

           if (par("proactiveLifeTime").longValue() > 0 )
               life = par("proactiveLifeTime").longValue() ;
           else
               life = PATH_DISCOVERY_TIME - 2 * rreq_new_hcnt * NODE_TRAVERSAL_TIME;
           rev_rt = rt_table_find(rreq_orig);
           if (rev_rt == NULL)
           {
               rev_nei=nei_table_find(rreq_orig);
               if(rev_nei == NULL)
                   rev_rt = rt_table_insert(rreq_orig, ip_src, rreq_new_hcnt, rreq_orig_seqno, life, VALID, 0, ifindex,cost,hopfix, true, true, rreq_new_delay, new_pathTrust );
                   // opp_error("reverse route NULL with RREQ in the processed table" );
               else
                   rev_rt = rt_table_insert(rreq_orig, ip_src, rreq_new_hcnt, rreq_orig_seqno, life, VALID, 0, ifindex,cost,hopfix, rev_nei->trusted, rev_nei->blacklist, rreq_new_delay, new_pathTrust );

           }
           if (rev_rt->dest_seqno != 0)
           {
               if ((int32_t) rreq_orig_seqno < (int32_t) rev_rt->dest_seqno)
                   return;
               if (!useHover && (rreq_orig_seqno == rev_rt->dest_seqno &&
                   (rev_rt->state != INVALID && rreq_new_hcnt >= rev_rt->hcnt)))
                   return;
               /*if (!useHover && (rreq_orig_seqno == rev_rt->dest_seqno &&
                 (rev_rt->state != INVALID && new_pathTrust <= rev_rt->pathTrust)))
                   return;*/
/*               if (!useHover && (rreq_orig_seqno == rev_rt->dest_seqno &&
                  (rev_rt->state != INVALID && rreq_new_delay >= rev_rt->delay)))
                  return;*/
               if (useHover && (rreq_orig_seqno == rev_rt->dest_seqno &&
                   (rev_rt->state != INVALID && cost >= rev_rt->cost)))
               {
                   //pFile<<"rev_rt cost"<<endl;
                   return;
               }
           }
        }
        else
#endif
        {
            life = PATH_DISCOVERY_TIME - 2 * rreq_new_hcnt * NODE_TRAVERSAL_TIME;
            rev_rt = rt_table_find(rreq_orig);
            if (rev_rt == NULL)
            {
                rev_nei=nei_table_find(rreq_orig);
                if (rev_nei == NULL)
                    rev_rt = rt_table_insert(rreq_orig, ip_src, rreq_new_hcnt,rreq_orig_seqno, life, VALID, 0, ifindex,cost,hopfix,true, true, rreq_new_delay, new_pathTrust);
                    // opp_error("reverse route NULL with RREQ in the processed table" );
                else
                    rev_rt = rt_table_insert(rreq_orig, ip_src, rreq_new_hcnt,rreq_orig_seqno, life, VALID, 0, ifindex,cost,hopfix, rev_nei->trusted, rev_nei->blacklist, rreq_new_delay, new_pathTrust);
            }
            if (!useHover && (rev_rt->dest_seqno == 0 ||
                  (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
                  (rreq_orig_seqno == rev_rt->dest_seqno &&
                   (rev_rt->state == INVALID || rreq_new_hcnt < rev_rt->hcnt))))
/*            if (!useHover && (rev_rt->dest_seqno == 0 ||
                              (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
                              (rreq_orig_seqno == rev_rt->dest_seqno &&
                               (rev_rt->state == INVALID || rreq_new_delay < rev_rt->delay))))*/
/*            if (!useHover && (rev_rt->dest_seqno == 0 ||
                              (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
                              (rreq_orig_seqno == rev_rt->dest_seqno &&
                               (rev_rt->state == INVALID || new_pathTrust > rev_rt->pathTrust))))*/
           {
               rev_rt = rt_table_update(rev_rt, ip_src, rreq_new_hcnt,
                                        rreq_orig_seqno, life, VALID,
                                        rev_rt->flags,ifindex,cost,hopfix, rev_rt->trusted, rev_rt->blacklist, rreq_new_delay, new_pathTrust);
           }
            if (useHover && (rev_rt->dest_seqno == 0 ||
                    (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
                    (rreq_orig_seqno == rev_rt->dest_seqno &&
                     (rev_rt->state == INVALID || cost < rev_rt->cost))))
            {
                //pFile<<"*******************************"<<endl;
                life = PATH_DISCOVERY_TIME - 2 * rreq_new_hcnt * NODE_TRAVERSAL_TIME;
                rev_rt = rt_table_update(rev_rt, ip_src, rreq_new_hcnt,
                                         rreq_orig_seqno, life, VALID,
                                         rev_rt->flags,ifindex,cost,hopfix, rev_rt->trusted, rev_rt->blacklist, rev_rt->delay, rev_rt->pathTrust);
            }
            return;
        }
    }

    /* Now buffer this RREQ so that we don't process a similar RREQ we
       get within PATH_DISCOVERY_TIME. */
    rreq_record_insert(rreq_orig, rreq_id);

    /* Determine whether there are any RREQ extensions */


#ifndef OMNETPP
    ext = (AODV_ext *) ((char *) rreq + RREQ_SIZE);
    while ((rreqlen - extlen) > RREQ_SIZE)
    {
#else
    ext = rreq->getFirstExtension();
    for (int i=0; i<rreq->getNumExtension (); i++)
    {
#endif
        switch (ext->type)
        {
        case RREQ_EXT:
            DEBUG(LOG_INFO, 0, "RREQ include EXTENSION");
            /* Do something here */
            break;
        default:
            alog(LOG_WARNING, 0, __FUNCTION__, "Unknown extension type %d",
                 ext->type);
            break;
        }
        extlen += AODV_EXT_SIZE(ext);
        ext = AODV_EXT_NEXT(ext);
    }
#ifdef DEBUG_OUTPUT
    log_pkt_fields((AODV_msg *) rreq);
#endif

    /* The node always creates or updates a REVERSE ROUTE entry to the
       source of the RREQ. */
    rev_rt = rt_table_find(rreq_orig);

    /* Calculate the extended minimal life time. */
    life = PATH_DISCOVERY_TIME - 2 * rreq_new_hcnt * NODE_TRAVERSAL_TIME;

    if (rev_rt == NULL)
    {
        DEBUG(LOG_DEBUG, 0, "Creating REVERSE route entry, RREQ orig: %s",
              ip_to_str(rreq_orig));
        rev_nei= nei_table_find(rreq_orig);
        if(rev_nei == NULL)
            rev_rt = rt_table_insert(rreq_orig, ip_src, rreq_new_hcnt,
                                     rreq_orig_seqno, life, VALID, 0, ifindex,cost,hopfix, true, true, rreq_new_delay, new_pathTrust);
        else
            rev_rt = rt_table_insert(rreq_orig, ip_src, rreq_new_hcnt,
                                              rreq_orig_seqno, life, VALID, 0, ifindex,cost,hopfix, rev_nei->trusted, rev_nei->blacklist, rreq_new_delay, new_pathTrust);
    }
    else
    {
        if (!useHover && (rev_rt->dest_seqno == 0 ||
                (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
                (rreq_orig_seqno == rev_rt->dest_seqno &&
                 (rev_rt->state == INVALID || rreq_new_hcnt < rev_rt->hcnt))))
/*        if (!useHover && (rev_rt->dest_seqno == 0 ||
               (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
               (rreq_orig_seqno == rev_rt->dest_seqno &&
                (rev_rt->state == INVALID || rreq_new_delay < rev_rt->delay))))*/
/*        if (!useHover && (rev_rt->dest_seqno == 0 ||
               (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
               (rreq_orig_seqno == rev_rt->dest_seqno &&
                (rev_rt->state == INVALID || new_pathTrust > rev_rt->pathTrust))))*/
        {
            rev_rt = rt_table_update(rev_rt, ip_src, rreq_new_hcnt,
                                     rreq_orig_seqno, life, VALID,
                                     rev_rt->flags,ifindex,cost,hopfix, rev_rt->trusted, rev_rt->blacklist, rreq_new_delay, new_pathTrust);
        }


        else if (useHover && (rev_rt->dest_seqno == 0 ||
                (int32_t) rreq_orig_seqno > (int32_t) rev_rt->dest_seqno ||
                (rreq_orig_seqno == rev_rt->dest_seqno &&
                 (rev_rt->state == INVALID || cost < rev_rt->cost))))
        {
            rev_rt = rt_table_update(rev_rt, ip_src, rreq_new_hcnt,
                                     rreq_orig_seqno, life, VALID,
                                     rev_rt->flags,ifindex,cost,hopfix, rev_rt->trusted, rev_rt->blacklist, rreq_new_delay, rev_rt->pathTrust);
        }

#ifdef DISABLED
        /* This is a out of draft modification of AODV-UU to prevent
           nodes from creating routing entries to themselves during
           the RREP phase. We simple drop the RREQ if there is a
           missmatch between the reverse path on the node and the one
           suggested by the RREQ. */

        else if (rev_rt->next_hop.s_addr != ip_src.s_addr)
        {
            DEBUG(LOG_DEBUG, 0, "Dropping RREQ due to reverse route mismatch!");
            return;
        }
#endif
    }
    /**** END updating/creating REVERSE route ****/

#ifdef CONFIG_GATEWAY
    /* This is a gateway */
    if (internet_gw_mode)
    {
        /* Subnet locality decision */
        switch (locality(rreq_dest, ifindex))
        {
        case HOST_ADHOC:
            break;
        case HOST_INET:
            /* We must increase the gw's sequence number before sending a RREP,
             * otherwise intermediate nodes will not forward the RREP. */
            seqno_incr(this_host.seqno);
            rrep = rrep_create(0, 0, 0, DEV_IFINDEX(rev_rt->ifindex).ipaddr,
                               this_host.seqno, rev_rt->dest_addr,
                               ACTIVE_ROUTE_TIMEOUT, 0);
            rrep->totalHops =  rev_rt->hcnt;

            ext = rrep_add_ext(rrep, RREP_INET_DEST_EXT, rrep_size,
                               sizeof(struct in_addr), (char *) &rreq_dest);

            rrep_size += AODV_EXT_SIZE(ext);

            DEBUG(LOG_DEBUG, 0,
                  "Responding for INTERNET dest: %s rrep_size=%d",
                  ip_to_str(rreq_dest), rrep_size);

            rrep_send(rrep, rev_rt, NULL, rrep_size);

            return;

        case HOST_UNKNOWN:
        default:
            DEBUG(LOG_DEBUG, 0, "GW: Destination unkown");
        }
    }
#endif

    /*create and send ack msg to the sender of the node using rrep msg, regardless of fwd_rt
    EV<<"create and send ack msg to the sender of the node using rrep msg"<<endl;
    //struct in_addr dest;
    //dest.S_addr = rreq->dest_addr;

    rrep = rrep_create(0, 0, 0, DEV_IFINDEX(rev_rt->ifindex).ipaddr, this_host.seqno, rev_rt->dest_addr, ACTIVE_ROUTE_TIMEOUT, 1);
    rrep->src_addr.S_addr = DEV_IFINDEX(ifindex).ipaddr.s_addr;
    EV<<"current node address: "<<rrep->src_addr.S_addr<<endl;
    rrep_send(rrep, rev_rt, NULL, rrep_size);*/

#ifdef OMNETPP
    if (getIsGateway())
    {
        /* Subnet locality decision */
        // search address
        if (isAddressInProxyList(rreq_dest.s_addr))
        {
            /* We must increase the gw's sequence number before sending a RREP,
             * otherwise intermediate nodes will not forward the RREP. */
            seqno_incr(this_host.seqno);
            rrep = rrep_create(0, 0, 0, DEV_IFINDEX(rev_rt->ifindex).ipaddr,
                               this_host.seqno, rev_rt->dest_addr,
                               ACTIVE_ROUTE_TIMEOUT);

            ext = rrep_add_ext(rrep, RREP_INET_DEST_EXT, rrep_size,
                               sizeof(struct in_addr), (char *) &rreq_dest);

            rrep_size += AODV_EXT_SIZE(ext);


            DEBUG(LOG_DEBUG, 0,
                  "Responding for INTERNET dest: %s rrep_size=%d",
                  ip_to_str(rreq_dest), rrep_size);

            if (checkRrep)
                 rrep_send(rrep, rev_rt, NULL, rrep_size, par ("unicastDelay").doubleValue());
            else
                rrep_send(rrep, rev_rt, NULL, rrep_size);
            return;
        }
    }
#endif
    /* Are we the destination of the RREQ?, if so we should immediately send a
       RREP.. */
#ifndef OMNETPP
    if (rreq_dest.s_addr == DEV_IFINDEX(ifindex).ipaddr.s_addr)
    {
#else
    if (isLocalAddress (rreq_dest.s_addr))
    {
#endif
        totalRreqRec++;
        /* WE are the RREQ DESTINATION. Update the node's own
           sequence number to the maximum of the current seqno and the
           one in the RREQ. */
        //idFile<<rreq->rreq_id<<"delivered to "<<DEV_IFINDEX(ifindex).ipaddr.s_addr<<" at "<<simTime()<<endl;
        //pFile<<" Destination found"<<endl;
        delFile<<rreq->totalDelay<<endl;
        if (rreq_dest_seqno != 0)
        {
            if ((int32_t) this_host.seqno < (int32_t) rreq_dest_seqno)
                this_host.seqno = rreq_dest_seqno;
            else if (this_host.seqno == rreq_dest_seqno)
                seqno_incr(this_host.seqno);
        }
        /*aodvRoutCostMap.insert(std::make_pair(rev_rt,rreq->rout_cost));
        pFile<<"size of cost table map: "<<aodvRoutCostMap.size()<<endl;
        pFile<<"size of rt table:"<<aodvRtTableMap.size()<<endl;
        if(aodvRoutCostMap.size() > 0.5 * aodvRtTableMap.size())
        {
            rt_table_t * minCost_entry = (rt_table_t *) malloc(sizeof(rt_table_t));
            double minCost=0;
            AodvRoutCostMap::iterator it2=aodvRoutCostMap.begin();
            minCost=it2->second;
            for(AodvRoutCostMap::iterator it=aodvRoutCostMap.begin(); it!=aodvRoutCostMap.end(); it++)
            {
                pFile<<it->second<<"\t";
                if(it->second <= minCost)
                {
                    minCost = it->second;
                    minCost_entry = it->first;
                }
            }
            rev_rt = minCost_entry;
            rrep = rrep_create(0, 0, 0, DEV_IFINDEX(rev_rt->ifindex).ipaddr,
                               this_host.seqno, rev_rt->dest_addr,
                               MY_ROUTE_TIMEOUT, 0);
            pFile<<"rrep created"<<endl;
            rrep->totalHops =  rev_rt->hcnt;
            rrep->totalDelay = rev_rt->delay;
#ifdef OMNETPP
            EV << " create a rrep" << convertAddressToString(DEV_IFINDEX(rev_rt->ifindex).ipaddr.s_addr) << "seq n" << this_host.seqno << " to " << convertAddressToString(rev_rt->dest_addr.s_addr) << "\n";
#endif

            rrep_send(rrep, rev_rt, NULL, RREP_SIZE);
            pFile<<"rrep sent"<<endl;
        }*/
        rrep = rrep_create(0, 0, 0, DEV_IFINDEX(rev_rt->ifindex).ipaddr,
                           this_host.seqno, rev_rt->dest_addr,
                           MY_ROUTE_TIMEOUT);
        rrep->totalHops =  rev_rt->hcnt;
        rrep->totalDelay = rev_rt->delay;
#ifdef OMNETPP
        //pFile << " create a rrep" << convertAddressToString(DEV_IFINDEX(rev_rt->ifindex).ipaddr.s_addr) << "seq n" << this_host.seqno << " to " << convertAddressToString(rev_rt->dest_addr.s_addr) << "\n";
#endif

        rrep_send(rrep, rev_rt, NULL, RREP_SIZE);
    }
    else if (isBroadcast (rreq_dest.s_addr))
    {
        totalRreqRec++;
        if(!rreq->d)
            return;
        if (!propagateProactive)
            return;

        /* WE are the RREQ DESTINATION. Update the node's own
           sequence number to the maximum of the current seqno and the
           one in the RREQ. */
        seqno_incr(this_host.seqno);
        rrep = rrep_create(0, 0, 0, DEV_IFINDEX(rev_rt->ifindex).ipaddr,this_host.seqno, rev_rt->dest_addr, MY_ROUTE_TIMEOUT);
        rrep->totalHops =  rev_rt->hcnt;
        rrep->totalDelay = rev_rt->delay;
        //pFile << "Create a rrep" << convertAddressToString(DEV_IFINDEX(rev_rt->ifindex).ipaddr.s_addr) << "seq n" << this_host.seqno << " to " << convertAddressToString(rev_rt->dest_addr.s_addr) << "\n";
        rrep_send(rrep, rev_rt, NULL, RREP_SIZE);
        if (ip_ttl > 0)
        {
            rreq_forward(rreq, rreqlen, ip_ttl); // the ttl is decremented for ip layer
        }
        else
        {
            DEBUG(LOG_DEBUG, 0, "RREQ not forwarded - ttl=0");
            //pFile << "RREQ not forwarded - ttl=0 (in broadcast)" << "\n";
        }
        return;
    }
    else
    {
        /* We are an INTERMEDIATE node. - check if we have an active
         * route entry */
#ifdef OMNETPP
        actualizeTablesWithCollaborative(rreq_dest.s_addr);
#endif
        fwd_rt = rt_table_find(rreq_dest);

        if (fwd_rt && (fwd_rt->state == VALID || fwd_rt->state == IMMORTAL) && !rreq->d)
        {
            struct timeval now;
            u_int32_t lifetime;

            /* GENERATE RREP, i.e we have an ACTIVE route entry that is fresh
               enough (our destination sequence number for that route is
               larger than the one in the RREQ). */

            gettimeofday(&now, NULL);
#ifdef CONFIG_GATEWAY_DISABLED
            if (fwd_rt->flags & RT_INET_DEST)
            {
                rt_table_t *gw_rt;
                /* This node knows that this is a rreq for an Internet
                 * destination and it has a valid route to the gateway */

                goto forward;   // DISABLED

                gw_rt = rt_table_find(fwd_rt->next_hop);

                if (!gw_rt || gw_rt->state == INVALID)
                    goto forward;

                lifetime = timeval_diff(&gw_rt->rt_timer.timeout, &now);

                rrep = rrep_create(0, 0, gw_rt->hcnt, gw_rt->dest_addr,
                                   gw_rt->dest_seqno, rev_rt->dest_addr,
                                   lifetime, 0);
                rrep->totalHops =  rev_rt->hcnt;

                ext = rrep_add_ext(rrep, RREP_INET_DEST_EXT, rrep_size,
                                   sizeof(struct in_addr), (char *) &rreq_dest);

                rrep_size += AODV_EXT_SIZE(ext);

                DEBUG(LOG_DEBUG, 0,
                      "Intermediate node response for INTERNET dest: %s rrep_size=%d",
                      ip_to_str(rreq_dest), rrep_size);

                // clean entry
                rrep_send(rrep, rev_rt, gw_rt, rrep_size);
                return;
            }
#endif              /* CONFIG_GATEWAY_DISABLED */

            /* Respond only if the sequence number is fresh enough... */
//      if ((fwd_rt->dest_seqno != 0 &&
//      (int32_t) fwd_rt->dest_seqno >= (int32_t) rreq_dest_seqno &&
//                (fwd_rt->hcnt>HCNT_LIMIT || (fwd_rt->hcnt==HCNT_LIMIT && uniform(0, 1)>0.8 ))) || fwd_rt->state==IMMORTAL) {
            if ((fwd_rt->dest_seqno != 0 &&
                    (int32_t) fwd_rt->dest_seqno >= (int32_t) rreq_dest_seqno &&
                    (fwd_rt->hcnt>HCNT_LIMIT))|| fwd_rt->state==IMMORTAL)
            {
//      if (fwd_rt->dest_seqno != 0 &&
//      (int32_t) fwd_rt->dest_seqno >= (int32_t) rreq_dest_seqno) {
#ifdef AODV_USE_STL
                if (fwd_rt->state==IMMORTAL)
                    lifetime = 10000;
                else
                {
                    double val = SIMTIME_DBL(fwd_rt->rt_timer.timeout - simTime());
                    lifetime = (val * 1000.0);
                }
#else
                if (fwd_rt->state==IMMORTAL)
                    lifetime = 10000;
                else
                    lifetime = timeval_diff(&fwd_rt->rt_timer.timeout, &now);
#endif
                rrep = rrep_create(0, 0, fwd_rt->hcnt, fwd_rt->dest_addr,
                                   fwd_rt->dest_seqno, rev_rt->dest_addr,
                                   lifetime);
                rrep->totalHops =  rev_rt->hcnt + fwd_rt->hcnt;
                rrep->totalDelay = rev_rt->delay + fwd_rt->delay;
                delFile<<"rev_rt:"<<rev_rt->delay<<" fwd_rt: "<<fwd_rt->delay<<endl;
                delFile<<"inter: "<<rrep->totalDelay<<endl;
                rrep_send(rrep, rev_rt, fwd_rt, rrep_size);
                /* If the GRATUITOUS flag is set, we must also unicast a
                   gratuitous RREP to the destination. */
                if (rreq->g)
                {
                    rrep = rrep_create(0, 0, rev_rt->hcnt, rev_rt->dest_addr,
                                       rev_rt->dest_seqno, fwd_rt->dest_addr,
                                       lifetime);
                    rrep->totalHops =  rev_rt->hcnt + fwd_rt->hcnt;
                    rrep->totalDelay = rev_rt->delay + fwd_rt->delay;
                    rrep_send(rrep, fwd_rt, rev_rt, RREP_SIZE);
                    DEBUG(LOG_INFO, 0, "Sending G-RREP to %s with rte to %s",
                          ip_to_str(rreq_dest), ip_to_str(rreq_orig));
                }
                totalRreqRec++;
                //idFile<<rreq->rreq_id<<" delivered to "<<DEV_IFINDEX(ifindex).ipaddr.s_addr<<" at "<<simTime()<<endl;
                return;
            }
            /*
                        else
                        {
                            goto forward;
                        }
            //      If the GRATUITOUS flag is set, we must also unicast a
            //             gratuitous RREP to the destination.
                        if (rreq->g)
                        {
                            rrep = rrep_create(0, 0, rev_rt->hcnt, rev_rt->dest_addr,
                               rev_rt->dest_seqno, fwd_rt->dest_addr,
                               lifetime, 0);

                            rrep_send(rrep, fwd_rt, rev_rt, RREP_SIZE);

                            DEBUG(LOG_INFO, 0, "Sending G-RREP to %s with rte to %s",
                                    ip_to_str(rreq_dest), ip_to_str(rreq_orig));
                        }
                        return;
            */
        }

forward:
#ifndef OMNETPP
        if (ip_ttl > 1)
#else
        if (ip_ttl > 0)
#endif
        {

            //pFile<<" process forwarding..."<<endl;
           // show_table();
            /*put the list of qvalue of neighbors in the q_list of rreq packet */
            //rreq->q_list = q_list_add();

/*
            //print neighbors
            qlist *cur = new qlist();
            cur = rreq->q_list;

            while(cur)
            {
                EV<<cur->qvalue<<endl;
                cur= cur->next;
            }
*/

            EV<<"previous source address 1: "<<rreq->prev_src<<endl;
            EV<<"current source address 1: "<<rreq->cur_src<<endl;
            /*put the sender of the rreq in prev_src (in order to use for listening in the sender-updating qvalue)*/
            struct in_addr cur;
            cur.S_addr = rreq->cur_src;
            rreq->prev_src = cur.S_addr; //rreq->cur_src;
            rreq->cur_src = DEV_IFINDEX(ifindex).ipaddr.s_addr;
            //AodvNeiTableMap::iterator it = aodvNeiTableMap.find(rreq->prev_src);
            //rreq->helloRcvd_no = it->second->hello_rcvd;  //not used

           // pFile<<"previous source address 2: "<<rreq->prev_src<<endl;
           // pFile<<"current source address 2: "<<rreq->cur_src<<endl;




            /* Update the sequence number in case the maintained one is larger */
            if (fwd_rt && (fwd_rt->state == VALID || fwd_rt->state == IMMORTAL) && !rreq->d && 0!=HCNT_LIMIT)
            {
                if (fwd_rt->dest_seqno != 0 &&
                (int32_t) fwd_rt->dest_seqno >= (int32_t) rreq_dest_seqno && fwd_rt->hcnt==HCNT_LIMIT)
                    ip_ttl = HCNT_LIMIT;
            }
            if (fwd_rt && !(fwd_rt->flags & RT_INET_DEST) &&
                    (int32_t) fwd_rt->dest_seqno > (int32_t) rreq_dest_seqno)
                rreq->dest_seqno = htonl(fwd_rt->dest_seqno);
#ifndef OMNETPP
            rreq_forward(rreq, rreqlen, --ip_ttl);
#else
            rreq_forward(rreq, rreqlen, ip_ttl); // the ttl is decremented for ip layer
#endif
        }
        else
        {
            DEBUG(LOG_DEBUG, 0, "RREQ not forwarded - ttl=0");
#ifdef OMNETPP
            //pFile << "RREQ not forwarded - ttl=0 ( in forwarding)" << "\n";
#endif
        }
    }
    //pFile.close();
    //idFile.close();
    delFile.close();
    qFile.close();
}

/* Perform route discovery for a unicast destination */

void NS_CLASS rreq_route_discovery(struct in_addr dest_addr, u_int8_t flags,
                                   struct ip_data *ipd)
{
    struct timeval now;
    rt_table_t *rt;
    seek_list_t *seek_entry;
    u_int32_t dest_seqno;
    int ttl;
    //std::fstream destFile;
    //destFile.open("Destinations.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    //destFile<<" from: "<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<" to: "<<"destination:"<<dest_addr.S_addr<<" at "<<simTime()<<endl;
#define TTL_VALUE ttl

    gettimeofday(&now, NULL);

    if (seek_list_find(dest_addr))
    {
        return;
    }

    /* If we already have a route entry, we use information from it. */
    rt = rt_table_find(dest_addr);

    ttl = NET_DIAMETER;     /* This is the TTL if we don't use expanding
                   ring search */
    if (!rt)
    {
        dest_seqno = 0;

        if (expanding_ring_search)
        {
            ttl = TTL_START;
            criticality = temp_criticality;
        }

    }
    else
    {
        dest_seqno = rt->dest_seqno;

        if (expanding_ring_search)
        {
            ttl = rt->hcnt + TTL_INCREMENT;
        }

        /*  if (rt->flags & RT_INET_DEST) */
        /*      flags |= RREQ_DEST_ONLY; */

        /* A routing table entry waiting for a RREP should not be expunged
           before 2 * NET_TRAVERSAL_TIME... */
#ifdef AODV_USE_STL
        if ((rt->rt_timer.timeout - simTime()) < (2 * NET_TRAVERSAL_TIME))
            rt_table_update_timeout(rt, 2 * NET_TRAVERSAL_TIME);
#else
        if (timeval_diff(&rt->rt_timer.timeout, &now) <
                (2 * NET_TRAVERSAL_TIME))
            rt_table_update_timeout(rt, 2 * NET_TRAVERSAL_TIME);
#endif
    }
    rreq_send(dest_addr, dest_seqno, ttl, flags, 0, -1);

    /* Remember that we are seeking this destination */
    seek_entry = seek_list_insert(dest_addr, dest_seqno, ttl, flags, ipd);


    /* Set a timer for this RREQ */
    if (expanding_ring_search)
        timer_set_timeout(&seek_entry->seek_timer, RING_TRAVERSAL_TIME);
    else
        timer_set_timeout(&seek_entry->seek_timer, NET_TRAVERSAL_TIME);

    DEBUG(LOG_DEBUG, 0, "Seeking %s ttl=%d", ip_to_str(dest_addr), ttl);
    //destFile.close();
    return;
}

/* Local repair is very similar to route discovery... */
void NS_CLASS rreq_local_repair(rt_table_t * rt, struct in_addr src_addr,
                                struct ip_data *ipd)
{
    struct timeval now;
    seek_list_t *seek_entry;
    rt_table_t *src_entry;
    int ttl;
    u_int8_t flags = 0;

    if (!rt)
        return;

    if (seek_list_find(rt->dest_addr))
        return;

    if (!(rt->flags & RT_REPAIR))
        return;

    gettimeofday(&now, NULL);

    DEBUG(LOG_DEBUG, 0, "REPAIRING route to %s", ip_to_str(rt->dest_addr));

    /* Caclulate the initial ttl to use for the RREQ. MIN_REPAIR_TTL
       mentioned in the draft is the last known hop count to the
       destination. */

    src_entry = rt_table_find(src_addr);

    if (src_entry)
        ttl = (int) (maxMacro(rt->hcnt, 0.5 * src_entry->hcnt) + LOCAL_ADD_TTL);
    else
        ttl = rt->hcnt + LOCAL_ADD_TTL;

    DEBUG(LOG_DEBUG, 0, "%s, rreq ttl=%d, dest_hcnt=%d",
          ip_to_str(rt->dest_addr), ttl, rt->hcnt);

    /* Reset the timeout handler, was probably previously
       local_repair_timeout */
    rt->rt_timer.handler = &NS_CLASS route_expire_timeout;

#ifdef AODV_USE_STL
    if ((rt->rt_timer.timeout -simTime()) < (2 * NET_TRAVERSAL_TIME))
        rt_table_update_timeout(rt, 2 * NET_TRAVERSAL_TIME);
#else
    if (timeval_diff(&rt->rt_timer.timeout, &now) < (2 * NET_TRAVERSAL_TIME))
        rt_table_update_timeout(rt, 2 * NET_TRAVERSAL_TIME);
#endif
    totalLocalRep++;
    rreq_send(rt->dest_addr, rt->dest_seqno, ttl, flags, 0, -1);

    /* Remember that we are seeking this destination and setup the
       timers */
    seek_entry = seek_list_insert(rt->dest_addr, rt->dest_seqno,
                                  ttl, flags, ipd);

    if (expanding_ring_search)
        timer_set_timeout(&seek_entry->seek_timer,
                          2 * ttl * NODE_TRAVERSAL_TIME);
    else
        timer_set_timeout(&seek_entry->seek_timer, NET_TRAVERSAL_TIME);

    DEBUG(LOG_DEBUG, 0, "Seeking %s ttl=%d", ip_to_str(rt->dest_addr), ttl);

    return;
}

// proactive RREQ
void NS_CLASS  rreq_proactive (void *arg)
{
    struct in_addr dest;
    if (!isRoot)
         return;
    if (this->isInMacLayer())
         dest.s_addr= ManetAddress(MACAddress::BROADCAST_ADDRESS);
    else
         dest.s_addr= ManetAddress(IPv4Address::ALLONES_ADDRESS);
    rreq_send(dest,0,NET_DIAMETER, RREQ_DEST_ONLY, 0, -1);
    timer_set_timeout(&proactive_rreq_timer, proactive_rreq_timeout);
}

#ifndef AODV_USE_STL
NS_STATIC struct rreq_record *NS_CLASS rreq_record_insert(struct in_addr orig_addr,
        u_int32_t rreq_id)
{
    struct rreq_record *rec;

    /* First check if this rreq packet is already buffered */
    rec = rreq_record_find(orig_addr, rreq_id);

    /* If already buffered, should we update the timer???  */
    if (rec)
        return rec;

    if ((rec =
                (struct rreq_record *) malloc(sizeof(struct rreq_record))) == NULL)
    {
        fprintf(stderr, "Malloc failed!!!\n");
        exit(-1);
    }
    rec->orig_addr = orig_addr;
    rec->rreq_id = rreq_id;

    timer_init(&rec->rec_timer, &NS_CLASS rreq_record_timeout, rec);

    list_add(&rreq_records, &rec->l);

    DEBUG(LOG_INFO, 0, "Buffering RREQ %s rreq_id=%lu time=%u",
          ip_to_str(orig_addr), rreq_id, PATH_DISCOVERY_TIME);

    timer_set_timeout(&rec->rec_timer, PATH_DISCOVERY_TIME);
    return rec;
}

NS_STATIC struct rreq_record *NS_CLASS rreq_record_find(struct in_addr orig_addr,
        u_int32_t rreq_id)
{
    list_t *pos;

    list_foreach(pos, &rreq_records)
    {
        struct rreq_record *rec = (struct rreq_record *) pos;
        if (rec->orig_addr.s_addr == orig_addr.s_addr &&
                (rec->rreq_id == rreq_id))
            return rec;
    }
    return NULL;
}

void NS_CLASS rreq_record_timeout(void *arg)
{
    struct rreq_record *rec = (struct rreq_record *) arg;

    list_detach(&rec->l);
    free(rec);
}


struct blacklist *NS_CLASS rreq_blacklist_insert(struct in_addr dest_addr)
{

    struct blacklist *bl;

    /* First check if this rreq packet is already buffered */
    bl = rreq_blacklist_find(dest_addr);

    /* If already buffered, should we update the timer??? */
    if (bl)
        return bl;

    if ((bl = (struct blacklist *) malloc(sizeof(struct blacklist))) == NULL)
    {
        fprintf(stderr, "Malloc failed!!!\n");
        exit(-1);
    }
    bl->dest_addr.s_addr = dest_addr.s_addr;

    timer_init(&bl->bl_timer, &NS_CLASS rreq_blacklist_timeout, bl);

    list_add(&rreq_blacklist, &bl->l);

    timer_set_timeout(&bl->bl_timer, BLACKLIST_TIMEOUT);
    return bl;
}


struct blacklist *NS_CLASS rreq_blacklist_find(struct in_addr dest_addr)
{
    list_t *pos;

    list_foreach(pos, &rreq_blacklist)
    {
        struct blacklist *bl = (struct blacklist *) pos;

        if (bl->dest_addr.s_addr == dest_addr.s_addr)
            return bl;
    }
    return NULL;
}

void NS_CLASS rreq_blacklist_timeout(void *arg)
{

    struct blacklist *bl = (struct blacklist *) arg;

    list_detach(&bl->l);
    free(bl);
}
#else
NS_STATIC struct rreq_record *NS_CLASS rreq_record_insert(struct in_addr orig_addr,
        u_int32_t rreq_id)
{
    struct rreq_record *rec;

    /* First check if this rreq packet is already buffered */
    rec = rreq_record_find(orig_addr, rreq_id);

    /* If already buffered, should we update the timer???  */
    if (rec)
        return rec;

    if ((rec =
                (struct rreq_record *) malloc(sizeof(struct rreq_record))) == NULL)
    {
        fprintf(stderr, "Malloc failed!!!\n");
        exit(-1);
    }
    rec->orig_addr = orig_addr;
    rec->rreq_id = rreq_id;

    timer_init(&rec->rec_timer, &NS_CLASS rreq_record_timeout, rec);
    rreq_records.push_back(rec);


    DEBUG(LOG_INFO, 0, "Buffering RREQ %s rreq_id=%lu time=%u",
          ip_to_str(orig_addr), rreq_id, PATH_DISCOVERY_TIME);

    timer_set_timeout(&rec->rec_timer, PATH_DISCOVERY_TIME);
    return rec;
}

NS_STATIC struct rreq_record *NS_CLASS rreq_record_find(struct in_addr orig_addr,
        u_int32_t rreq_id)
{
    for (unsigned int i = 0 ; i < rreq_records.size();i++)
    {
        struct rreq_record *rec = rreq_records[i];
        if (rec->orig_addr.s_addr == orig_addr.s_addr &&
                (rec->rreq_id == rreq_id))
            return rec;
    }
    return NULL;
}

void NS_CLASS rreq_record_timeout(void *arg)
{
    struct rreq_record *rec = (struct rreq_record *) arg;
    for (RreqRecords::iterator it = rreq_records.begin();it!=rreq_records.end();it++)
    {
        struct rreq_record *recAux = *it;
        if (rec  == recAux)
        {
            rreq_records.erase(it);
            break;
        }
    }
    free(rec);
}


struct blacklist *NS_CLASS rreq_blacklist_insert(struct in_addr dest_addr)
{

    struct blacklist *bl;

    /* First check if this rreq packet is already buffered */
    bl = rreq_blacklist_find(dest_addr);

    /* If already buffered, should we update the timer??? */
    if (bl)
        return bl;

    if ((bl = (struct blacklist *) malloc(sizeof(struct blacklist))) == NULL)
    {
        fprintf(stderr, "Malloc failed!!!\n");
        exit(-1);
    }
    bl->dest_addr.s_addr = dest_addr.s_addr;

    timer_init(&bl->bl_timer, &NS_CLASS rreq_blacklist_timeout, bl);
    rreq_blacklist.insert(std::make_pair(dest_addr.s_addr,bl));

    timer_set_timeout(&bl->bl_timer, BLACKLIST_TIMEOUT);
    return bl;
}


struct blacklist *NS_CLASS rreq_blacklist_find(struct in_addr dest_addr)
{
    RreqBlacklist::iterator it = rreq_blacklist.find(dest_addr.s_addr);
    if (it != rreq_blacklist.end())
        return it->second;
    return NULL;
}

void NS_CLASS rreq_blacklist_timeout(void *arg)
{
    struct blacklist *bl = (struct blacklist *)arg;
    for (RreqBlacklist::iterator it = rreq_blacklist.begin();it!=rreq_blacklist.end();it++)
    {
        struct blacklist *blAux = it->second;
        if (bl == blAux)
        {
            rreq_blacklist.erase(it);

        }
    }
    free(bl);
}
#endif

