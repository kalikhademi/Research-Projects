/*****************************************************************************
 *
 * Copyright (C) 2001 Uppsala University & Ericsson AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Erik Nordstr�m, <erik.nordstrom@it.uu.se>
 *
 *
 *****************************************************************************/
#ifndef _NEIGHBOR_TABLE_H
#define _NEIGHBOR_TABLE_H

#ifndef NS_NO_GLOBALS
#include "defs_aodv.h"
#include "list.h"

typedef struct nei_table nei_table_t;

#ifdef AODV_USE_STL_NEI

struct nei_table
{
    struct in_addr nei_addr;   /*address of neighbor*/
    double Dtrust;   /*direct trust of the neighbor*/
    double Itrust;   /*indirect trust of the neighbor*/
    double Ttrust;  /* total trust of the neighbor until time t-1, [0,1] -> used as historical trust*/
    bool trusted;
    double q_value; /* Value of the neighbor selection as the next action*/
    double futureValue;  /*expected future reward of the neighbor Q(s(t+1),a(t+1))*/
    int forwardTo;   /* number of forwarded packets to the neighbor in every period. reset after the period used for trust computation*/
    int forwarded;    /* number of packets forwarded by the neighbor in every period. reset after the period used for trust computation*/
    bool blacklist; /*true if the energy of the neighbor is lower than the threshold*/
    simtime_t delay;  //mean delay until the last time, between the node and neighbor
    double deliveryRatio; //delivery ratio between the node and neighbor
    double energy;   //remaining energy of the neighbor,
    bool nei_now;
    simtime_t lastUpdate;
    int hello_rcvd;
    int hello_send;
    double etx;
    double beforFwd;

};
#else

/* neighbor table entries */
struct nei_table
{
    struct in_addr nei_addr;   /*address of neighbor*/
    double Dtrust;   /*direct trust of the neighbor*/
    double Itrust;   /*indirect trust of the neighbor*/
    double Ttrust;  /* total trust of the neighbor until time t-1, [0,1] -> used as historical trust*/
    bool trusted;
    double q_value; /* Value of the neighbor selection as the next action*/
    double futureValue;  /*expected future reward of the neighbor Q(s(t+1),a(t+1))*/
    int forwardTo;   /* number of forwarded packets to the neighbor in every period. reset after the period used for trust computation*/
    int forwarded;    /* number of packets forwarded by the neighbor in every period. reset after the period used for trust computation*/
    bool blacklist; /*true if the energy of the neighbor is lower than the threshold*/
    simtime_t delay;  //mean delay until the last time, between the node and neighbor
    double deliveryRatio; //delivery ratio between the node and neighbor
    //double energy = -1;  //remaining energy of the neighbor
    double etx;
    double beforFwd;
};
#endif

#define NEI_TABLESIZE 64     /* Must be a power of 2 */
#define NEI_TABLEMASK (NEI_TABLESIZE - 1)

//void precursor_list_destroy(rt_table_t * rt);
#endif              /* NS_NO_GLOBALS */

nei_table_t *nei_table_find(struct in_addr dest);
nei_table_t *nei_table_insert(struct in_addr nei_Addr, double dt, double it, double tt, bool ist, double q_val, int rcv,int fwd, bool bl, bool now, double energy, double futurVal, simtime_t delay);
void nei_table_update(struct in_addr nei_addr, simtime_t delay, bool is_nei, bool lowEnergy, double energy);
void inc_forwardTo_packet(struct in_addr nei_addr);
void inc_forwarded_packet(struct in_addr nei_addr);
void q_value_update(struct in_addr nei_addr, RREQ *rreq);
void q_value_update(RREP * hello);
void trust_value_update();
double Ctrust_compute(double dt, double it);   //current trust computation based on direct and indirect trust
double Ttrust_compute(double ct, double ht);   //total trust computation based on current and history trust
double Itrust_compute(struct in_addr nei_addr);
void nei_table_init();
void nei_table_delete(nei_table_t *nei);
void show_neighbors();
void Q_value_check();
//struct qlist *q_list_add();
/*#ifndef NS_NO_DECLARATIONS
neighbor_table() { delay=0; deliveryRatio=0; receiveP=0; forwardP=0; blacklist=false; trusted=true; q_value=0; Dtrust=0; Itrust=0; Ttrust=0.5 }
void rt_table_init();
void rt_table_destroy();
rt_table_t *rt_table_insert(struct in_addr dest, struct in_addr next,
                            u_int8_t hops, u_int32_t seqno, u_int32_t life,
                            u_int8_t state, u_int16_t flags,
                            unsigned int ifindex,
                            uint32_t cost,uint8_t hopfix);
rt_table_t *rt_table_update(rt_table_t * rt, struct in_addr next, u_int8_t hops,
                            u_int32_t seqno, u_int32_t lifetime, u_int8_t state,
                            u_int16_t flags,int iface,
                            uint32_t cost,uint8_t hopfix);

NS_INLINE rt_table_t *rt_table_update_timeout(rt_table_t * rt,
        u_int32_t lifetime);
void rt_table_update_route_timeouts(rt_table_t * fwd_rt, rt_table_t * rev_rt);
rt_table_t *rt_table_find(struct in_addr dest);
rt_table_t *rt_table_find_gateway();
int rt_table_update_inet_rt(rt_table_t * gw, u_int32_t life);
int rt_table_invalidate(rt_table_t * rt);
void rt_table_delete(rt_table_t * rt);
void precursor_add(rt_table_t * rt, struct in_addr addr);
void precursor_remove(rt_table_t * rt, struct in_addr addr);

#ifdef OMNETPP
rt_table_t * modifyAODVTables(struct in_addr,
                              struct in_addr next,
                              u_int8_t hops, u_int32_t seqno,
                              u_int32_t life, u_int8_t state,
                              u_int16_t flags, unsigned int ifindex);
#endif


#endif               NS_NO_DECLARATIONS*/

//neighbor_table() { delay=0; deliveryRatio=0; receiveP=0; forwardP=0; blacklist=false; trusted=true; q_value=0; Dtrust=0; Itrust=0; Ttrust=0.5 };

#endif              /* NEIGHBOR_TABLE_H */
