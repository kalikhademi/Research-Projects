/*****************************************************************************
 *
 * Copyright (C) 2001 Uppsala University and Ericsson AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Erik Nordstr�m, <erik.nordstrom@it.uu.se>
 *
 *****************************************************************************/
#define NS_PORT
#define OMNETPP

#include <time.h>
#include <fstream>
#include <iostream>
#include "IPv4.h"

#ifdef NS_PORT
#ifndef OMNETPP
#include "ns/aodv-uu.h"
#else
#include "../aodv_uu_omnet.h"
#endif
#else
#include "routing_table.h"
#include "neighbor_table.h"
#include "aodv_timeout.h"
#include "aodv_rerr.h"
#include "aodv_hello.h"
#include "aodv_socket.h"
#include "aodv_neighbor.h"
#include "timer_queue_aodv.h"
#include "defs_aodv.h"
#include "debug_aodv.h"
#include "params.h"
#include "seek_list.h"
#include "nl.h"
extern int llfeedback;
#endif              /* NS_PORT */

void NS_CLASS nei_table_init()
{
    while (!aodvNeiTableMap.empty())
    {
        nei_table_delete (aodvNeiTableMap.begin()->second);
        aodvNeiTableMap.erase(aodvNeiTableMap.begin());
    }
}

void NS_CLASS nei_table_delete(nei_table_t * nei)
{
    if (!nei)
    {
        DEBUG(LOG_ERR, 0, "No neighbor entry to delete");
        return;
    }

    ManetAddress dest = nei->nei_addr.s_addr;
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(dest);
    if (it != aodvNeiTableMap.end())
    {
        if (it->second != nei)
            opp_error("AODV neighbor table error");
    }
    aodvNeiTableMap.erase(it);
    free(nei);
    return;
}

nei_table_t *NS_CLASS nei_table_find(struct in_addr dest_addr)
{

    if (aodvNeiTableMap.empty())
        return NULL;

    // Check if we already have an entry for dest_addr
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(dest_addr.s_addr);

    if (it != aodvNeiTableMap.end())
        return it->second;
    return NULL;
}

nei_table_t *NS_CLASS nei_table_insert(struct in_addr neigh_addr,double Dt,double It , double Tt ,bool isTr, double q_val,
        int fwdto,int fwded, bool bl, bool now, double energy, double fVal, simtime_t delay)
{
    nei_table_t *nei;
    ManetAddress neighbor;
    neighbor=neigh_addr.S_addr;
    if ((nei = (nei_table_t *) malloc(sizeof(nei_table_t))) == NULL)
    {
        fprintf(stderr, "Malloc failed!\n");
        exit(-1);
    }
    memset(nei, 0, sizeof(nei_table_t));
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(neighbor);
    if (it != aodvNeiTableMap.end())
        return it->second;
    nei->Ttrust=Tt;
    nei->Itrust=It;
    nei->trusted=isTr;
    nei->Dtrust=Dt;
    nei->q_value=q_val;
    nei->forwardTo=fwdto;
    nei->forwarded=fwded;
    nei->blacklist=bl;
    nei->nei_now = now;
    nei->energy = energy;
    nei->lastUpdate = 0;
    nei->futureValue = fVal;
    nei->delay = delay;    //not used in the algorithm
    nei->hello_send = 0;
    nei->hello_rcvd = 0;
    nei->etx = 5;
    nei->beforFwd = 0;
    aodvNeiTableMap.insert(std::make_pair(neighbor,nei));

    AodvNeiTableMap::iterator it2 = aodvNeiTableMap.find(neighbor);
    //EV<<"add new neighbor to neighbor_table: "<<"\t"<<it2->second->Ttrust<<"\t"<<it2->second->blacklist<<endl;

   /*  write neighbor table map in the txt file
    std::fstream neiFile;
    neiFile.open("neiTableMap.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    if(neiFile.is_open())
    {
        neiFile<<neighbor<<" : "<< nei->Ttrust<<"\t"<<endl;
        neiFile.close();
    }
    else
        EV<<"error opening neiTableMap file"<<endl;*/

    return nei;
}

void NS_CLASS Q_value_check()
{
    std::fstream pFile;
    pFile.open("QCheck.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    pFile<<"Q-value check:"<<endl;

    if(!aodvQValueMap.empty())
    {
        AodvQValueMap::iterator it = aodvQValueMap.begin();
        pFile<<"size of q table:"<<aodvQValueMap.size()<<endl;
        do
        {
            pFile<<it->first<<"  "<<it->second->ad<<"   "<<it->second->time<<" at: "<<simTime()<<endl;
            if( (simTime() - it->second->time).dbl() >= (tUpdateTime-1) )
            {
                AodvNeiTableMap::iterator it2 = aodvNeiTableMap.find(it->second->ad);
                if(it2!=aodvNeiTableMap.end())
                {
                    pFile<<"1q value of: "<<it2->first<<" is: "<<it2->second->q_value<<" at: "<<simTime()<<endl;
                    it2->second->q_value = 0.5 * it2->second->q_value;
                    aodvQValueMap.erase(it);
                   // AodvQValueMap::iterator it3 = aodvQValueMap.find(it2->first);
                    pFile<<"2q value of: "<<it2->first<<" is: "<<it2->second->q_value<<endl;
                }
            }
            pFile<<"***"<<endl;
            it++;
        }while(it!=aodvQValueMap.end());
    }
    pFile<<"\nafter deleting:\n";
    for (AodvQValueMap::iterator it2 = aodvQValueMap.begin(); it2 != aodvQValueMap.end(); it2++)
    {
        pFile<<it2->first<<"  "<<it2->second->ad<<"   "<<it2->second->time<<" at: "<<simTime()<<endl;
    }
    pFile<<"\n\n";
    pFile.close();
}

void NS_CLASS show_neighbors()
{
    //std::fstream showFile;
    //showFile.open("ttlvalue3.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    for (AodvNeiTableMap::iterator it3 = aodvNeiTableMap.begin(); it3 != aodvNeiTableMap.end(); it3++)
   {
       //EV<<"neighbors information: "<< it3->first <<" :"<<it3->second->Ttrust<<"\t"<<it3->second->blacklist<<endl;
      // showFile<<it3->first<<":"<<it3->second->Ttrust<<"\t"<<it3->second->blacklist<<endl;
      // showFile<<endl;
   }
    //showFile.close();
    return;
}

void NS_CLASS inc_forwardTo_packet(struct in_addr nei_addr)
{
   /* if (aodvNeiTableMap.empty())
           nei_table_t *nei = nei_table_insert(nei_addr, 0, 0, -1, true, 0, 0, 0, false, true, -1,);
*/
   // Check if we already have an entry for nei_addr
   AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
   if (it != aodvNeiTableMap.end())
       it->second->forwardTo ++;
   return;
}

void NS_CLASS inc_forwarded_packet(struct in_addr nei_addr)
{
    /*if (aodvNeiTableMap.empty())
           nei_table_t *nei = nei_table_insert(nei_addr, 0, 0, -1, true, 0, 0, 0, false, true, -1);*/

   // Check if we already have an entry for nei_addr
   AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
   if (it != aodvNeiTableMap.end())
       it->second->forwarded++;
   return;
}

void NS_CLASS q_value_update(RREP * hello)
{

    double etx=0, delay=0;
    //std::fstream qFile;
    //qFile.open("QValue.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    /*for (AodvNeiTableMap::iterator it3 = aodvNeiTableMap.begin(); it3 != aodvNeiTableMap.end(); it3++)
    {
        qFile<<it3->first<<": qValue: "<<it3->second->q_value<<" futureReward: "<<it3->second->futureValue<<endl;
    }*/
    double reward=0;
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(hello->sender);
    if(it!=aodvNeiTableMap.end())
    {
        it->second->futureValue = hello->expFuturVal;
        etx = it->second->etx;
        delay = (simTime() - hello->src_time).dbl();
        reward = (double)((-1)*log(delay)-log(etx));
        //reward = 1.0 / (delay * etx);
        //qFile<<"ETX: "<<etx<<endl;
        //qFile<<"delay: "<<delay<<endl;
        //qFile<<"reward: "<<reward<<endl;
        //qFile<<"expfutval: "<< it->second->futureValue<<endl;
        //qFile<<"previous q value: "<<it->second->q_value<<endl;
        it->second->q_value = (1 - alfa) * it->second->q_value + alfa * (reward + gama * it->second->futureValue);
        //qFile<<"updated q value: "<<it->second->q_value<<" at "<<simTime()<<endl;
        //qFile.close();
        return;
    }
}

/*void NS_CLASS q_value_update(struct in_addr nei_addr, RREQ * rreq)
{

    double etx=0, delay=0, pDelay=0, distance=0;
    Coord myPos = MobilityAccess().get()->getCurrentPosition();
    std::fstream qFile;
    qFile.open("QValue.txt", std::fstream::in | std::fstream::out | std::fstream::app);

    for (AodvNeiTableMap::iterator it3 = aodvNeiTableMap.begin(); it3 != aodvNeiTableMap.end(); it3++)
    {
        qFile<<it3->first<<": qValue:"<<it3->second->q_value<<" futureReward: "<<it3->second->futureValue<<endl;
    }
    qFile<<"delay reward: "<<rreq->delayReward<<endl;
    double reward=0;
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
    if(it!=aodvNeiTableMap.end())
    {
        it->second->futureValue = rreq->futurQValue;
        etx = it->second->etx;
        distance = sqrt(pow(rreq->sender_x - myPos.x,2)+pow(rreq->sender_y - myPos.y,2));
        pDelay = (double) (distance)/300000000;
        //etx = 1.0 / ((double)(rreq->helloRcvd_no)/it->second->hello_send);  //[1,infinity]
        delay = pDelay + rreq->delayReward.dbl();
        qFile<<"delay:"<<rreq->delay<<endl;
        qFile<<"pdelay:"<<pDelay<<endl;
        //[0,infinity]
        //reward = 1.0/exp(delay) + 1.0/exp(etx-1);  //reward is a function of delivery ratio(ETX) and delay
        reward = (double)((-1)*log(delay)-log(etx)); ///1470.6;
        //reward = 1.0 / (etx * delay);
        qFile<<"ETX: "<<etx<<endl;
        qFile<<"delayreward: "<<rreq->delayReward<<endl;
        qFile<<"delayreward: "<<rreq->delayReward.dbl()<<endl;
        qFile<<"reward: "<<reward<<endl;
        qFile<<"previous q value: "<<it->second->q_value<<endl;
        it->second->q_value = (1 - alfa) * it->second->q_value + alfa * (reward + gama * it->second->futureValue);
        qFile<<"updated q value: "<<it->second->q_value<<" at "<<simTime()<<endl;
        qFile.close();
        return;
    }
      std::fstream qFile;
      qFile.open("qvalue.txt", std::fstream::in | std::fstream::out | std::fstream::app);
      if(qFile.is_open())
      {
          qFile<<"prev: "<<rreq->prev_src<<"  cur:"<<rreq->cur_src<<"\t"<<simTime()<<endl;
          qFile.close();
      }
      else
          EV<<"error opening  qfile"<<endl;

    Expected SARSA update formula
    int count = 0, num = 0;
    double exp_futurRew = 0, maxQ = 0, meanQ = 0, reward=0;
    qlist * cur = new qlist();
    cur = rreq->q_list;
    if(nei_addr.S_addr == rreq->dest_addr)
        exp_futurRew = 0;
    else
    {
        while(cur)
        {
            //EV<<cur->qvalue<<"\t"<<cur->number<<endl;
            if(cur->qvalue >= maxQ)
            {
                //EV<<"q value number "<<cur->number<<" : "<<cur->qvalue<<endl;
                maxQ = cur->qvalue;
                count = cur->number;
            }
            cur = cur->next;
        }
        cur = rreq->q_list;
        while(cur)
        {
            if(cur->number != count)
            {
                meanQ = meanQ + cur->qvalue;
                num++;
            }
            cur = cur->next;
        }
        //EV<<"number of q values:"<<num<<endl;
        meanQ = (double)(meanQ/num);
        exp_futurRew = (1 - epsilon) * maxQ + epsilon * meanQ;     //expected future value
    }
}*/

/*struct qlist *NS_CLASS q_list_add()
{
    int count = 0;
    qlist *cur, *first;
    cur = new qlist();
    first= new qlist();
    for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
    {
        if(it->second->nei_now == true)
        {
            //EV<<"nei now"<<endl;
           if (count == 0)
           {
               qlist *newq = new qlist();
               newq->qvalue = it->second->q_value;
               count ++;
               newq->number = count;
               newq->prev = NULL;
               newq->next = NULL;
               first = newq;
               //EV<<"first nei: "<< first->number<<"\t"<<first->qvalue<<endl;
               continue;
           }
           cur = first;
            while(cur->next)
                cur = cur->next;
            qlist *newq = new qlist();
            newq->qvalue = it->second->q_value;
            count = count + 1;
            newq->number = count;
            newq->next = NULL;
            newq->prev = cur;
            cur->next = newq;
            cur = newq;
            //EV<<"next nei: "<< cur->number<<"\t"<<cur->qvalue<<endl;
        }
    }
    return first;
}*/

void NS_CLASS trust_value_update()
{
   double current_trust = 0;
   struct in_addr nei_addr;
   bool noRelation, foundFlag, found, found2;
   std::fstream trustFile, neiFile;
   trustFile.open("Trust.txt", std::fstream::in | std::fstream::out | std::fstream::app);
   //neiFile.open("neighborTable.txt", std::fstream::in | std::fstream::out | std::fstream::app);

   for(IPMap::iterator it=ipmap.begin(); it!=ipmap.end(); it++)
   {
       trustFile<<"\n"<<it->first<<" :\n";
       for(unsigned int i=0; i<it->second.size(); i++)
           trustFile<<it->second[i]->neiNode<<"  "<<it->second[i]->fwded<<"  "<<it->second[i]->fwdto<<endl;
       trustFile<<"\n\n";
   }
   /*neiFile<<"--- "<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<": \n";
   for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
   {
       neiFile<<it->first<<" : "<<it->second->nei_now<<endl;
   }
   neiFile<<"***********************************************"<<endl;
*/
   IPMap::iterator myIp = ipmap.find(DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr);
   trustFile<<"--- "<<DEV_IFINDEX(NS_IFINDEX).ipaddr.S_addr<<": \n";
   trustFile<<"routing table:"<<endl;
   for(AodvRtTableMap::iterator it=aodvRtTableMap.begin(); it!=aodvRtTableMap.end(); it++)
   {

       struct in_addr newNei;
       newNei.S_addr = it->first;
       nei_table_t *nei = nei_table_find(newNei);
       if(!nei)
           nei_table_insert (newNei, 0, 0 , -1.0 ,true, 0, 0, 0 , false, true, -1, 0, 0);
       trustFile<<"   "<<it->first<<": "<<it->second->trusted<<endl;
   }
   trustFile<<"\n\n";
   trustFile<<"neighbor table:"<<endl;
   for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
   {
       trustFile<<"   "<<it->first<<": "<<it->second->trusted<<endl;
   }
   trustFile<<"\n\n";
   for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
   {
       trustFile<<"neighbor node: "<<it->first<<endl;
       noRelation = false;
       foundFlag = false;
       found = false;
       found2 = false;
       IPMap::iterator neiIp = ipmap.find(it->first);
       for(unsigned int i=0 ; i<myIp->second.size();i++)
       {
           if(ManetAddress(myIp->second[i]->neiNode) == it->first)
           {
               foundFlag = true;
               if(myIp->second[i]->fwdto == 0)
               {
                   trustFile<<"no relation!\n";
                   noRelation = true;
                   break;
               }
               else if(myIp->second[i]->fwdto != 0 && it->second->Ttrust == -1)
               {
                  trustFile<<"first relationship!"<<endl;
                  for(unsigned int j=0 ; j<neiIp->second.size();j++)
                      if(ManetAddress(neiIp->second[j]->neiNode) == myIp->first)
                      {
                          trustFile<<"number of packets forwarded by neigh:"<<neiIp->second[j]->fwded<<endl;
                          trustFile<<"number of packets forwarded to neigh:"<<myIp->second[i]->fwdto<<endl;
                          it->second->Dtrust = (double)(neiIp->second[j]->fwded)/myIp->second[i]->fwdto;  //compute current direct trust
                          trustFile<<"direct trust:"<< it->second->Dtrust<<endl;
                          if(it->second->Dtrust > 1)
                              it->second->Dtrust = 1;
                          if(it->second->Dtrust < trustThrsh)
                              it->second->Dtrust = trustThrsh + ((double)(1-trustThrsh)/2);
                          found2 = true;
                      }
                  if(found2 == false)
                  {
                      it->second->Dtrust = trustThrsh + ((double)(1-trustThrsh)/2);
                      trustFile<<"the node did not forward the packets at all \n";
                      trustFile<<"direct trust"<<it->second->Dtrust<<endl;
                  }
               }
               else if(myIp->second[i]->fwdto != 0 && it->second->Ttrust != -1)
               {
                   trustFile<<"more relationship!"<<endl;
                   for(unsigned int j=0 ; j<neiIp->second.size();j++)
                      if(ManetAddress(neiIp->second[j]->neiNode) == myIp->first)
                      {
                          trustFile<<"number of packets forwarded to neigh:"<<myIp->second[i]->fwdto<<endl;
                          trustFile<<"number of packets forwarded by neigh:"<<neiIp->second[j]->fwded<<endl;
                          it->second->Dtrust = (double)(neiIp->second[j]->fwded)/myIp->second[i]->fwdto;  //compute current direct trust
                          trustFile<<"direct trust:"<< it->second->Dtrust<<endl;
                          if(it->second->Dtrust > 1)
                          {
                            ///////// it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(floor(it->second->Dtrust))/it->second->beforFwd );
                             it->second->Dtrust = 1;
                          }
                          found = true;
                      }
                   if(found == false)
                   {
                       //direct trust ro kam konim
                       it->second->Dtrust = 0;
                       trustFile<<"the node did not forward the packet \n";
                       trustFile<<"direct trust"<<it->second->Dtrust<<endl;
                   }

               }
           }
       }
       if(noRelation == true)
       {
           if (it->second->Ttrust == -1)
           {
               trustFile<<"the node had not still relationship with "<<it->first<<" at "<<simTime()<<endl;
               continue;
           }
           else
           {
               //decrease trust
               continue;
           }
       }
       if(foundFlag == false)
       {
           trustFile<<"the node had not relationship with "<<it->first<<" in this period of time, at "<<simTime()<<endl;
           continue;
       }
/*       IPMap::iterator myIp2 = ipmap.find(it->first);
       for(unsigned int i=0 ; i<myIp2->second.size();i++)
           if(ManetAddress(myIp2->second[i]->neiNode) == it->first)
               it->second->beforFwd = myIp2->second[i]->fwdto;*/

       //compute indirect trust and current trust
       nei_addr.S_addr = it->first;
       it->second->Itrust = Itrust_compute(nei_addr);
       trustFile<<"indirect trust:"<<it->second->Itrust<<endl;
       current_trust = Ctrust_compute(it->second->Dtrust, it->second->Itrust);    //compute current trust based on direct and indirect trust
       trustFile<<"current trust:"<<current_trust<<endl;
       if(it->second->Ttrust == -1)
             it->second->Ttrust = current_trust;
       else
             it->second->Ttrust = Ttrust_compute(current_trust, it->second->Ttrust);    //compute total trust based on current and history trust

       if(it->second->Ttrust > 1)
             it->second->Ttrust = 1;
       trustFile<<"total trust:"<<it->second->Ttrust<<endl;
       /* determine trustworthiness of the node*/
       AodvRtTableMap::iterator it2 = aodvRtTableMap.find(it->first);
       if (it2!=aodvRtTableMap.end() && it->second->Ttrust >= trustThrsh)
       {
           it->second->trusted = true;
           if(it2!=aodvRtTableMap.end())
               it2->second->trusted = true;
       }
       else
       {
           it->second->trusted = false;
           if(it2!=aodvRtTableMap.end())
               it2->second->trusted = false;
       }
       it->second->lastUpdate = simTime();
   }
   return;




//       if(it->second->forwardTo == 0 && it->second->forwarded == 0/*&& it->second->Ttrust == -1*/)    //if the node had not relationship yet, ignore the trust update
//       {
//           trustFile<<"the node had not relationship with "<<it->first<<" yet at "<<simTime()<<endl;
//           continue;
//       }
//       trustFile<<it->first<<":"<<endl;
//       if(it->second->forwardTo == 0 && it->second->forwarded != 0 )
//       {
//           trustFile<<"forwarded is not zero \n totaltrust1:"<<it->second->Ttrust<<endl;
//           it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(it->second->forwarded)/it->second->beforFwd );
//           trustFile<<"totaltrust2:"<<it->second->Ttrust<<endl;
//           continue;
//       }
//       if(it->second->forwardTo !=0 && it->second->Ttrust == -1)
//       {
//           it->second->Dtrust = (double)(it->second->forwarded)/it->second->forwardTo;  //compute current direct trust
//           if(it->second->Dtrust > 1)
//           {
//              // it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(floor(it->second->Dtrust))/it->second->beforFwd );
//               it->second->Dtrust = 1;
//           }
//           if(it->second->Dtrust < trustThrsh)
//               it->second->Dtrust = trustThrsh + ((double)(1-trustThrsh)/2);
//       }
//       else if(it->second->forwardTo !=0 && it->second->Ttrust != -1)
//       {
//           it->second->Dtrust = (double)(it->second->forwarded)/it->second->forwardTo;  //compute current direct trust
//           if(it->second->Dtrust > 1)
//           {
//               it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(floor(it->second->Dtrust))/it->second->beforFwd );
//               it->second->Dtrust = 1;
//           }
//       }
//      // else if (it->second->forwardTo == 0 /*&& it->second->trusted == true*/ && it->second->Ttrust != -1)
//      //         it->second->Dtrust = pow((double)(it->second->lastUpdate.dbl()) / simTime().dbl(),lambda) * it->second->Dtrust;  //trust decay function
//       it->second->beforFwd = it->second->forwardTo;
//       trustFile<<"forwarded:"<<it->second->forwarded<<" forwardTo:"<<it->second->forwardTo<<endl;
//       trustFile<<"direct trust:"<<it->second->Dtrust<<endl;
//      // if (it->second->trusted == true)   //if the neighbor is trusted
//     //  {
//           nei_addr.S_addr = it->first;
//           it->second->Itrust = Itrust_compute(nei_addr);
//           trustFile<<"indirect trust:"<<it->second->Itrust<<endl;
//           current_trust = Ctrust_compute(it->second->Dtrust, it->second->Itrust);    //compute current trust based on direct and indirect trust
//           trustFile<<"current trust:"<<current_trust<<endl;
//           trustFile<<"total trust1:"<<it->second->Ttrust<<endl;
//           if(it->second->Ttrust == -1)
///*            {
//               if(current_trust == 0)
//                   it->second->Ttrust = 0.75;     //optimistic behavior
//               else*/
//                   it->second->Ttrust = current_trust;
//           //}
//           else
//               it->second->Ttrust = Ttrust_compute(current_trust, it->second->Ttrust);    //compute total trust based on current and history trust
//
//           if(it->second->Ttrust > 1)
//               it->second->Ttrust = 1;
//           trustFile<<"total trust2:"<< it->second->Ttrust<<endl;
//           trustFile<<endl;
//           /* determine trustworthiness of the node*/
//           AodvRtTableMap::iterator it2 = aodvRtTableMap.find(it->first);
//           if (it2!=aodvRtTableMap.end() && it->second->Ttrust >= trustThrsh)
//           {
//               it->second->trusted = true;
//               if(it2!=aodvRtTableMap.end())
//                   it2->second->trusted = true;
//           }
//           else
//           {
//               it->second->trusted = false;
//               if(it2!=aodvRtTableMap.end())
//                   it2->second->trusted = false;
//           }
//           /*reset the field of receive and forward*/
//           it->second->forwardTo = 0;
//           it->second->forwarded = 0;
//           it->second->lastUpdate = simTime();
//           trustFile<<"last update time:" << it->second->lastUpdate;
//      // }
//   }
//   trustFile.close();
//   return;






//   double current_trust = 0;
//     struct in_addr nei_addr;
//     std::fstream trustFile;
//     trustFile.open("Trust.txt", std::fstream::in | std::fstream::out | std::fstream::app);
//     for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
//     {
//         if(it->second->forwardTo == 0 && it->second->forwarded == 0/*&& it->second->Ttrust == -1*/)    //if the node had not relationship yet, ignore the trust update
//         {
//             trustFile<<"the node had not relationship with "<<it->first<<" yet at "<<simTime()<<endl;
//             continue;
//         }
//         trustFile<<it->first<<":"<<endl;
//         if(it->second->forwardTo == 0 && it->second->forwarded != 0 )
//         {
//             trustFile<<"forwarded is not zero \n totaltrust1:"<<it->second->Ttrust<<endl;
//             it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(it->second->forwarded)/it->second->beforFwd );
//             trustFile<<"totaltrust2:"<<it->second->Ttrust<<endl;
//             continue;
//         }
//         if(it->second->forwardTo !=0 && it->second->Ttrust == -1)
//         {
//             it->second->Dtrust = (double)(it->second->forwarded)/it->second->forwardTo;  //compute current direct trust
//             if(it->second->Dtrust > 1)
//             {
//                // it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(floor(it->second->Dtrust))/it->second->beforFwd );
//                 it->second->Dtrust = 1;
//             }
//             if(it->second->Dtrust < trustThrsh)
//                 it->second->Dtrust = trustThrsh + ((double)(1-trustThrsh)/2);
//         }
//         else if(it->second->forwardTo !=0 && it->second->Ttrust != -1)
//         {
//             it->second->Dtrust = (double)(it->second->forwarded)/it->second->forwardTo;  //compute current direct trust
//             if(it->second->Dtrust > 1)
//             {
//                 it->second->Ttrust = it->second->Ttrust + dTrustFactor*curTrustFactor*( (double)(floor(it->second->Dtrust))/it->second->beforFwd );
//                 it->second->Dtrust = 1;
//             }
//         }
//        // else if (it->second->forwardTo == 0 /*&& it->second->trusted == true*/ && it->second->Ttrust != -1)
//        //         it->second->Dtrust = pow((double)(it->second->lastUpdate.dbl()) / simTime().dbl(),lambda) * it->second->Dtrust;  //trust decay function
//         it->second->beforFwd = it->second->forwardTo;
//         trustFile<<"forwarded:"<<it->second->forwarded<<" forwardTo:"<<it->second->forwardTo<<endl;
//         trustFile<<"direct trust:"<<it->second->Dtrust<<endl;
//        // if (it->second->trusted == true)   //if the neighbor is trusted
//       //  {
//             nei_addr.S_addr = it->first;
//             it->second->Itrust = Itrust_compute(nei_addr);
//             trustFile<<"indirect trust:"<<it->second->Itrust<<endl;
//             current_trust = Ctrust_compute(it->second->Dtrust, it->second->Itrust);    //compute current trust based on direct and indirect trust
//             trustFile<<"current trust:"<<current_trust<<endl;
//             trustFile<<"total trust1:"<<it->second->Ttrust<<endl;
//             if(it->second->Ttrust == -1)
//  /*            {
//                 if(current_trust == 0)
//                     it->second->Ttrust = 0.75;     //optimistic behavior
//                 else*/
//                     it->second->Ttrust = current_trust;
//             //}
//             else
//                 it->second->Ttrust = Ttrust_compute(current_trust, it->second->Ttrust);    //compute total trust based on current and history trust
//
//             if(it->second->Ttrust > 1)
//                 it->second->Ttrust = 1;
//             trustFile<<"total trust2:"<< it->second->Ttrust<<endl;
//             trustFile<<endl;
//             /* determine trustworthiness of the node*/
//             AodvRtTableMap::iterator it2 = aodvRtTableMap.find(it->first);
//             if (it2!=aodvRtTableMap.end() && it->second->Ttrust >= trustThrsh)
//             {
//                 it->second->trusted = true;
//                 if(it2!=aodvRtTableMap.end())
//                     it2->second->trusted = true;
//             }
//             else
//             {
//                 it->second->trusted = false;
//                 if(it2!=aodvRtTableMap.end())
//                     it2->second->trusted = false;
//             }
//             /*reset the field of receive and forward*/
//             it->second->forwardTo = 0;
//             it->second->forwarded = 0;
//             it->second->lastUpdate = simTime();
//             trustFile<<"last update time:" << it->second->lastUpdate;
//        // }
//        /* if(it->second->trusted == false)                            //if the neighbor is untrusted
//         {
//             trustFile<<" the neighbor is untrusted"<<endl;
//             it->second->Itrust = Itrust_compute(nei_addr);
//             current_trust = Ctrust_compute(it->second->Dtrust, it->second->Itrust);
//             it->second->Ttrust = Ttrust_compute(current_trust, it->second->Ttrust);    //compute total trust based on current and history trust
//              determine trustworthiness of the node
//             AodvRtTableMap::iterator it2 = aodvRtTableMap.find(it->first);
//             if (it->second->Ttrust >= trustThrsh)
//             {
//                 it->second->trusted = true;
//                 if(it2!=aodvRtTableMap.end())
//                     it2->second->trusted = true;
//             }
//             else
//             {
//                 it->second->trusted = false;
//                 if(it2!=aodvRtTableMap.end())
//                     it2->second->trusted = false;
//             }
//             //reset the field of receive and forward
//             trustFile<<"direct trust trust: "<<it->second->Dtrust<<endl;
//             trustFile<<"indirect trust: "<<it->second->Itrust<<endl;
//             trustFile<<"total trust: "<<it->second->Ttrust<<"\n\n";
//             it->second->forwardTo = 0;
//             it->second->forwarded = 0;
//             it->second->lastUpdate = simTime();
//         }*/
//     }
//     trustFile.close();
//     return;
}

double NS_CLASS Ctrust_compute(double Dt, double Int)  //if the difference of Dt and Rt is high, be nazare recommender shak konim
{
    double trust = 0;
/*    if(Int == 0)   //recommenders have no idea
        trust = Dt;
    else*/
    if(Int == -1)
        trust = Dt;
    else
        trust = (double)(dTrustFactor)* Dt + ((1 - dTrustFactor)* Int);
    return trust;
}

double NS_CLASS Ttrust_compute(double Ctt, double Htt)   // idea:trust kamkam be dast miad va be sor'at az bein mire
{
    double trust = 0;
/*    if(Ctt < 0.5*Htt)
        trust = (double)((curTrustFactor * Ctt) + ((1 - curTrustFactor)* Htt));
    else if (Htt < 0.5*Ctt)
        trust = (double)(((1 - curTrustFactor) * Ctt) + (curTrustFactor* Htt));
    else
    {*/
       // double curTrustFactor2 = 0.5;
        trust = (double)((curTrustFactor * Ctt) + ((1 - curTrustFactor)* Htt));
    //}
    return trust;
}

double NS_CLASS Itrust_compute(struct in_addr nei_addr)
{
    ManetAddress nei = nei_addr.S_addr;
    double Itrust=0, obj_trust=0, counter=0, recom_trust=0;
    std::fstream trustFile;
    trustFile.open("ITrust.txt", std::fstream::in | std::fstream::out | std::fstream::app);
    //trustFile<<"indirect trust:"<<endl;

    /*for(AodvRecomTableMap::iterator it2=aodvRecomTableMap.begin(); it2!=aodvRecomTableMap.end(); it2++)
    {
        trustFile<<"vector of:"<<it2->first<<endl;
        for(unsigned i=0; i<it2->second.size(); i++)
        {
            trustFile<<it2->second[i]->objNode<<" trust: "<<it2->second[i]->trust<<endl;
        }
        trustFile<<"\n\n";

    }*/
    for(AodvRtTableMap::iterator it=aodvRtTableMap.begin(); it!=aodvRtTableMap.end(); it++)  //search for recommenders. if use neighbor table, consider all recommenders, id use routing table, consider current neighbors
    {
        if( it->first == it->second->next_hop.S_addr )
        {
            AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it->first);
            if(checkNei!=aodvNeiTableMap.end() /*&& checkNei->second->trusted == true*/ && it->first != nei)
            {
                /*if(checkNei->second->Ttrust >= recomThrsh)   //if the recommender's trust is above the threshold
                {
                    //recom_trust = checkNei->second->Dtrust;   //agar Ttrust begozarim bayad be -1 trust dar ebtedaye ejra tavjoh konim
                    recom_trust = checkNei->second->Ttrust;
                }
                else
                    continue;*/
                for(AodvRecomTableMap::iterator it2=aodvRecomTableMap.begin(); it2!=aodvRecomTableMap.end(); it2++)
                {
                    if( it2->first == it->first )
                    {
                        for(unsigned i=0; i<it2->second.size(); i++)
                        {
                            if( it2->second[i]->objNode == nei && it2->second[i]->trust!=-1) //recommender is the current neighbor of j
                            {
                                trustFile<<"trust of "<< it->first <<" about "<<nei<<endl;
                                //obj_trust = recom_trust * it2->second[i]->trust;
                                obj_trust =  it2->second[i]->trust;
                                trustFile<<"recom trust"<<recom_trust<<"  obj trust" << obj_trust<<endl;
                                Itrust = Itrust + obj_trust;
                             //   trustFile<<"Itrust: "<<Itrust<<endl;
                                counter++;
                                obj_trust=0;
                            }
                            /*else if( it2->second[i]->objNode == nei && it2->second[i]->is_nei == false && it2->second[i]->trust!=-1 )
                            {
                                EV<<"recom "<< counter<<":"<<endl;
                                obj_trust = (it2->second[i]->lastTime/simTime()) * recom_trust * it2->second[i]->trust;  //tasire  etemade recom ra kahesh dahim
                                EV<<"recom trust" << recom_trust <<"*"<< it2->second[i]->trust<<endl;
                                Itrust = Itrust + obj_trust;
                                EV<<"Itrust: "<<Itrust<<endl;
                                counter++;
                                obj_trust=0;
                            }*/
                        }
                    }
                }
            }
        }
    }
    trustFile.close();
    if(counter == 0)
        return -1;
        //return Itrust;
    Itrust = (double)(Itrust)/counter;
    return Itrust;
}

void NS_CLASS nei_table_update(struct in_addr nei_addr, simtime_t delay,bool is_nei, bool lowEnergy, double energy)
{
    AodvNeiTableMap::iterator it = aodvNeiTableMap.find(nei_addr.s_addr);
    it->second->nei_now = is_nei;
    it->second->delay = delay;
   // it->second->futureValue = fVal;
    it->second->blacklist = lowEnergy;
    it->second->energy = energy;   //if -1 the node is not in low energy, else in low energy
    return;
}
