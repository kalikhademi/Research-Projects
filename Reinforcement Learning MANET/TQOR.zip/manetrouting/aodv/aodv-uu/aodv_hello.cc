/*****************************************************************************
 *
 * Copyright (C) 2001 Uppsala University and Ericsson AB.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Erik Nordstr�m, <erik.nordstrom@it.uu.se>
 *
 *
 *****************************************************************************/
#define NS_PORT
#define OMNETPP

#ifdef NS_PORT
#ifndef OMNETPP
#include "ns/aodv-uu.h"
#else
#include "../aodv_uu_omnet.h"
#endif
#else
#include <netinet/in.h>
#include "aodv_hello.h"
#include "aodv_timeout.h"
#include "aodv_rrep.h"
#include "aodv_rreq.h"
#include "routing_table.h"
#include "timer_queue_aodv.h"
#include "params.h"
#include "aodv_socket.h"
#include "defs_aodv.h"
#include "debug_aodv.h"
#define DEBUG_HELLO
extern int unidir_hack, receive_n_hellos, hello_jittering, optimized_hellos;
static struct timer hello_timer;

#endif

/* #define DEBUG_HELLO */


long NS_CLASS hello_jitter()
{
    if (hello_jittering)
    {
#ifdef NS_PORT
#ifndef OMNETPP
        return (long) (((float) Random::integer(RAND_MAX + 1) / RAND_MAX - 0.5)
                       * JITTER_INTERVAL);
#else
        return (long) (((float) intuniform(0, RAND_MAX) / RAND_MAX - 0.5)
                       * JITTER_INTERVAL);
#endif
#else
        return (long) (((float) random() / RAND_MAX - 0.5) * JITTER_INTERVAL);
#endif
    }
    else
        return 0;
}

void NS_CLASS hello_start()
{
    if (hello_timer.used)
    {
        return;
    }

    gettimeofday(&this_host.fwd_time, NULL);

    DEBUG(LOG_DEBUG, 0, "Starting to send HELLOs!");
    timer_init(&hello_timer, &NS_CLASS hello_send, NULL);

    hello_send(NULL);
}

void NS_CLASS hello_stop()
{
    DEBUG(LOG_DEBUG, 0,
          "No active forwarding routes - stopped sending HELLOs!");
#ifdef OMNETPP
    EV << "No active forwarding routes - stopped sending HELLOs!";
#endif
    timer_remove(&hello_timer);
}

void NS_CLASS hello_send(void *arg)
{
    RREP *rrep;
    AODV_ext *ext = NULL;
    u_int8_t flags = 0;
    struct in_addr dest;
    long time_diff, jitter;
    struct timeval now;
    int msg_size = RREP_SIZE;
    int i, counter=0;
    char buffer[300];
    char *buffer_ptr;
    double maxQval=0, sumQ=0, meanQ=0;
    ManetAddress index;
    BasicBattery *bt = BatteryAccess().get();
    epsilon = 0.5;

    buffer_ptr = buffer;

    gettimeofday(&now, NULL);

    if (optimized_hellos &&
            timeval_diff(&now, &this_host.fwd_time) > ACTIVE_ROUTE_TIMEOUT)
    {
        hello_stop();
        return;
    }

#ifdef OMNETPP
    double delay = -1;
    if (par("EqualDelay"))
        delay = par("broadcastDelay");
#endif

    time_diff = timeval_diff(&now, &this_host.bcast_time);  //faseleye zamani beine alan va akharin msgi ke bcast shode
    jitter = hello_jitter();

    /* This check will ensure we don't send unnecessary hello msgs, in case
       we have sent other bcast msgs within HELLO_INTERVAL */
    if (time_diff >= HELLO_INTERVAL)
    {

        for (i = 0; i < MAX_NR_INTERFACES; i++)
        {
            if (!DEV_NR(i).enabled)
                continue;
#ifdef DEBUG_HELLO
            DEBUG(LOG_DEBUG, 0, "sending Hello to 255.255.255.255");
#endif
#ifdef OMNETPP
            EV << "sending Hello to 255.255.255.255"<<endl;
#endif
            rrep = rrep_create(flags, 0, 0, DEV_NR(i).ipaddr,
                               this_host.seqno,
                               DEV_NR(i).ipaddr,
                               ALLOWED_HELLO_LOSS * HELLO_INTERVAL);

            //calculate future Q value used in updating q value of selection this node as next hop
            for (AodvRtTableMap::iterator it4 = aodvRtTableMap.begin(); it4 != aodvRtTableMap.end(); it4++)
            {
                if( it4->second->next_hop.S_addr == it4->first )
                {
                    AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it4->first);
                    if( checkNei!=aodvNeiTableMap.end() &&  it4->second->trusted == true )
                        if(checkNei->second->q_value >= maxQval)
                        {
                            maxQval = checkNei->second->q_value;
                            index = it4->first;
                        }
                }
            }
            for (AodvRtTableMap::iterator it5 = aodvRtTableMap.begin(); it5 != aodvRtTableMap.end(); it5++)
            {
                if( it5->first == it5->second->next_hop.S_addr )
                {
                    AodvNeiTableMap::iterator checkNei = aodvNeiTableMap.find(it5->first);
                    if( checkNei!=aodvNeiTableMap.end() && it5->second->trusted == true)
                    if(it5->first != index)
                    {
                        sumQ = sumQ + checkNei->second->q_value;
                        counter++;
                    }
                }
            }
            if(counter != 0)
                meanQ = (double)(sumQ) / counter;
            else
                meanQ = 0;
            rrep->expFuturVal= (1 - epsilon) * maxQval + epsilon * meanQ;   //sarsa model
           // rrep->expFuturVal= maxQval;   //q-learning model

            /* Assemble a RREP extension which contain our neighbor set... */
            if (unidir_hack)
            {
                int i;
#ifndef OMNETPP
                if (ext)
                    ext = AODV_EXT_NEXT(ext);
                else
                    /* Check for hello interval extension: */
                    ext = (AODV_ext *) ((char *) rrep + RREP_SIZE);
                ext->type = RREP_HELLO_NEIGHBOR_SET_EXT;
                ext->length = 0;
#endif

#ifdef AODV_USE_STL_RT
                for (i = 0; i < RT_TABLESIZE; i++)
                {
                    for (AodvRtTableMap::iterator it = aodvRtTableMap.begin(); it != aodvRtTableMap.end(); it++)
                    {
                        rt_table_t *rt = it->second;
                        /* If an entry has an active hello timer, we assume
                           that we are receiving hello messages from that
                           node... */
                        if (rt->hello_timer.used)
                        {
#ifdef DEBUG_HELLO
                            DEBUG(LOG_INFO, 0,
                                  "Adding %s to hello neighbor set ext",
                                  ip_to_str(rt->dest_addr));
#endif
                            memcpy(buffer_ptr, &rt->dest_addr,
                                   sizeof(struct in_addr));
                            buffer_ptr+=sizeof(struct in_addr);
                        }
                    }
                }
#else
                for (i = 0; i < RT_TABLESIZE; i++)
                {
                    list_t *pos;
                    list_foreach(pos, &rt_tbl.tbl[i])
                    {
                        rt_table_t *rt = (rt_table_t *) pos;
                        /* If an entry has an active hello timer, we assume
                           that we are receiving hello messages from that
                           node... */
                        if (rt->hello_timer.used)
                        {
#ifdef DEBUG_HELLO
                            DEBUG(LOG_INFO, 0,
                                  "Adding %s to hello neighbor set ext",
                                  ip_to_str(rt->dest_addr));
#endif
#ifndef OMNETPP
                            memcpy(AODV_EXT_NEXT(ext), &rt->dest_addr,
                                   sizeof(struct in_addr));
                            ext->length += sizeof(struct in_addr);
#else
                            memcpy(buffer_ptr, &rt->dest_addr,
                                   sizeof(struct in_addr));
                            buffer_ptr+=sizeof(struct in_addr);
#endif

                        }
                    }
                }

#endif
#ifdef OMNETPP
                if (ext->length)
                {
                    msg_size = RREP_SIZE + AODV_EXT_SIZE(ext);

                }
                rrep->setName("AodvHello");
                rrep->setByteLength(msg_size);
#else
                if (buffer_ptr-buffer>0)
                {
                    rrep->addExtension(RREP_HELLO_NEIGHBOR_SET_EXT,(int)(buffer_ptr-buffer),buffer);
                    msg_size = RREP_SIZE + (int)(buffer_ptr-buffer);
                }

#endif
            }
            dest.s_addr = ManetAddress(IPv4Address(AODV_BROADCAST));
#ifdef OMNETPP
            rrep->ttl=1;
           // if ( bt->GetEnergy() < energyThrsh )
           // {
           //     rrep->lowEnergy =true;
                rrep->energy = bt->GetEnergy();
                rrep->src_time = simTime();
           // }
            aodv_socket_send((AODV_msg *) rrep, dest, msg_size, 1, &DEV_NR(i),delay);
            EV<<"hello send "<<endl;
            // increase number of hello packets sent to the neighbors
            for(AodvNeiTableMap::iterator it=aodvNeiTableMap.begin(); it!=aodvNeiTableMap.end(); it++)
            {
                AodvRtTableMap::iterator checkNei = aodvRtTableMap.find(it->first);
                if(checkNei!=aodvRtTableMap.end())
                    it->second->hello_send++;
            }
#else
            aodv_socket_send((AODV_msg *) rrep, dest, msg_size, 1, &DEV_NR(i));
#endif
        }

        timer_set_timeout(&hello_timer, HELLO_INTERVAL + jitter);
    }
    else
    {
        EV<<"hello does not send"<<endl;
        if (HELLO_INTERVAL - time_diff + jitter < 0)
            timer_set_timeout(&hello_timer,
                              HELLO_INTERVAL - time_diff - jitter);
        else
            timer_set_timeout(&hello_timer,
                              HELLO_INTERVAL - time_diff + jitter);
    }

}


/* Process a hello message */
void NS_CLASS hello_process(RREP * hello, int rreplen, unsigned int ifindex)
{
    u_int32_t hello_seqno, timeout, hello_interval = HELLO_INTERVAL;
    u_int8_t state, flags = 0;
    struct in_addr ext_neighbor, hello_dest;
    rt_table_t *rt;
    nei_table_t *nei_new;
    AODV_ext *ext = NULL;
    struct timeval now;
    simtime_t delay = 0;

    uint32_t cost;
    uint8_t fixhop;

    cost = costMobile;
    if (hello->prevFix)
    {
        fixhop=1;
        cost =  costStatic;
    }

    q_value_update(hello);

    if (this->isStaticNode())
        fixhop++;

    gettimeofday(&now, NULL);

    hello_dest.s_addr = hello->dest_addr;
    hello_seqno = ntohl(hello->dest_seqno);

    rt = rt_table_find(hello_dest);

    if (rt)
        flags = rt->flags;

    if (unidir_hack)
        flags |= RT_UNIDIR;
#ifndef OMNETPP
    /* Check for hello interval extension: */
    ext = (AODV_ext *) ((char *) hello + RREP_SIZE);
    while (rreplen > (int) RREP_SIZE)
    {
#else
    ext = hello->getFirstExtension();
    for (int i=0; i<hello->getNumExtension (); i++)
    {
#endif
        switch (ext->type)
        {
        case RREP_HELLO_INTERVAL_EXT:
            if (ext->length == 4)
            {
                memcpy(&hello_interval, AODV_EXT_DATA(ext), 4);
                hello_interval = ntohl(hello_interval);
#ifdef DEBUG_HELLO
                DEBUG(LOG_INFO, 0, "Hello extension interval=%lu!",
                      hello_interval);
#endif
#ifdef OMNETPP
                EV << "Hello extension interval = "<< hello_interval;
#endif

            }
            else
                alog(LOG_WARNING, 0,
                     __FUNCTION__, "Bad hello interval extension!");
            break;
        case RREP_HELLO_NEIGHBOR_SET_EXT:

#ifdef DEBUG_HELLO
            DEBUG(LOG_INFO, 0, "RREP_HELLO_NEIGHBOR_SET_EXT");
#endif
#ifdef OMNETPP
            EV << "RREP_HELLO_NEIGHBOR_SET_EXT";
#endif

            for (i = 0; i < ext->length; i = i + 4)
            {
                //ext_neighbor.s_addr =
                //    *(in_addr_t *) ((char *) AODV_EXT_DATA(ext) + i);

                ext_neighbor.s_addr = ManetAddress(IPv4Address(*(in_addr_t *) ((char *) AODV_EXT_DATA(ext) + i)));

                if (ext_neighbor.s_addr == DEV_IFINDEX(ifindex).ipaddr.s_addr)
                    flags &= ~RT_UNIDIR;
            }
            break;
        default:
            alog(LOG_WARNING, 0, __FUNCTION__,
                 "Bad extension!! type=%d, length=%d", ext->type, ext->length);
            ext = NULL;
            break;
        }
        if (ext == NULL)
            break;

        rreplen -= AODV_EXT_SIZE(ext);
        ext = AODV_EXT_NEXT(ext);
    }

#ifdef DEBUG_HELLO
    DEBUG(LOG_DEBUG, 0, "rcvd HELLO from %s, seqno %lu",
          ip_to_str(hello_dest), hello_seqno);
#endif
#ifdef OMNETPP
    EV << "rcvd HELLO from " << ip_to_str(hello_dest) << " seqno = hello_seqno";
#endif

    /* This neighbor should only be valid after receiving 3
       consecutive hello messages... */
    if (receive_n_hellos)
        state = INVALID;
    else
        state = VALID;

    timeout = ALLOWED_HELLO_LOSS * hello_interval + ROUTE_TIMEOUT_SLACK;

    EV<<"hello process"<<endl;
    if (!rt)
    {
        /* No active or expired route in the routing table. So we add a
           new entry... */

        nei_table_t *nei = nei_table_find(hello_dest);
        //there is no entry in the neighbor table for its neighbor so we add a new entry in neighbor table with initial trust=-1
        if(!nei)
        {
            EV<<"hello_process: Added new neighbor to the neighbor_table and routing_table"<<endl;
            delay = simTime() - hello->src_time;   //not used in the algorithm
            if(hello->lowEnergy == false)   //low message notification
            {
                nei_new = nei_table_insert (hello_dest, 0, 0 , -1.0 ,true, 0, 0, 0 , false, true, hello->energy, hello->expFuturVal, delay);
                rt = rt_table_insert(hello_dest, hello_dest, 1,
                                 hello_seqno, timeout, state, flags, ifindex,cost,fixhop, true, false, 0, 0);
            }
            else
            {
                rt = rt_table_insert(hello_dest, hello_dest, 1,
                                 hello_seqno, timeout, state, flags, ifindex,cost,fixhop, true, true, 0, 0);
                nei_new = nei_table_insert (hello_dest, 0, 0 , -1.0 ,true, 0, 0, 0 , true, true, hello->energy, hello->expFuturVal, delay);
            }

        }
        else
        {
            EV<<"hello_process: Added new neighbor to the routing table"<<endl;
            if(nei->trusted == true )
                if(nei->blacklist == true)
                    rt = rt_table_insert(hello_dest, hello_dest, 1,
                                                     hello_seqno, timeout, state, flags, ifindex,cost,fixhop, true, true, 0, -1);
                else
                {
                    if (hello->lowEnergy == true)
                        rt = rt_table_insert(hello_dest, hello_dest, 1,
                                                     hello_seqno, timeout, state, flags, ifindex,cost,fixhop, true, true, 0, -1);
                    else
                        rt = rt_table_insert(hello_dest, hello_dest, 1,
                                                     hello_seqno, timeout, state, flags, ifindex,cost,fixhop, true, false, 0, -1);
                }
            else
                if(nei->blacklist == true )
                    rt = rt_table_insert(hello_dest, hello_dest, 1,
                                                     hello_seqno, timeout, state, flags, ifindex,cost,fixhop, false, true, 0, -1);
                else
                {
                    if(hello->lowEnergy == true)
                        rt = rt_table_insert(hello_dest, hello_dest, 1,
                                                     hello_seqno, timeout, state, flags, ifindex,cost,fixhop, false, true, 0, -1);
                    else
                        rt = rt_table_insert(hello_dest, hello_dest, 1,
                                                    hello_seqno, timeout, state, flags, ifindex,cost,fixhop, false, false, 0, -1);
                }
/*            if(nei->nei_now == false)
            {*/
            delay = simTime() - hello->src_time;
            nei_table_update(hello_dest, delay, true, hello->lowEnergy, hello->energy);
            //}
        }
        if (flags & RT_UNIDIR)
        {
            DEBUG(LOG_INFO, 0, "%s new NEIGHBOR, link UNI-DIR",
                  ip_to_str(rt->dest_addr));
        }
        else
        {
            DEBUG(LOG_INFO, 0, "%s new NEIGHBOR!", ip_to_str(rt->dest_addr));
        }
        rt->hello_cnt = 1;
    }
    else
    {

        if ((flags & RT_UNIDIR) && rt->state == VALID && rt->hcnt > 1)
        {
            goto hello_update;
        }

        if (receive_n_hellos && rt->hello_cnt < (receive_n_hellos - 1))
        {
            if (timeval_diff(&now, &rt->last_hello_time) <
                    (long) (hello_interval + hello_interval / 2))
                rt->hello_cnt++;
            else
                rt->hello_cnt = 1;

            memcpy(&rt->last_hello_time, &now, sizeof(struct timeval));
            return;
        }
        nei_table_t *nei2 = nei_table_find(hello_dest);
       //update the trust value and blacklist state of the node from neighbor_table and put in routing_table
       if(nei2)
       {
           EV<<"hello_process: Update trust and blacklist of the neighbor in the routing table"<<endl;
           //show_neighbors();
           if(nei2->trusted == true)
               if(nei2->blacklist == true)
                   rt_table_update(rt, hello_dest, 1, hello_seqno, timeout, VALID, flags, ifindex, cost, fixhop, true, true, rt->delay, rt->pathTrust);
               else
               {
                   if(hello->lowEnergy == true)
                       rt_table_update(rt, hello_dest, 1, hello_seqno, timeout, VALID, flags, ifindex, cost, fixhop, true, true, rt->delay, rt->pathTrust);
                   else
                       rt_table_update(rt, hello_dest, 1, hello_seqno, timeout, VALID, flags, ifindex, cost, fixhop, true, false, rt->delay, rt->pathTrust);
               }
           else
               if(nei2->blacklist == true )
                   rt_table_update(rt, hello_dest, 1, hello_seqno, timeout, VALID, flags, ifindex, cost, fixhop, false, true, rt->delay, rt->pathTrust);
               else
               {
                   if(hello->lowEnergy == true)
                       rt_table_update(rt, hello_dest, 1, hello_seqno, timeout, VALID, flags, ifindex, cost, fixhop, false, true, rt->delay, rt->pathTrust);
                   else
                       rt_table_update(rt, hello_dest, 1, hello_seqno, timeout, VALID, flags, ifindex, cost, fixhop, false, false, rt->delay, rt->pathTrust);
               }
           //if(nei2->nei_now == false)
           delay = simTime() - hello->src_time;
           //if(hello->lowEnergy == true)
           nei_table_update(hello_dest, delay,true, hello->lowEnergy, hello->energy);
          // else
          //     nei_table_update(hello_dest, delay, hello->expFuturVal, false);
       }
       else
       {
           EV<<"Error, neighbor in routing table exist, but does not exist in neighbor_table!"<<endl;
       }
    }
    //ttlFile2<<"routing table of: "<<DEV_IFINDEX(ifindex).ipaddr.s_addr<<endl;
    /*if(!aodvRtTableMap.empty())
        for (AodvRtTableMap::iterator it = aodvRtTableMap.begin(); it != aodvRtTableMap.end(); it++)
        {
            ttlFile2<<it->second->dest_addr.S_addr<<" "<<it->second->next_hop.S_addr<<endl;
        }*/
   // ttlFile2<<endl;
    for (AodvNeiTableMap::iterator it = aodvNeiTableMap.begin(); it != aodvNeiTableMap.end(); it++)
        if(it->first == hello_dest.S_addr)
            it->second->hello_rcvd++;

   // ttlFile2.close();
   // show_table2();



hello_update:

    hello_update_timeout(rt, &now, ALLOWED_HELLO_LOSS * hello_interval);
    return;
}


#define HELLO_DELAY 50      /* The extra time we should allow an hello
message to take (due to processing) before
assuming lost . */

NS_INLINE void NS_CLASS hello_update_timeout(rt_table_t * rt,
        struct timeval *now, long time)
{
    timer_set_timeout(&rt->hello_timer, time + HELLO_DELAY);
    memcpy(&rt->last_hello_time, now, sizeof(struct timeval));
}

